@echo off
title Omnifi Video Downloader
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Omnifi-Video-Downloader.ps1"
echo.
pause
