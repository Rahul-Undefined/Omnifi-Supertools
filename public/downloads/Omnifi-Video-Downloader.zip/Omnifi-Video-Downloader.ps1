# Omnifi Video Downloader (Windows helper)
# Downloads videos from YouTube, Facebook, Instagram, X, TikTok, Vimeo and most sites
# from YOUR computer, using the open-source yt-dlp engine and FFmpeg.
# First run fetches the latest engine into the "engine" folder next to this script
# (about 15 MB + 90 MB for FFmpeg). Nothing is installed system-wide, no admin rights needed.
# Omnifi internal use only. Download content you have the rights to use.

$ErrorActionPreference = "Stop"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Engine = Join-Path $Root "engine"
$YtDlp = Join-Path $Engine "yt-dlp.exe"
$FfmpegDir = Join-Path $Engine "ffmpeg"
$OutDir = Join-Path ([Environment]::GetFolderPath("MyDocuments")) "Omnifi Videos"
New-Item -ItemType Directory -Force $Engine | Out-Null
New-Item -ItemType Directory -Force $OutDir | Out-Null

function Write-Title($t) { Write-Host ""; Write-Host "  $t" -ForegroundColor Cyan; Write-Host ("  " + ("-" * $t.Length)) -ForegroundColor DarkCyan }

function Ensure-Engine {
  $stamp = Join-Path $Engine "last-update.txt"
  $needs = -not (Test-Path $YtDlp)
  if (-not $needs -and (Test-Path $stamp)) {
    $age = (Get-Date) - (Get-Item $stamp).LastWriteTime
    if ($age.TotalDays -gt 7) { $needs = $true }   # sites change often; refresh weekly
  }
  if ($needs) {
    Write-Host "  Fetching the latest download engine (yt-dlp) from GitHub..." -ForegroundColor Yellow
    try {
      Invoke-WebRequest -Uri "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe" -OutFile "$YtDlp.new" -UseBasicParsing
      Move-Item -Force "$YtDlp.new" $YtDlp
      Set-Content $stamp (Get-Date).ToString()
    } catch {
      if (Test-Path $YtDlp) { Write-Host "  Could not update; using the existing engine." -ForegroundColor Yellow }
      else { throw "Could not download yt-dlp.exe. Check your internet connection or proxy. $_" }
    }
  }
  $ff = Get-ChildItem -Path $FfmpegDir -Recurse -Filter ffmpeg.exe -ErrorAction SilentlyContinue | Select-Object -First 1
  if (-not $ff) {
    Write-Host "  Fetching FFmpeg (needed to merge 1080p+ video with audio and to make MP3)..." -ForegroundColor Yellow
    try {
      $zip = Join-Path $Engine "ffmpeg.zip"
      Invoke-WebRequest -Uri "https://github.com/BtbN/FFmpeg-Builds/releases/latest/download/ffmpeg-master-latest-win64-gpl.zip" -OutFile $zip -UseBasicParsing
      Expand-Archive -Path $zip -DestinationPath $FfmpegDir -Force
      Remove-Item $zip -Force
      $ff = Get-ChildItem -Path $FfmpegDir -Recurse -Filter ffmpeg.exe | Select-Object -First 1
    } catch {
      Write-Host "  FFmpeg could not be fetched. Downloads still work, limited to 720p single-file streams and no MP3." -ForegroundColor Yellow
    }
  }
  # YouTube's player challenges need a small JavaScript runtime (Deno). Fetched once, kept in the engine folder.
  $deno = Join-Path $Engine "deno\deno.exe"
  if (-not (Test-Path $deno)) {
    Write-Host "  Fetching the Deno JavaScript runtime (needed for YouTube)..." -ForegroundColor Yellow
    try {
      $dz = Join-Path $Engine "deno.zip"
      Invoke-WebRequest -Uri "https://github.com/denoland/deno/releases/latest/download/deno-x86_64-pc-windows-msvc.zip" -OutFile $dz -UseBasicParsing
      Expand-Archive -Path $dz -DestinationPath (Join-Path $Engine "deno") -Force
      Remove-Item $dz -Force
    } catch { Write-Host "  Deno could not be fetched; YouTube may offer fewer qualities." -ForegroundColor Yellow }
  }
  if ($ff) { return $ff.DirectoryName } else { return $null }
}

Write-Title "Omnifi Video Downloader"
$ffLocation = Ensure-Engine
$ver = & $YtDlp --version 2>$null
Write-Host "  Engine $ver" -ForegroundColor DarkGray
Write-Host "  Saves to: $OutDir" -ForegroundColor DarkGray

while ($true) {
  Write-Host ""
  $url = Read-Host "  Paste the video link (blank to quit)"
  if ([string]::IsNullOrWhiteSpace($url)) { break }
  Write-Host ""
  Write-Host "  1) Best quality video (MP4)     4) Audio only (MP3)"
  Write-Host "  2) Up to 1080p (MP4)            5) Audio only (M4A)"
  Write-Host "  3) Up to 720p (MP4)             6) Choose a specific quality"
  $choice = Read-Host "  Choice [1]"
  if ([string]::IsNullOrWhiteSpace($choice)) { $choice = "1" }

  $denoExe = Join-Path $Engine "deno\deno.exe"
  $args = @("--no-playlist", "--no-mtime", "--windows-filenames", "-o", (Join-Path $OutDir "%(title).120B.%(ext)s"), "--remote-components", "ejs:github")
  if (Test-Path $denoExe) { $args += @("--js-runtimes", "deno:$denoExe") }
  if ($ffLocation) { $args += @("--ffmpeg-location", $ffLocation) }
  switch ($choice) {
    "1" { $args += @("-f", "bv*+ba/b", "--merge-output-format", "mp4", "-S", "res,ext:mp4:m4a") }
    "2" { $args += @("-f", "bv*[height<=1080]+ba/b[height<=1080]/b", "--merge-output-format", "mp4", "-S", "res,ext:mp4:m4a") }
    "3" { $args += @("-f", "bv*[height<=720]+ba/b[height<=720]/b", "--merge-output-format", "mp4", "-S", "res,ext:mp4:m4a") }
    "4" { $args += @("-f", "ba/b", "-x", "--audio-format", "mp3", "--audio-quality", "0") }
    "5" { $args += @("-f", "ba/b", "-x", "--audio-format", "m4a") }
    "6" {
      & $YtDlp --no-playlist -F $url
      $fid = Read-Host "  Type the ID from the list (video+audio are merged automatically)"
      $args += @("-f", "$fid+ba/$fid", "--merge-output-format", "mp4")
    }
    default { $args += @("-f", "bv*+ba/b", "--merge-output-format", "mp4") }
  }
  # The JS-runtime flags only exist on recent engines; drop them if this version does not know them.
  $help = & $YtDlp --help 2>$null | Out-String
  if ($help -notmatch "--js-runtimes") { $args = $args | Where-Object { $_ -ne "--js-runtimes" -and $_ -notlike "deno:*" } }
  if ($help -notmatch "--remote-components") { $args = $args | Where-Object { $_ -notin @("--remote-components", "ejs:github") } }
  # Reuse your browser's sign-in for sites that need it (optional, e.g. private Facebook groups).
  $useCookies = Read-Host "  Use your Edge sign-in cookies for this site? (y/N)"
  if ($useCookies -match "^[Yy]") { $args += @("--cookies-from-browser", "edge") }

  Write-Host ""
  & $YtDlp @args $url
  if ($LASTEXITCODE -eq 0) {
    Write-Host ""; Write-Host "  Done. Saved in $OutDir" -ForegroundColor Green
    Start-Process explorer.exe $OutDir
  } else {
    Write-Host ""; Write-Host "  The download failed. Read the ERROR line above; for YouTube 'sign in' errors try again with cookies (y), or update by deleting the engine folder." -ForegroundColor Red
  }
}
