using System.Runtime.InteropServices;

namespace StepsRecorder.Native;

/// <summary>
/// Gives the window its own taskbar identity even though the process is the generic dotnet.exe host.
/// Windows uses the AppUserModelID to group taskbar buttons and, when the user pins the app, the
/// "relaunch" properties (command, display name, icon) to build the pinned shortcut. Without these the
/// pinned item would show the .NET host icon and launch dotnet.exe with no arguments.
/// </summary>
internal static class TaskbarIdentity
{
    public const string AppUserModelId = "Omnifi.StepsRecorder";

    private static readonly Guid PropertyStoreFormat = new("9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3");
    private const uint PidRelaunchCommand = 2;
    private const uint PidRelaunchIconResource = 3;
    private const uint PidRelaunchDisplayNameResource = 4;
    private const uint PidAppUserModelId = 5;
    private const ushort VT_LPWSTR = 31;

    [StructLayout(LayoutKind.Sequential, Pack = 4)]
    private struct PROPERTYKEY
    {
        public Guid fmtid;
        public uint pid;
    }

    // Native PROPVARIANT is 24 bytes on x64: vt + 3 reserved words, then a 16-byte union at offset 8.
    [StructLayout(LayoutKind.Explicit, Size = 24)]
    private struct PROPVARIANT
    {
        [FieldOffset(0)] public ushort vt;
        [FieldOffset(8)] public IntPtr pointerValue;
    }

    [ComImport, Guid("886d8eeb-8cf2-4446-8d02-cdba1dbdcf99"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IPropertyStore
    {
        [PreserveSig] int GetCount(out uint count);
        [PreserveSig] int GetAt(uint index, out PROPERTYKEY key);
        [PreserveSig] int GetValue([In] ref PROPERTYKEY key, out PROPVARIANT value);
        [PreserveSig] int SetValue([In] ref PROPERTYKEY key, [In] ref PROPVARIANT value);
        [PreserveSig] int Commit();
    }

    [DllImport("shell32.dll", SetLastError = true)]
    private static extern int SHGetPropertyStoreForWindow(IntPtr hwnd, ref Guid riid, out IPropertyStore store);

    [DllImport("shell32.dll", CharSet = CharSet.Unicode)]
    private static extern int SetCurrentProcessExplicitAppUserModelID(string appId);

    [DllImport("ole32.dll")]
    private static extern int PropVariantClear(ref PROPVARIANT pvar);

    /// <summary>Call once, before any window is created.</summary>
    public static void SetProcessId()
    {
        try { SetCurrentProcessExplicitAppUserModelID(AppUserModelId); } catch { /* best effort */ }
    }

    /// <summary>Sets the window's taskbar identity and relaunch info. Safe to call again after the handle is recreated.</summary>
    public static void Apply(IntPtr hwnd, string relaunchCommand, string displayName, string? iconPath)
    {
        if (hwnd == IntPtr.Zero) return;
        try
        {
            Guid iid = typeof(IPropertyStore).GUID;
            if (SHGetPropertyStoreForWindow(hwnd, ref iid, out IPropertyStore store) != 0 || store == null) return;
            try
            {
                SetString(store, PidAppUserModelId, AppUserModelId);
                SetString(store, PidRelaunchCommand, relaunchCommand);
                SetString(store, PidRelaunchDisplayNameResource, displayName);
                if (!string.IsNullOrEmpty(iconPath)) SetString(store, PidRelaunchIconResource, iconPath + ",0");
                store.Commit();
            }
            finally
            {
                Marshal.ReleaseComObject(store);
            }
        }
        catch
        {
            // Taskbar identity is cosmetic; never fail the app over it.
        }
    }

    private static void SetString(IPropertyStore store, uint pid, string value)
    {
        var key = new PROPERTYKEY { fmtid = PropertyStoreFormat, pid = pid };
        var pv = new PROPVARIANT { vt = VT_LPWSTR, pointerValue = Marshal.StringToCoTaskMemUni(value) };
        try { store.SetValue(ref key, ref pv); }
        finally { PropVariantClear(ref pv); }
    }
}
