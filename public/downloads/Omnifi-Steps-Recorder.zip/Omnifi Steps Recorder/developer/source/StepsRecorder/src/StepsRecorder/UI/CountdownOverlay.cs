using StepsRecorder.Branding;

namespace StepsRecorder.UI;

/// <summary>
/// Small borderless, always-on-top countdown shown in the centre of the primary display before recording
/// starts, so the user has time to switch to the application they want to demonstrate.
/// </summary>
public sealed class CountdownOverlay : Form
{
    private readonly Label _number = new();
    private readonly Label _caption = new();

    public CountdownOverlay()
    {
        FormBorderStyle = FormBorderStyle.None;
        ShowInTaskbar = false;
        TopMost = true;
        StartPosition = FormStartPosition.Manual;
        BackColor = OmnifiBrand.DeepNavy;
        Opacity = 0.92;
        Size = new Size(260, 200);
        Rectangle b = Screen.PrimaryScreen?.Bounds ?? new Rectangle(0, 0, 1920, 1080);
        Location = new Point(b.X + (b.Width - Width) / 2, b.Y + (b.Height - Height) / 2);

        _caption.Text = "Recording starts in";
        _caption.ForeColor = OmnifiBrand.Lavender;
        _caption.Font = OmnifiBrand.BodyFont(12f);
        _caption.TextAlign = ContentAlignment.MiddleCenter;
        _caption.Dock = DockStyle.Top;
        _caption.Height = 50;

        _number.ForeColor = OmnifiBrand.IndigoBright;
        _number.Font = OmnifiBrand.HeadlineFont(64f);
        _number.TextAlign = ContentAlignment.MiddleCenter;
        _number.Dock = DockStyle.Fill;

        Controls.Add(_number);
        Controls.Add(_caption);
    }

    protected override bool ShowWithoutActivation => true; // never steal focus from the app being demonstrated

    protected override CreateParams CreateParams
    {
        get
        {
            var cp = base.CreateParams;
            cp.ExStyle |= 0x08000000; // WS_EX_NOACTIVATE
            return cp;
        }
    }

    /// <summary>Shows the overlay and counts down; returns when the count reaches zero.</summary>
    public static async Task RunAsync(int seconds)
    {
        using var overlay = new CountdownOverlay();
        overlay.Show();
        for (int n = seconds; n >= 1; n--)
        {
            overlay._number.Text = n.ToString();
            overlay.Refresh();
            await Task.Delay(1000);
        }
        overlay._number.Text = "Go";
        overlay._caption.Text = "Recording";
        overlay.Refresh();
        await Task.Delay(350);
        overlay.Close();
    }
}
