using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using StepsRecorder.Branding;
using StepsRecorder.Models;
using A = DocumentFormat.OpenXml.Drawing;
using DW = DocumentFormat.OpenXml.Drawing.Wordprocessing;
using PIC = DocumentFormat.OpenXml.Drawing.Pictures;
using W = DocumentFormat.OpenXml.Wordprocessing;

namespace StepsRecorder.Reporting;

/// <summary>
/// Omnifi-branded Word report built with the Open XML SDK: logo top-left and title top-right in the header
/// over a thin navy rule, navy section headings with an indigo rule, navy-header metadata table with
/// alternating rows, numbered steps with scaled screenshots, and a footer with the internal-use notice,
/// centered page number and date.
/// </summary>
public static class DocxReportWriter
{
    private const long PageWidthEmu = 6L * 914400L + 457200L; // 6.5" printable width (US Letter, 1" margins)
    private const long MaxImageHeightEmu = 8L * 914400L;      // 8"
    private const string Navy = "0A0F3D";
    private const string Indigo = "4F5BD5";
    private const string Body = "2D3580";
    private const string Muted = "6B72B8";
    private const string OffWhite = "F5F5FA";
    private const string Font = "Segoe UI";

    public static void Write(string path, RecordingResult r)
    {
        using var doc = WordprocessingDocument.Create(path, WordprocessingDocumentType.Document);
        MainDocumentPart main = doc.AddMainDocumentPart();
        main.Document = new W.Document();
        var body = main.Document.AppendChild(new W.Body());
        uint imageId = 1;

        // Header part: logo left, title right, navy rule below.
        HeaderPart headerPart = main.AddNewPart<HeaderPart>();
        string headerId = main.GetIdOfPart(headerPart);
        headerPart.Header = BuildHeader(headerPart, ref imageId);
        headerPart.Header.Save();

        // Footer part: rule above, internal-use notice left, page number centered, date right.
        FooterPart footerPart = main.AddNewPart<FooterPart>();
        string footerId = main.GetIdOfPart(footerPart);
        footerPart.Footer = BuildFooter(r.EndedAt);
        footerPart.Footer.Save();

        body.Append(Paragraph("Steps recording", bold: true, sizeHalfPoints: 40, color: Navy, spaceAfter: 60, dot: true));
        body.Append(Paragraph($"Recorded {r.StartedAt:dd MMM yyyy HH:mm} on {r.MachineName}", sizeHalfPoints: 20, color: Muted, spaceAfter: 200));

        int saved = r.Steps.Count(s => s.ScreenshotSaved);
        body.Append(Callout($"{r.Steps.Count} step{(r.Steps.Count == 1 ? "" : "s")} ({r.ClickCount} click{(r.ClickCount == 1 ? "" : "s")}, {r.SelectionCount} selection{(r.SelectionCount == 1 ? "" : "s")}) captured over {ReportGenerator.FormatDuration(r.ActiveDuration)} of recording" +
                            (r.VideoSucceeded ? ", with video." : "; video not available.")));

        body.Append(SectionHeading("Recording details"));
        body.Append(MetadataTable(new[]
        {
            ("Started", r.StartedAt.ToString("dd MMM yyyy HH:mm:ss")),
            ("Ended", r.EndedAt.ToString("dd MMM yyyy HH:mm:ss")),
            ("Duration", ReportGenerator.FormatDuration(r.ActiveDuration) + " (excluding pauses)"),
            ("Total steps", $"{r.Steps.Count} ({r.ClickCount} clicks, {r.SelectionCount} selections)"),
            ("Screenshots", saved.ToString()),
            ("Audio", r.AudioMode == "Microphone" ? "Microphone (voice narration)" : "None"),
            ("Captured display", r.CaptureDisplay),
            ("Video", r.VideoSucceeded ? "screen.mp4" : "Not available: " + (r.VideoError ?? "unknown error")),
            ("Output folder", r.OutputFolder)
        }));

        if (r.Warnings.Count > 0)
        {
            body.Append(SectionHeading("Warnings"));
            foreach (var w in r.Warnings) body.Append(Paragraph("- " + w, sizeHalfPoints: 20, color: Body));
        }

        body.Append(SectionHeading("Steps"));
        if (r.Steps.Count == 0) body.Append(Paragraph("No clicks were captured during this recording.", sizeHalfPoints: 22, color: Body));

        foreach (var s in r.Steps)
        {
            body.Append(StepHeading(s.StepNumber, s.Description));
            string what = s.Kind == StepKind.Selection
                ? $"Selection ({ReportGenerator.ButtonName(s.Button).ToLowerInvariant()} drag) from ({s.X}, {s.Y}) to ({s.EndX}, {s.EndY})"
                : $"{ReportGenerator.ButtonName(s.Button)} click at ({s.X}, {s.Y})";
            string meta = what + "   |   " +
                          $"Time {ReportGenerator.FormatWall(s.WallTime)}   |   Video offset {ReportGenerator.FormatOffset(s.VideoOffset)}   |   " +
                          $"Window: {s.Window.DisplayTitle}" + (string.IsNullOrEmpty(s.Window.ProcessName) ? "" : $" ({s.Window.ProcessName}.exe)");
            body.Append(Paragraph(meta, sizeHalfPoints: 18, color: Muted, spaceAfter: 60, keepNext: true));
            if (s.Element != null)
            {
                string el = "UI element: " + s.Element.ControlType +
                            (string.IsNullOrEmpty(s.Element.Name) ? "" : " \"" + s.Element.Name + "\"") +
                            (string.IsNullOrEmpty(s.Element.AutomationId) ? "" : " [" + s.Element.AutomationId + "]");
                body.Append(Paragraph(el, sizeHalfPoints: 18, color: Muted, spaceAfter: 60, keepNext: true));
            }
            if (!string.IsNullOrEmpty(s.Note))
                body.Append(Paragraph("Note: " + s.Note, italic: true, sizeHalfPoints: 18, color: Body, spaceAfter: 60, keepNext: true));

            if (s.ScreenshotSaved && File.Exists(s.ScreenshotFullPath) && s.ScreenshotWidth > 0 && s.ScreenshotHeight > 0)
            {
                try
                {
                    ImagePart imagePart = main.AddImagePart(ImagePartType.Png);
                    using (FileStream fs = File.OpenRead(s.ScreenshotFullPath)) imagePart.FeedData(fs);
                    string relId = main.GetIdOfPart(imagePart);
                    body.Append(ImageParagraph(relId, imageId++, Path.GetFileName(s.ScreenshotFullPath), s.ScreenshotWidth, s.ScreenshotHeight, PageWidthEmu, MaxImageHeightEmu));
                    body.Append(Paragraph("Screenshot: " + s.ScreenshotRelativePath, sizeHalfPoints: 16, color: Muted, spaceAfter: 160));
                }
                catch (Exception ex)
                {
                    body.Append(Paragraph("Screenshot could not be embedded: " + ex.Message, italic: true, sizeHalfPoints: 18, color: Indigo));
                }
            }
            else
            {
                body.Append(Paragraph("Screenshot not available for this step.", italic: true, sizeHalfPoints: 18, color: Indigo));
            }
        }

        body.Append(new W.SectionProperties(
            new W.HeaderReference { Type = W.HeaderFooterValues.Default, Id = headerId },
            new W.FooterReference { Type = W.HeaderFooterValues.Default, Id = footerId },
            new W.PageSize { Width = 12240, Height = 15840 },
            new W.PageMargin { Top = 1500, Right = 1440, Bottom = 1300, Left = 1440, Header = 560, Footer = 560, Gutter = 0 }));

        main.Document.Save();
    }

    // ----- header / footer -----

    private static W.Header BuildHeader(HeaderPart headerPart, ref uint imageId)
    {
        var header = new W.Header();
        ImagePart logoPart = headerPart.AddImagePart(ImagePartType.Png);
        using (var ms = new MemoryStream(OmnifiBrand.RenderLogoPng(120, onDark: false))) logoPart.FeedData(ms);
        string logoId = headerPart.GetIdOfPart(logoPart);

        // Two-column borderless table: logo left, title right; bottom border = thin navy rule.
        var table = new W.Table(new W.TableProperties(
            new W.TableWidth { Width = "5000", Type = W.TableWidthUnitValues.Pct },
            new W.TableBorders(
                new W.TopBorder { Val = W.BorderValues.Nil },
                new W.LeftBorder { Val = W.BorderValues.Nil },
                new W.RightBorder { Val = W.BorderValues.Nil },
                new W.InsideHorizontalBorder { Val = W.BorderValues.Nil },
                new W.InsideVerticalBorder { Val = W.BorderValues.Nil },
                new W.BottomBorder { Val = W.BorderValues.Single, Size = 6, Color = Navy })));
        var row = new W.TableRow();

        long logoCx = (long)(0.95 * 914400); // ~0.95" wide
        long logoCy = (long)Math.Round(logoCx * 43.0 / 160.0);
        var logoCell = new W.TableCell(new W.TableCellProperties(new W.TableCellWidth { Width = "4680", Type = W.TableWidthUnitValues.Dxa }, new W.TableCellVerticalAlignment { Val = W.TableVerticalAlignmentValues.Center }));
        logoCell.Append(ImageParagraph(logoId, imageId++, "omnifi-logo.png", 160, 43, logoCx, logoCy, spaceAfter: 60));
        row.Append(logoCell);

        var titleCell = new W.TableCell(new W.TableCellProperties(new W.TableCellWidth { Width = "4680", Type = W.TableWidthUnitValues.Dxa }, new W.TableCellVerticalAlignment { Val = W.TableVerticalAlignmentValues.Center }));
        titleCell.Append(Paragraph(OmnifiBrand.ProductName + " report", bold: true, sizeHalfPoints: 20, color: Navy, spaceAfter: 60, align: W.JustificationValues.Right));
        row.Append(titleCell);
        table.Append(row);
        header.Append(table);
        header.Append(Paragraph(string.Empty, sizeHalfPoints: 8, spaceAfter: 0));
        return header;
    }

    private static W.Footer BuildFooter(DateTime date)
    {
        var footer = new W.Footer();
        var table = new W.Table(new W.TableProperties(
            new W.TableWidth { Width = "5000", Type = W.TableWidthUnitValues.Pct },
            new W.TableBorders(
                new W.TopBorder { Val = W.BorderValues.Single, Size = 6, Color = Navy },
                new W.LeftBorder { Val = W.BorderValues.Nil },
                new W.RightBorder { Val = W.BorderValues.Nil },
                new W.BottomBorder { Val = W.BorderValues.Nil },
                new W.InsideHorizontalBorder { Val = W.BorderValues.Nil },
                new W.InsideVerticalBorder { Val = W.BorderValues.Nil })));
        var row = new W.TableRow();

        row.Append(FooterCell(Paragraph(OmnifiBrand.InternalUseNotice, sizeHalfPoints: 16, color: Muted, spaceBefore: 80, spaceAfter: 0, align: W.JustificationValues.Left)));

        var pageRun = RunProps(bold: false, italic: false, sizeHalfPoints: 16, color: Muted);
        var pagePara = new W.Paragraph(
            new W.ParagraphProperties(new W.Justification { Val = W.JustificationValues.Center }, new W.SpacingBetweenLines { Before = "80", After = "0" }),
            new W.Run(pageRun.CloneNode(true), new W.Text("Page ") { Space = SpaceProcessingModeValues.Preserve }),
            new W.Run(pageRun.CloneNode(true), new W.FieldChar { FieldCharType = W.FieldCharValues.Begin }),
            new W.Run(pageRun.CloneNode(true), new W.FieldCode(" PAGE ") { Space = SpaceProcessingModeValues.Preserve }),
            new W.Run(pageRun.CloneNode(true), new W.FieldChar { FieldCharType = W.FieldCharValues.Separate }),
            new W.Run(pageRun.CloneNode(true), new W.Text("1")),
            new W.Run(pageRun.CloneNode(true), new W.FieldChar { FieldCharType = W.FieldCharValues.End }));
        row.Append(FooterCell(pagePara));

        row.Append(FooterCell(Paragraph(date.ToString("dd MMM yyyy"), sizeHalfPoints: 16, color: Muted, spaceBefore: 80, spaceAfter: 0, align: W.JustificationValues.Right)));
        table.Append(row);
        footer.Append(table);
        return footer;
    }

    private static W.TableCell FooterCell(W.Paragraph p) =>
        new(new W.TableCellProperties(new W.TableCellWidth { Width = "3120", Type = W.TableWidthUnitValues.Dxa }), p);

    // ----- building blocks -----

    private static W.RunProperties RunProps(bool bold, bool italic, int sizeHalfPoints, string? color)
    {
        var rp = new W.RunProperties();
        rp.Append(new W.RunFonts { Ascii = Font, HighAnsi = Font, ComplexScript = Font });
        if (bold) rp.Append(new W.Bold());
        if (italic) rp.Append(new W.Italic());
        if (color != null) rp.Append(new W.Color { Val = color });
        rp.Append(new W.FontSize { Val = sizeHalfPoints.ToString() });
        return rp;
    }

    private static W.Paragraph Paragraph(string text, bool bold = false, bool italic = false, int sizeHalfPoints = 22,
        string? color = Body, int spaceBefore = 0, int spaceAfter = 100, bool keepNext = false, bool dot = false,
        W.JustificationValues? align = null)
    {
        var paraProps = new W.ParagraphProperties();
        if (keepNext) paraProps.Append(new W.KeepNext());
        paraProps.Append(new W.SpacingBetweenLines { Before = spaceBefore.ToString(), After = spaceAfter.ToString(), Line = "276", LineRule = W.LineSpacingRuleValues.Auto });
        if (align != null) paraProps.Append(new W.Justification { Val = align });

        var para = new W.Paragraph(paraProps);
        para.Append(new W.Run(RunProps(bold, italic, sizeHalfPoints, color), new W.Text(text) { Space = SpaceProcessingModeValues.Preserve }));
        if (dot) para.Append(new W.Run(RunProps(true, false, sizeHalfPoints, Indigo), new W.Text("•")));
        return para;
    }

    /// <summary>Section header: Deep Navy bold, followed by a thin Indigo rule (paragraph bottom border).</summary>
    private static W.Paragraph SectionHeading(string text)
    {
        var paraProps = new W.ParagraphProperties(
            new W.KeepNext(),
            new W.ParagraphBorders(new W.BottomBorder { Val = W.BorderValues.Single, Size = 8, Color = Indigo, Space = 2 }),
            new W.SpacingBetweenLines { Before = "320", After = "140" });
        var para = new W.Paragraph(paraProps);
        para.Append(new W.Run(RunProps(true, false, 28, Navy), new W.Text(text) { Space = SpaceProcessingModeValues.Preserve }));
        para.Append(new W.Run(RunProps(true, false, 28, Indigo), new W.Text("•")));
        return para;
    }

    private static W.Paragraph StepHeading(int number, string description)
    {
        var paraProps = new W.ParagraphProperties(new W.KeepNext(), new W.SpacingBetweenLines { Before = "260", After = "60" });
        var para = new W.Paragraph(paraProps);
        para.Append(new W.Run(RunProps(true, false, 24, Indigo), new W.Text($"{number}.  ") { Space = SpaceProcessingModeValues.Preserve }));
        para.Append(new W.Run(RunProps(true, false, 24, Navy), new W.Text(description) { Space = SpaceProcessingModeValues.Preserve }));
        return para;
    }

    /// <summary>Callout: Indigo left border, Off-White background, Deep Navy bold text.</summary>
    private static W.Paragraph Callout(string text)
    {
        var paraProps = new W.ParagraphProperties(
            new W.ParagraphBorders(new W.LeftBorder { Val = W.BorderValues.Single, Size = 24, Color = Indigo, Space = 8 }),
            new W.Shading { Val = W.ShadingPatternValues.Clear, Color = "auto", Fill = OffWhite },
            new W.SpacingBetweenLines { Before = "120", After = "200" },
            new W.Indentation { Left = "120" });
        return new W.Paragraph(paraProps, new W.Run(RunProps(true, false, 22, Navy), new W.Text(text) { Space = SpaceProcessingModeValues.Preserve }));
    }

    private static W.Table MetadataTable(IEnumerable<(string Key, string Value)> rows)
    {
        var table = new W.Table(new W.TableProperties(
            new W.TableWidth { Width = "5000", Type = W.TableWidthUnitValues.Pct },
            new W.TableBorders(
                new W.TopBorder { Val = W.BorderValues.Single, Size = 4, Color = "DADCF0" },
                new W.BottomBorder { Val = W.BorderValues.Single, Size = 4, Color = "DADCF0" },
                new W.LeftBorder { Val = W.BorderValues.Single, Size = 4, Color = "DADCF0" },
                new W.RightBorder { Val = W.BorderValues.Single, Size = 4, Color = "DADCF0" },
                new W.InsideHorizontalBorder { Val = W.BorderValues.Single, Size = 4, Color = "DADCF0" },
                new W.InsideVerticalBorder { Val = W.BorderValues.Single, Size = 4, Color = "DADCF0" })));

        bool alt = false;
        foreach (var (key, value) in rows)
        {
            var row = new W.TableRow();
            row.Append(Cell(key, bold: true, widthTwips: 2300, fill: Navy, textColor: "FFFFFF"));
            row.Append(Cell(value, bold: false, widthTwips: 7060, fill: alt ? OffWhite : "FFFFFF", textColor: Body));
            table.Append(row);
            alt = !alt;
        }
        return table;
    }

    private static W.TableCell Cell(string text, bool bold, int widthTwips, string fill, string textColor)
    {
        var cellProps = new W.TableCellProperties(
            new W.TableCellWidth { Width = widthTwips.ToString(), Type = W.TableWidthUnitValues.Dxa },
            new W.Shading { Val = W.ShadingPatternValues.Clear, Color = "auto", Fill = fill },
            new W.TableCellMargin(new W.TopMargin { Width = "80", Type = W.TableWidthUnitValues.Dxa }, new W.BottomMargin { Width = "80", Type = W.TableWidthUnitValues.Dxa }));
        var cell = new W.TableCell(cellProps);
        cell.Append(Paragraph(text, bold: bold, sizeHalfPoints: 20, color: textColor, spaceAfter: 0));
        return cell;
    }

    private static W.Paragraph ImageParagraph(string relationshipId, uint id, string name, int pixelWidth, int pixelHeight, long maxCx, long maxCy, int spaceAfter = 40)
    {
        long cx = maxCx;
        long cy = (long)Math.Round(cx * (double)pixelHeight / pixelWidth);
        if (cy > maxCy)
        {
            cy = maxCy;
            cx = (long)Math.Round(cy * (double)pixelWidth / pixelHeight);
        }

        var inline = new DW.Inline(
            new DW.Extent { Cx = cx, Cy = cy },
            new DW.EffectExtent { LeftEdge = 0L, TopEdge = 0L, RightEdge = 0L, BottomEdge = 0L },
            new DW.DocProperties { Id = id, Name = name },
            new DW.NonVisualGraphicFrameDrawingProperties(new A.GraphicFrameLocks { NoChangeAspect = true }),
            new A.Graphic(
                new A.GraphicData(
                    new PIC.Picture(
                        new PIC.NonVisualPictureProperties(
                            new PIC.NonVisualDrawingProperties { Id = 0U, Name = name },
                            new PIC.NonVisualPictureDrawingProperties()),
                        new PIC.BlipFill(
                            new A.Blip { Embed = relationshipId, CompressionState = A.BlipCompressionValues.Print },
                            new A.Stretch(new A.FillRectangle())),
                        new PIC.ShapeProperties(
                            new A.Transform2D(new A.Offset { X = 0L, Y = 0L }, new A.Extents { Cx = cx, Cy = cy }),
                            new A.PresetGeometry(new A.AdjustValueList()) { Preset = A.ShapeTypeValues.Rectangle })))
                { Uri = "http://schemas.openxmlformats.org/drawingml/2006/picture" }))
        {
            DistanceFromTop = 0U,
            DistanceFromBottom = 0U,
            DistanceFromLeft = 0U,
            DistanceFromRight = 0U
        };

        var paraProps = new W.ParagraphProperties(new W.SpacingBetweenLines { Before = "0", After = spaceAfter.ToString() });
        return new W.Paragraph(paraProps, new W.Run(new W.Drawing(inline)));
    }
}
