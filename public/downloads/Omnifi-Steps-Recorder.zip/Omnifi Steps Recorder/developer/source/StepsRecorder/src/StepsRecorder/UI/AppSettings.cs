using System.Text.Json;
using StepsRecorder.Branding;

namespace StepsRecorder.UI;

/// <summary>
/// Small per-user settings file (%LOCALAPPDATA%\StepsRecorder\settings.json). Nothing else is persisted.
/// </summary>
public sealed class AppSettings
{
    /// <summary>Global shortcut Left Ctrl + Right Ctrl opens the recorder (default on).</summary>
    public bool HotkeyEnabled { get; set; } = true;

    /// <summary>Start minimized in the tray at sign-in so the shortcut always works (default on).</summary>
    public bool StartWithWindows { get; set; } = true;

    public bool FirstRunNoticeShown { get; set; }

    public static string FilePath =>
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "StepsRecorder", "settings.json");

    public static AppSettings Load()
    {
        try
        {
            if (File.Exists(FilePath))
                return JsonSerializer.Deserialize<AppSettings>(File.ReadAllText(FilePath)) ?? new AppSettings();
        }
        catch { /* corrupt or unreadable: fall back to defaults */ }
        return new AppSettings();
    }

    public void Save()
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(FilePath)!);
            File.WriteAllText(FilePath, JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true }));
        }
        catch { /* settings are a convenience; never fail the app over them */ }
    }
}

/// <summary>
/// Creates / removes the Windows shortcuts (.lnk) that start the app: a Startup-folder entry (background
/// tray mode) and an optional Desktop shortcut. Shortcuts point at the silent launcher through wscript.exe,
/// so they work under application-control policies. Uses the Windows Script Host COM object; no admin.
/// </summary>
public static class ShortcutManager
{
    public const string ShortcutName = OmnifiBrand.ProductName;

    public static string StartupShortcutPath =>
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Startup), ShortcutName + " (background).lnk");

    public static string DesktopShortcutPath =>
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory), ShortcutName + ".lnk");

    /// <summary>Finds "Start Steps Recorder.vbs" next to the app, or one folder up (the shipped layout).</summary>
    public static string? FindLauncher()
    {
        string baseDir = AppContext.BaseDirectory;
        foreach (string candidate in new[]
                 {
                     Path.Combine(baseDir, "Start Steps Recorder.vbs"),
                     Path.Combine(Path.GetFullPath(Path.Combine(baseDir, "..")), "Start Steps Recorder.vbs")
                 })
        {
            if (File.Exists(candidate)) return candidate;
        }
        return null;
    }

    public static bool StartupShortcutExists => File.Exists(StartupShortcutPath);
    public static bool DesktopShortcutExists => File.Exists(DesktopShortcutPath);

    public static void SetStartupShortcut(bool enabled)
    {
        if (enabled) CreateShortcut(StartupShortcutPath, "--tray", "Steps Recorder background listener for the Left Ctrl + Right Ctrl shortcut");
        else if (File.Exists(StartupShortcutPath)) File.Delete(StartupShortcutPath);
    }

    public static void SetDesktopShortcut(bool enabled)
    {
        if (enabled) CreateShortcut(DesktopShortcutPath, string.Empty, "Open Steps Recorder");
        else if (File.Exists(DesktopShortcutPath)) File.Delete(DesktopShortcutPath);
    }

    /// <summary>Target + arguments that start the app: the silent launcher when shipped, else the dotnet host + DLL.</summary>
    public static (string Target, string Arguments, string WorkDir) LaunchCommand(string appArgs = "")
    {
        string? launcher = FindLauncher();
        if (launcher != null)
        {
            return (Path.Combine(Environment.SystemDirectory, "wscript.exe"),
                    "\"" + launcher + "\"" + (appArgs.Length > 0 ? " " + appArgs : string.Empty),
                    Path.GetDirectoryName(launcher)!);
        }
        // Fallback (developer builds): run the DLL with the dotnet host that started this process.
        return (Environment.ProcessPath ?? "dotnet.exe",
                "\"" + Path.Combine(AppContext.BaseDirectory, "StepsRecorder.dll") + "\"" + (appArgs.Length > 0 ? " " + appArgs : string.Empty),
                AppContext.BaseDirectory);
    }

    /// <summary>Single command line used by Windows when relaunching a pinned taskbar item.</summary>
    public static string RelaunchCommandLine()
    {
        var (target, arguments, _) = LaunchCommand();
        return "\"" + target + "\" " + arguments;
    }

    private static void CreateShortcut(string lnkPath, string appArgs, string description)
    {
        var (target, arguments, workDir) = LaunchCommand(appArgs);

        Type? shellType = Type.GetTypeFromProgID("WScript.Shell")
            ?? throw new InvalidOperationException("Windows Script Host is not available.");
        dynamic shell = Activator.CreateInstance(shellType)!;
        dynamic shortcut = shell.CreateShortcut(lnkPath);
        shortcut.TargetPath = target;
        shortcut.Arguments = arguments;
        shortcut.WorkingDirectory = workDir;
        shortcut.Description = description;
        shortcut.WindowStyle = 7; // minimized (the launcher hides its own console anyway)
        string? icon = IconPath();
        if (icon != null) shortcut.IconLocation = icon + ",0";
        shortcut.Save();
    }

    /// <summary>Writes the app icon to the settings folder so shortcuts and the taskbar can reference it.</summary>
    public static string? IconPath()
    {
        try
        {
            string path = Path.Combine(Path.GetDirectoryName(AppSettings.FilePath)!, "StepsRecorder.ico");
            if (!File.Exists(path))
            {
                Directory.CreateDirectory(Path.GetDirectoryName(path)!);
                using Icon icon = OmnifiBrand.CreateAppIcon();
                using FileStream fs = File.Create(path);
                icon.Save(fs);
            }
            return path;
        }
        catch
        {
            return null;
        }
    }
}
