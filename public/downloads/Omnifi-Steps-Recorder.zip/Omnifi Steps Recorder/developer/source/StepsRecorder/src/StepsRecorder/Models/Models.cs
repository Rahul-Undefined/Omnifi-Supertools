namespace StepsRecorder.Models;

public enum MouseButton
{
    Left,
    Right,
    Middle
}

public enum SessionState
{
    Idle,
    Starting,
    Recording,
    Paused,
    Stopping,
    Stopped,
    Failed
}

public enum StepKind
{
    /// <summary>A mouse button press.</summary>
    Click,
    /// <summary>A press-drag-release that covered a visible distance: the user selected or marked an area.</summary>
    Selection
}

/// <summary>Raw click or drag as observed by the low-level mouse hook. Created on the hook (UI) thread; immutable.</summary>
public sealed record ClickEvent(
    int StepNumber,
    StepKind Kind,
    MouseButton Button,
    int X,
    int Y,
    DateTime WallTime,
    TimeSpan VideoOffset,
    WindowInfo Window,
    int EndX = 0,
    int EndY = 0)
{
    /// <summary>For selections: the dragged rectangle in screen coordinates (normalized).</summary>
    public Rectangle SelectionRect => Kind == StepKind.Selection
        ? Rectangle.FromLTRB(Math.Min(X, EndX), Math.Min(Y, EndY), Math.Max(X, EndX), Math.Max(Y, EndY))
        : Rectangle.Empty;
}

/// <summary>Top-level window under the cursor (or the foreground window as a fallback).</summary>
public sealed record WindowInfo(IntPtr Handle, string Title, string ProcessName, string ClassName)
{
    public static readonly WindowInfo Unknown = new(IntPtr.Zero, string.Empty, string.Empty, string.Empty);

    public string DisplayTitle => string.IsNullOrWhiteSpace(Title)
        ? (string.IsNullOrWhiteSpace(ProcessName) ? "Desktop" : ProcessName)
        : Title;
}

/// <summary>Accessible information about the UI element under the cursor, from Windows UI Automation.</summary>
public sealed record UiElementInfo(string Name, string ControlType, string AutomationId, string ClassName, string FrameworkId);

public sealed class StepRecord
{
    public required int StepNumber { get; init; }
    public StepKind Kind { get; init; } = StepKind.Click;
    /// <summary>For selections: end point of the drag (screen coordinates).</summary>
    public int EndX { get; init; }
    public int EndY { get; init; }
    public required DateTime WallTime { get; init; }
    public required TimeSpan VideoOffset { get; init; }
    public required MouseButton Button { get; init; }
    public required int X { get; init; }
    public required int Y { get; init; }
    public required string Description { get; init; }
    /// <summary>Path relative to the recording folder, forward slashes, e.g. screenshots/step-0001.png</summary>
    public required string ScreenshotRelativePath { get; init; }
    public required string ScreenshotFullPath { get; init; }
    public required int ScreenshotWidth { get; init; }
    public required int ScreenshotHeight { get; init; }
    public required WindowInfo Window { get; init; }
    public UiElementInfo? Element { get; init; }
    public string? Note { get; init; }
    public bool ScreenshotSaved { get; init; }
}

public sealed class RecordingResult
{
    public required string OutputFolder { get; init; }
    public required string ScreenshotsFolder { get; init; }
    public required string VideoPath { get; init; }
    public required bool VideoSucceeded { get; init; }
    public string? VideoError { get; init; }
    public required DateTime StartedAt { get; init; }
    public required DateTime EndedAt { get; init; }
    /// <summary>Recording time excluding pauses.</summary>
    public required TimeSpan ActiveDuration { get; init; }
    public required IReadOnlyList<StepRecord> Steps { get; init; }
    public required string CaptureDisplay { get; init; }
    public required string MachineName { get; init; }
    /// <summary>"None" or "Microphone".</summary>
    public string AudioMode { get; init; } = "None";
    public int ClickCount => Steps.Count(s => s.Kind == StepKind.Click);
    public int SelectionCount => Steps.Count(s => s.Kind == StepKind.Selection);
    public string? HtmlPath { get; set; }
    public string? DocxPath { get; set; }
    public string? SummaryPath { get; set; }
    public List<string> Warnings { get; } = new();
}
