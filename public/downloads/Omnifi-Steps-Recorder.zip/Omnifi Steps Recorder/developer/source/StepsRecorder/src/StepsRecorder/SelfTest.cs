using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;
using StepsRecorder.Describing;
using StepsRecorder.Models;
using StepsRecorder.Recording;

namespace StepsRecorder;

/// <summary>
/// Non-interactive end-to-end check: starts a real session (video + hook + screenshots + reports), opens a
/// small test window, injects a left, right and middle click on its button with SendInput, pauses/resumes,
/// stops, and verifies the outputs. Writes selftest-result.txt into the output root. Exit code 0 = pass.
/// </summary>
internal static class SelfTest
{
    public static int Run(string outputRoot, int seconds)
    {
        Directory.CreateDirectory(outputRoot);
        using var form = new SelfTestForm(outputRoot, seconds);
        Application.Run(form);
        return form.ExitCode;
    }

    private sealed class SelfTestForm : Form
    {
        private readonly string _outputRoot;
        private readonly int _seconds;
        private readonly StringBuilder _log = new();
        public int ExitCode { get; private set; } = 1;

        public SelfTestForm(string outputRoot, int seconds)
        {
            _outputRoot = outputRoot;
            _seconds = seconds;
            Text = "Steps Recorder self-test";
            Size = new Size(420, 120);
            StartPosition = FormStartPosition.Manual;
            Location = new Point(40, 40);
            Controls.Add(new Label { Text = "Self-test running. Please do not use the mouse for a few seconds.", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleCenter });
            Shown += async (_, _) => await RunAsync();
        }

        private void Log(string line)
        {
            _log.AppendLine(DateTime.Now.ToString("HH:mm:ss.fff") + "  " + line);
        }

        private async Task RunAsync()
        {
            RecordingSession? session = null;
            Form? target = null;
            var sw = Stopwatch.StartNew();
            try
            {
                Log("Self-test start. Output root: " + _outputRoot);
                session = new RecordingSession(_outputRoot, new ScreenRecorderLibVideoRecorder(), CompositeStepDescriber.CreateDefault(), Handle);
                session.StepCaptured += (_, s) => Log($"StepCaptured #{s.StepNumber}: {s.Description} (saved={s.ScreenshotSaved}, element={(s.Element == null ? "none" : s.Element.ControlType + "/" + s.Element.Name)})");
                session.Warning += (_, w) => Log("Warning: " + w);
                session.VideoFailed += (_, e) => Log("VideoFailed: " + e);

                await session.StartAsync();
                Log($"Session started in {sw.ElapsedMilliseconds} ms. Folder: {session.OutputFolder}");

                target = new Form
                {
                    Text = "Steps Recorder self-test target",
                    TopMost = true,
                    StartPosition = FormStartPosition.Manual,
                    Location = new Point(120, 200),
                    Size = new Size(380, 240),
                    FormBorderStyle = FormBorderStyle.FixedDialog,
                    ShowInTaskbar = false
                };
                var button = new Button { Text = "Self-test target button", Size = new Size(240, 60), Location = new Point(60, 70), Name = "SelfTestButton" };
                target.Controls.Add(button);
                target.Show();
                await Task.Delay(1200);

                Point center = button.PointToScreen(new Point(button.Width / 2, button.Height / 2));
                Point originalCursor = Cursor.Position;
                Log($"Injecting clicks at ({center.X}, {center.Y})");
                foreach (MouseButton b in new[] { MouseButton.Left, MouseButton.Right, MouseButton.Middle })
                {
                    SendClick(b, center);
                    await Task.Delay(900);
                }
                // Drag-select across the target window: expected to produce a click step + a selection step.
                Point dragEnd = new(center.X + 140, center.Y + 60);
                SendButton(MOUSEEVENTF_LEFTDOWN, center);
                await Task.Delay(150);
                foreach (int i in Enumerable.Range(1, 6))
                {
                    SendButton(MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE, new Point(center.X + (dragEnd.X - center.X) * i / 6, center.Y + (dragEnd.Y - center.Y) * i / 6));
                    await Task.Delay(60);
                }
                SendButton(MOUSEEVENTF_LEFTUP, dragEnd);
                await Task.Delay(900);
                Cursor.Position = originalCursor;

                session.Pause();
                Log("Paused; hook installed=" + session.State);
                await Task.Delay(700);
                session.Resume();
                Log("Resumed; state=" + session.State);

                int remaining = (int)Math.Max(500, _seconds * 1000 - sw.ElapsedMilliseconds);
                await Task.Delay(remaining);

                target.Close();
                target = null;

                RecordingResult result = await session.StopAsync();
                Log($"Stopped after {sw.ElapsedMilliseconds} ms total. Active duration {result.ActiveDuration}");
                Log("Output folder: " + result.OutputFolder);
                Log($"Video: succeeded={result.VideoSucceeded} path={result.VideoPath} size={(File.Exists(result.VideoPath) ? new FileInfo(result.VideoPath).Length : -1)} error={result.VideoError}");
                Log($"Steps: {result.Steps.Count}");
                foreach (var s in result.Steps)
                    Log($"  #{s.StepNumber} {s.Button} ({s.X},{s.Y}) offset={s.VideoOffset} saved={s.ScreenshotSaved} {s.ScreenshotWidth}x{s.ScreenshotHeight} :: {s.Description}" + (s.Note == null ? "" : " NOTE: " + s.Note));
                Log($"HTML: {result.HtmlPath} exists={File.Exists(result.HtmlPath ?? "")}");
                Log($"DOCX: {result.DocxPath} exists={File.Exists(result.DocxPath ?? "")}");
                Log($"Summary: {result.SummaryPath} exists={File.Exists(result.SummaryPath ?? "")}");
                foreach (var w in result.Warnings) Log("Result warning: " + w);

                bool pass = result.VideoSucceeded
                            && result.Steps.Count == 5
                            && result.Steps.All(s => s.ScreenshotSaved && File.Exists(s.ScreenshotFullPath))
                            && result.Steps.Select(s => s.Button).SequenceEqual(new[] { MouseButton.Left, MouseButton.Right, MouseButton.Middle, MouseButton.Left, MouseButton.Left })
                            && result.Steps.Select(s => s.Kind).SequenceEqual(new[] { StepKind.Click, StepKind.Click, StepKind.Click, StepKind.Click, StepKind.Selection })
                            && Math.Abs(result.Steps[4].EndX - result.Steps[4].X) >= 100
                            && File.Exists(result.HtmlPath ?? "") && File.Exists(result.DocxPath ?? "") && File.Exists(result.SummaryPath ?? "");
                Log("RESULT: " + (pass ? "PASS" : "FAIL"));
                ExitCode = pass ? 0 : 1;
            }
            catch (Exception ex)
            {
                Log("EXCEPTION: " + ex);
                Log("RESULT: FAIL");
                ExitCode = 2;
            }
            finally
            {
                try { target?.Close(); } catch { /* ignore */ }
                try { session?.Dispose(); } catch { /* ignore */ }
                try { File.WriteAllText(Path.Combine(_outputRoot, "selftest-result.txt"), _log.ToString()); } catch { /* ignore */ }
                Close();
            }
        }

        // ---- SendInput (used only by the self-test) ----

        [StructLayout(LayoutKind.Sequential)]
        private struct MOUSEINPUT
        {
            public int dx;
            public int dy;
            public uint mouseData;
            public uint dwFlags;
            public uint time;
            public IntPtr dwExtraInfo;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct INPUT
        {
            public uint type;
            public MOUSEINPUT mi;
        }

        [DllImport("user32.dll", SetLastError = true)]
        private static extern uint SendInput(uint nInputs, INPUT[] pInputs, int cbSize);

        private const uint INPUT_MOUSE = 0;
        private const uint MOUSEEVENTF_LEFTDOWN = 0x0002, MOUSEEVENTF_LEFTUP = 0x0004;
        private const uint MOUSEEVENTF_RIGHTDOWN = 0x0008, MOUSEEVENTF_RIGHTUP = 0x0010;
        private const uint MOUSEEVENTF_MIDDLEDOWN = 0x0020, MOUSEEVENTF_MIDDLEUP = 0x0040;

        private const uint MOUSEEVENTF_MOVE = 0x0001, MOUSEEVENTF_ABSOLUTE = 0x8000;

        /// <summary>Absolute move to <paramref name="p"/> (primary display) packed in the same batch as the button event, so a user moving the mouse cannot divert the click.</summary>
        private static MOUSEINPUT MoveTo(Point p)
        {
            Rectangle b = Screen.PrimaryScreen!.Bounds;
            int ax = (int)Math.Round((p.X - b.X) * 65535.0 / (b.Width - 1));
            int ay = (int)Math.Round((p.Y - b.Y) * 65535.0 / (b.Height - 1));
            return new MOUSEINPUT { dx = ax, dy = ay, dwFlags = MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE };
        }

        private static void SendButton(uint flag, Point at)
        {
            var inputs = new[]
            {
                new INPUT { type = INPUT_MOUSE, mi = MoveTo(at) },
                new INPUT { type = INPUT_MOUSE, mi = new MOUSEINPUT { dwFlags = flag } }
            };
            SendInput((uint)inputs.Length, inputs, Marshal.SizeOf<INPUT>());
        }

        private static void SendClick(MouseButton button, Point at)
        {
            (uint down, uint up) = button switch
            {
                MouseButton.Left => (MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP),
                MouseButton.Right => (MOUSEEVENTF_RIGHTDOWN, MOUSEEVENTF_RIGHTUP),
                _ => (MOUSEEVENTF_MIDDLEDOWN, MOUSEEVENTF_MIDDLEUP)
            };
            var inputs = new[]
            {
                new INPUT { type = INPUT_MOUSE, mi = MoveTo(at) },
                new INPUT { type = INPUT_MOUSE, mi = new MOUSEINPUT { dwFlags = down } },
                new INPUT { type = INPUT_MOUSE, mi = new MOUSEINPUT { dwFlags = up } }
            };
            SendInput((uint)inputs.Length, inputs, Marshal.SizeOf<INPUT>());
        }
    }
}
