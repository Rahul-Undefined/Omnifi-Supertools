using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Net;
using System.Text;
using System.Text.Json.Serialization;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using StepsRecorder.Branding;
using StepsRecorder.Models;
using StepsRecorder.Reporting;
using W = DocumentFormat.OpenXml.Wordprocessing;

namespace StepsRecorder.AI;

/// <summary>Structured SOP returned by the SOP service and rendered to .md / .html / .docx.</summary>
public sealed class SopDocument
{
    [JsonPropertyName("title")] public string Title { get; set; } = "Standard operating procedure";
    [JsonPropertyName("purpose")] public string Purpose { get; set; } = string.Empty;
    [JsonPropertyName("prerequisites")] public List<string> Prerequisites { get; set; } = new();
    [JsonPropertyName("steps")] public List<SopStep> Steps { get; set; } = new();
    [JsonPropertyName("tips")] public List<string> Tips { get; set; } = new();
}

public sealed class SopStep
{
    /// <summary>Recorded step numbers this instruction covers (several clicks may be merged into one instruction).</summary>
    [JsonPropertyName("sourceSteps")] public List<int> SourceSteps { get; set; } = new();
    [JsonPropertyName("instruction")] public string Instruction { get; set; } = string.Empty;
    [JsonPropertyName("detail")] public string Detail { get; set; } = string.Empty;
}

public sealed class SopResult
{
    public required SopDocument Document { get; init; }
    public string? MarkdownPath { get; init; }
    public string? HtmlPath { get; init; }
    public string? DocxPath { get; init; }
    public int ImagesSent { get; init; }
    public SopAllowance? Allowance { get; init; }
}

/// <summary>
/// Packages a finished recording (step facts + downscaled screenshots), sends it to the Omnifi SuperTools SOP
/// service, and writes sop.md, sop.html and sop.docx into the recording folder. The AI provider key lives on
/// the server; this app only carries the build-time service token.
/// </summary>
public static class SopGenerator
{
    public static async Task<SopResult> GenerateAsync(RecordingResult recording, string deviceId, IProgress<string>? progress, CancellationToken cancellationToken)
    {
        if (recording.Steps.Count == 0) throw new SopServiceException("No steps were recorded, so there is nothing to turn into an SOP.");

        progress?.Report("Preparing screenshots...");
        var steps = new List<object>();
        var images = new List<object>();
        foreach (StepRecord s in recording.Steps)
        {
            steps.Add(new
            {
                n = s.StepNumber,
                kind = s.Kind == StepKind.Selection ? "selection" : "click",
                button = s.Button.ToString().ToLowerInvariant(),
                x = s.X,
                y = s.Y,
                endX = s.Kind == StepKind.Selection ? s.EndX : (int?)null,
                endY = s.Kind == StepKind.Selection ? s.EndY : (int?)null,
                window = Trim(s.Window.DisplayTitle, 300),
                process = Trim(s.Window.ProcessName, 100),
                elementType = Trim(s.Element?.ControlType ?? string.Empty, 100),
                elementName = Trim(s.Element?.Name ?? string.Empty, 300),
                description = Trim(s.Description, 600)
            });
            if (images.Count < AppConfig.SopMaxImages && s.ScreenshotSaved && File.Exists(s.ScreenshotFullPath))
            {
                byte[]? jpeg = TryDownscale(s.ScreenshotFullPath);
                if (jpeg != null) images.Add(new { step = s.StepNumber, jpegBase64 = Convert.ToBase64String(jpeg) });
            }
        }

        var payload = new
        {
            recording = new
            {
                startedAt = recording.StartedAt.ToString("dd MMM yyyy HH:mm"),
                durationSeconds = Math.Round(recording.ActiveDuration.TotalSeconds, 1),
                steps
            },
            images,
            language = "English"
        };

        progress?.Report($"Asking the Omnifi AI service to write the SOP ({steps.Count} steps, {images.Count} screenshots). This can take a few minutes...");
        using var client = new SopServiceClient(deviceId);
        SopServiceResponse response = await client.GenerateViaJobAsync(payload, progress, cancellationToken).ConfigureAwait(false);
        SopDocument doc = response.Sop!;
        doc.Steps = doc.Steps.Where(x => !string.IsNullOrWhiteSpace(x.Instruction)).ToList();
        if (doc.Steps.Count == 0) throw new SopServiceException("The SOP came back without steps. Try again.");

        progress?.Report("Writing SOP files...");
        string md = Path.Combine(recording.OutputFolder, "sop.md");
        string html = Path.Combine(recording.OutputFolder, "sop.html");
        string docx = Path.Combine(recording.OutputFolder, "sop.docx");
        WriteMarkdown(md, doc, recording);
        WriteHtml(html, doc, recording);
        WriteDocx(docx, doc, recording);
        return new SopResult { Document = doc, MarkdownPath = md, HtmlPath = html, DocxPath = docx, ImagesSent = response.ImagesUsed, Allowance = response.Allowance };
    }

    private static string Trim(string s, int max) => s.Length <= max ? s : s[..max];

    private static byte[]? TryDownscale(string pngPath)
    {
        try
        {
            using var src = new Bitmap(pngPath);
            double scale = Math.Min(1.0, (double)AppConfig.SopImageMaxWidth / src.Width);
            int w = Math.Max(1, (int)Math.Round(src.Width * scale));
            int h = Math.Max(1, (int)Math.Round(src.Height * scale));
            using var dst = new Bitmap(w, h, PixelFormat.Format24bppRgb);
            using (Graphics g = Graphics.FromImage(dst))
            {
                g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                g.SmoothingMode = SmoothingMode.HighQuality;
                g.DrawImage(src, new Rectangle(0, 0, w, h));
            }
            ImageCodecInfo? jpeg = ImageCodecInfo.GetImageEncoders().FirstOrDefault(c => c.FormatID == ImageFormat.Jpeg.Guid);
            using var ms = new MemoryStream();
            if (jpeg != null)
            {
                using var ep = new EncoderParameters(1);
                ep.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, 72L);
                dst.Save(ms, jpeg, ep);
            }
            else
            {
                dst.Save(ms, ImageFormat.Jpeg);
            }
            return ms.ToArray();
        }
        catch
        {
            return null;
        }
    }

    // ------------------------------------------------------------------ writers

    private static Dictionary<int, StepRecord> Index(RecordingResult r) => r.Steps.ToDictionary(s => s.StepNumber);

    private static StepRecord? ScreenshotFor(SopStep step, Dictionary<int, StepRecord> index)
    {
        // The last merged recorded step best shows the result of the action.
        foreach (int n in step.SourceSteps.OrderByDescending(n => n))
            if (index.TryGetValue(n, out var rec) && rec.ScreenshotSaved) return rec;
        return null;
    }

    private static void WriteMarkdown(string path, SopDocument doc, RecordingResult r)
    {
        var index = Index(r);
        var sb = new StringBuilder();
        sb.AppendLine("# " + doc.Title);
        sb.AppendLine();
        sb.AppendLine("*" + OmnifiBrand.InternalUseNotice + ". Generated with AI from a Steps Recorder recording made " + r.StartedAt.ToString("dd MMM yyyy HH:mm") + "; review before use.*");
        sb.AppendLine();
        if (!string.IsNullOrWhiteSpace(doc.Purpose)) { sb.AppendLine("## Purpose"); sb.AppendLine(); sb.AppendLine(doc.Purpose); sb.AppendLine(); }
        if (doc.Prerequisites.Count > 0) { sb.AppendLine("## Before you start"); sb.AppendLine(); foreach (var p in doc.Prerequisites) sb.AppendLine("- " + p); sb.AppendLine(); }
        sb.AppendLine("## Procedure"); sb.AppendLine();
        int i = 1;
        foreach (var s in doc.Steps)
        {
            sb.AppendLine($"{i}. **{s.Instruction}**");
            if (!string.IsNullOrWhiteSpace(s.Detail)) sb.AppendLine("   " + s.Detail);
            var shot = ScreenshotFor(s, index);
            if (shot != null) { sb.AppendLine(); sb.AppendLine($"   ![Step {i}]({shot.ScreenshotRelativePath})"); }
            sb.AppendLine();
            i++;
        }
        if (doc.Tips.Count > 0) { sb.AppendLine("## Tips"); sb.AppendLine(); foreach (var t in doc.Tips) sb.AppendLine("- " + t); sb.AppendLine(); }
        File.WriteAllText(path, sb.ToString(), new UTF8Encoding(false));
    }

    private static void WriteHtml(string path, SopDocument doc, RecordingResult r)
    {
        var index = Index(r);
        string E(string? s) => WebUtility.HtmlEncode(s ?? string.Empty);
        var sb = new StringBuilder();
        sb.AppendLine("<!DOCTYPE html><html lang=\"en\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">");
        sb.AppendLine("<title>" + E(doc.Title) + " | Omnifi</title><style>");
        sb.AppendLine(":root{--navy:" + OmnifiBrand.Hex_DeepNavy + ";--indigo:" + OmnifiBrand.Hex_IndigoBright + ";--lavender:" + OmnifiBrand.Hex_Lavender + ";--off:" + OmnifiBrand.Hex_OffWhite + ";--body:" + OmnifiBrand.Hex_BodyNavy + ";--muted:" + OmnifiBrand.Hex_MutedIndigo + ";}");
        sb.AppendLine("*{box-sizing:border-box} body{font-family:'Segoe UI',Arial,sans-serif;margin:0;background:var(--off);color:var(--body);font-size:15px;line-height:1.55} .wrap{max-width:1100px;margin:0 auto;padding:28px 32px 48px}");
        sb.AppendLine("header{display:flex;align-items:center;justify-content:space-between;padding-bottom:14px;border-bottom:1px solid var(--navy);margin-bottom:24px} header h1{margin:0;font-size:26px;color:var(--navy)} header h1 .dot{color:var(--indigo)} header .sub{color:var(--muted);font-size:13px;text-align:right}");
        sb.AppendLine("h2{font-size:18px;color:var(--navy);margin:28px 0 6px} h2 .dot{color:var(--indigo)} .rule{height:2px;width:64px;background:var(--indigo);margin-bottom:14px}");
        sb.AppendLine(".callout{border-left:4px solid var(--indigo);background:#fff;color:var(--navy);font-weight:600;padding:12px 16px;border-radius:0 8px 8px 0;margin-bottom:20px}");
        sb.AppendLine("ol.steps{list-style:none;padding:0;margin:0;counter-reset:s} ol.steps li{background:#fff;border-radius:10px;padding:18px 20px 18px 70px;margin-bottom:16px;position:relative;box-shadow:0 1px 2px rgba(10,15,61,.06)}");
        sb.AppendLine("ol.steps li::before{counter-increment:s;content:counter(s);position:absolute;left:20px;top:16px;width:34px;height:34px;border-radius:17px;background:var(--indigo);color:#fff;font-weight:700;display:flex;align-items:center;justify-content:center}");
        sb.AppendLine(".ins{font-weight:700;color:var(--navy);font-size:16px} .det{margin-top:4px} .src{color:var(--muted);font-size:12px;margin-top:6px} ol.steps img{max-width:100%;border:1px solid #DADCF0;border-radius:6px;margin-top:12px;display:block}");
        sb.AppendLine("ul{margin:0;padding-left:20px} footer{margin-top:40px;border-top:1px solid var(--navy);padding-top:10px;display:flex;justify-content:space-between;color:var(--muted);font-size:12px}");
        sb.AppendLine("</style></head><body><div class=\"wrap\">");
        sb.AppendLine("<header><div>" + OmnifiBrand.LogoSvg(34, false) + "</div><div><h1>" + E(doc.Title) + "<span class=\"dot\">&bull;</span></h1><div class=\"sub\">Standard operating procedure &middot; " + E(r.StartedAt.ToString("dd MMM yyyy")) + " &middot; " + E(OmnifiBrand.InternalUseNotice) + "</div></div></header>");
        sb.AppendLine("<div class=\"callout\">Generated with AI from a Steps Recorder recording (" + r.Steps.Count + " recorded actions, " + doc.Steps.Count + " procedure steps). Review for accuracy before sharing.</div>");
        if (!string.IsNullOrWhiteSpace(doc.Purpose)) sb.AppendLine("<h2>Purpose<span class=\"dot\">&bull;</span></h2><div class=\"rule\"></div><p>" + E(doc.Purpose) + "</p>");
        if (doc.Prerequisites.Count > 0) { sb.AppendLine("<h2>Before you start<span class=\"dot\">&bull;</span></h2><div class=\"rule\"></div><ul>"); foreach (var p in doc.Prerequisites) sb.AppendLine("<li>" + E(p) + "</li>"); sb.AppendLine("</ul>"); }
        sb.AppendLine("<h2>Procedure<span class=\"dot\">&bull;</span></h2><div class=\"rule\"></div><ol class=\"steps\">");
        foreach (var s in doc.Steps)
        {
            sb.Append("<li><div class=\"ins\">" + E(s.Instruction) + "</div>");
            if (!string.IsNullOrWhiteSpace(s.Detail)) sb.Append("<div class=\"det\">" + E(s.Detail) + "</div>");
            if (s.SourceSteps.Count > 0) sb.Append("<div class=\"src\">Recorded step" + (s.SourceSteps.Count == 1 ? "" : "s") + " " + string.Join(", ", s.SourceSteps) + "</div>");
            var shot = ScreenshotFor(s, index);
            if (shot != null) sb.Append("<a href=\"" + E(shot.ScreenshotRelativePath) + "\" target=\"_blank\"><img src=\"" + E(shot.ScreenshotRelativePath) + "\" alt=\"Screenshot\" loading=\"lazy\"></a>");
            sb.AppendLine("</li>");
        }
        sb.AppendLine("</ol>");
        if (doc.Tips.Count > 0) { sb.AppendLine("<h2>Tips<span class=\"dot\">&bull;</span></h2><div class=\"rule\"></div><ul>"); foreach (var t in doc.Tips) sb.AppendLine("<li>" + E(t) + "</li>"); sb.AppendLine("</ul>"); }
        sb.AppendLine("<footer><span>" + E(OmnifiBrand.InternalUseNotice) + ". AI-generated draft; verify before use.</span><span>" + E(DateTime.Now.ToString("dd MMM yyyy")) + "</span></footer></div></body></html>");
        File.WriteAllText(path, sb.ToString(), new UTF8Encoding(false));
    }

    private static void WriteDocx(string path, SopDocument doc, RecordingResult r)
    {
        var index = Index(r);
        using var wd = WordprocessingDocument.Create(path, WordprocessingDocumentType.Document);
        MainDocumentPart main = wd.AddMainDocumentPart();
        main.Document = new W.Document();
        var body = main.Document.AppendChild(new W.Body());
        uint imageId = 1;

        HeaderPart headerPart = main.AddNewPart<HeaderPart>();
        string headerId = main.GetIdOfPart(headerPart);
        headerPart.Header = DocxReportWriter.BuildHeader(headerPart, ref imageId, "Standard operating procedure");
        headerPart.Header.Save();
        FooterPart footerPart = main.AddNewPart<FooterPart>();
        string footerId = main.GetIdOfPart(footerPart);
        footerPart.Footer = DocxReportWriter.BuildFooter(DateTime.Now);
        footerPart.Footer.Save();

        body.Append(DocxReportWriter.Paragraph(doc.Title, bold: true, sizeHalfPoints: 40, color: DocxReportWriter.Navy, spaceAfter: 60, dot: true));
        body.Append(DocxReportWriter.Paragraph($"Standard operating procedure generated with AI from a Steps Recorder recording made {r.StartedAt:dd MMM yyyy HH:mm}. Review for accuracy before sharing.", sizeHalfPoints: 20, color: DocxReportWriter.Muted, spaceAfter: 200));

        if (!string.IsNullOrWhiteSpace(doc.Purpose))
        {
            body.Append(DocxReportWriter.SectionHeading("Purpose"));
            body.Append(DocxReportWriter.Paragraph(doc.Purpose, sizeHalfPoints: 22));
        }
        if (doc.Prerequisites.Count > 0)
        {
            body.Append(DocxReportWriter.SectionHeading("Before you start"));
            foreach (var p in doc.Prerequisites) body.Append(DocxReportWriter.Paragraph("•  " + p, sizeHalfPoints: 22, spaceAfter: 60));
        }

        body.Append(DocxReportWriter.SectionHeading("Procedure"));
        int i = 1;
        foreach (var s in doc.Steps)
        {
            body.Append(DocxReportWriter.StepHeading(i, s.Instruction));
            if (!string.IsNullOrWhiteSpace(s.Detail)) body.Append(DocxReportWriter.Paragraph(s.Detail, sizeHalfPoints: 22, spaceAfter: 60, keepNext: true));
            if (s.SourceSteps.Count > 0) body.Append(DocxReportWriter.Paragraph("Recorded step" + (s.SourceSteps.Count == 1 ? "" : "s") + " " + string.Join(", ", s.SourceSteps), sizeHalfPoints: 16, color: DocxReportWriter.Muted, spaceAfter: 60, keepNext: true));
            var shot = ScreenshotFor(s, index);
            if (shot != null && File.Exists(shot.ScreenshotFullPath) && shot.ScreenshotWidth > 0)
            {
                try
                {
                    ImagePart ip = main.AddImagePart(ImagePartType.Png);
                    using (var fs = File.OpenRead(shot.ScreenshotFullPath)) ip.FeedData(fs);
                    body.Append(DocxReportWriter.ImageParagraph(main.GetIdOfPart(ip), imageId++, Path.GetFileName(shot.ScreenshotFullPath), shot.ScreenshotWidth, shot.ScreenshotHeight, DocxReportWriter.PageWidthEmu, DocxReportWriter.MaxImageHeightEmu, spaceAfter: 160));
                }
                catch (Exception ex)
                {
                    body.Append(DocxReportWriter.Paragraph("Screenshot could not be embedded: " + ex.Message, italic: true, sizeHalfPoints: 18, color: DocxReportWriter.Indigo));
                }
            }
            i++;
        }
        if (doc.Tips.Count > 0)
        {
            body.Append(DocxReportWriter.SectionHeading("Tips"));
            foreach (var t in doc.Tips) body.Append(DocxReportWriter.Paragraph("•  " + t, sizeHalfPoints: 22, spaceAfter: 60));
        }

        body.Append(new W.SectionProperties(
            new W.HeaderReference { Type = W.HeaderFooterValues.Default, Id = headerId },
            new W.FooterReference { Type = W.HeaderFooterValues.Default, Id = footerId },
            new W.PageSize { Width = 12240, Height = 15840 },
            new W.PageMargin { Top = 1500, Right = 1440, Bottom = 1300, Left = 1440, Header = 560, Footer = 560, Gutter = 0 }));
        main.Document.Save();
    }
}
