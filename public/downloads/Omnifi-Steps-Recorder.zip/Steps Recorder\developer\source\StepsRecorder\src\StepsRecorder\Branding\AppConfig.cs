namespace StepsRecorder.Branding;

/// <summary>
/// Build-time configuration set by the administrator. End users cannot change these values; they are
/// compiled into the app. To rotate the service token, change it here AND in the SuperTools server's
/// STEPS_RECORDER_TOKEN environment variable, then ship a new build.
/// </summary>
public static class AppConfig
{
    /// <summary>Omnifi SuperTools server that holds the AI key and writes SOPs for the recorder.</summary>
    public const string SopServiceBaseUrl = "https://omnifi-supertools.onrender.com";

    /// <summary>
    /// Shared app token identifying this build to the SOP service. It grants access only to the SOP endpoint,
    /// which enforces a per-computer allowance (5 SOPs per 5 hours) and team-wide pacing; the AI provider key
    /// itself never leaves the server.
    /// </summary>
    public const string SopServiceToken = "srt_5a4453dd341324d4983a2b68fb06dd09a8457a65208de0d9";

    /// <summary>Screenshots are downscaled to this width (JPEG) before upload. Smaller images make the AI answer faster.</summary>
    public const int SopImageMaxWidth = 1024;

    /// <summary>At most this many screenshots are uploaded per SOP (the server enforces its own cap too).</summary>
    public const int SopMaxImages = 24;

    /// <summary>How long the app keeps polling the server for a finished SOP before giving up.</summary>
    public static readonly TimeSpan SopMaxWait = TimeSpan.FromMinutes(12);
}
