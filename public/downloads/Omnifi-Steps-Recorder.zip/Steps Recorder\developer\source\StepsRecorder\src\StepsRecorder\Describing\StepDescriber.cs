using StepsRecorder.Models;

namespace StepsRecorder.Describing;

/// <summary>Everything a describer may look at for one click. The screenshot is the raw (un-annotated) capture.</summary>
public sealed class StepContext
{
    public required ClickEvent Click { get; init; }
    public required WindowInfo Window { get; init; }
    public UiElementInfo? Element { get; init; }
    /// <summary>Raw capture; available for future local OCR / vision describers. Do not dispose.</summary>
    public Bitmap? Screenshot { get; init; }
    /// <summary>Click location in screenshot pixel coordinates, or null when the click was outside the captured display.</summary>
    public Point? ScreenshotPoint { get; init; }
}

/// <summary>
/// Produces the human-readable description of a step. Implementations must be thread-safe and must not
/// call any remote service. To add richer local descriptions later (OCR of the region around the click,
/// a local vision model, app-specific heuristics) implement this interface and register it in
/// <see cref="CompositeStepDescriber"/> ahead of the baseline.
/// </summary>
public interface IStepDescriber
{
    /// <summary>Returns a description, or null to let the next describer try.</summary>
    string? TryDescribe(StepContext context);
}

/// <summary>Runs describers in order; the first non-empty answer wins; the baseline always answers.</summary>
public sealed class CompositeStepDescriber : IStepDescriber
{
    private readonly IReadOnlyList<IStepDescriber> _describers;

    public CompositeStepDescriber(params IStepDescriber[] describers)
    {
        var list = new List<IStepDescriber>(describers);
        if (list.Count == 0 || list[^1] is not HeuristicStepDescriber) list.Add(new HeuristicStepDescriber());
        _describers = list;
    }

    public static CompositeStepDescriber CreateDefault() => new(new HeuristicStepDescriber());

    public string? TryDescribe(StepContext context)
    {
        foreach (var d in _describers)
        {
            try
            {
                string? text = d.TryDescribe(context);
                if (!string.IsNullOrWhiteSpace(text)) return text;
            }
            catch
            {
                // A faulty describer must never break the recording.
            }
        }
        return HeuristicStepDescriber.Fallback(context);
    }
}

/// <summary>
/// Reliable local baseline: window title + process, click button and location, and the accessible
/// control name/type from UI Automation when available.
/// </summary>
public sealed class HeuristicStepDescriber : IStepDescriber
{
    public string? TryDescribe(StepContext context)
    {
        var click = context.Click;
        if (click.Kind == StepKind.Selection) return DescribeSelection(context);
        string verb = Verb(click.Button);
        string where = $"at ({click.X}, {click.Y})";
        string window = WindowPhrase(context.Window);

        UiElementInfo? el = context.Element;
        if (el != null && (!string.IsNullOrWhiteSpace(el.Name) || !string.IsNullOrWhiteSpace(el.ControlType)))
        {
            string type = string.IsNullOrWhiteSpace(el.ControlType) ? "element" : el.ControlType;
            string target = string.IsNullOrWhiteSpace(el.Name) ? $"a {type}" : $"{type} \"{el.Name}\"";
            return $"{verb} {target} {where} in {window}";
        }

        return Fallback(context);
    }

    public static string Fallback(StepContext context)
    {
        var click = context.Click;
        if (click.Kind == StepKind.Selection) return DescribeSelection(context);
        return $"{Verb(click.Button)} at ({click.X}, {click.Y}) in {WindowPhrase(context.Window)}";
    }

    /// <summary>Drag selections: "Selected an area ... from (x1, y1) to (x2, y2) (W x H px) in window, starting on element".</summary>
    private static string DescribeSelection(StepContext context)
    {
        var click = context.Click;
        Rectangle r = click.SelectionRect;
        string how = click.Button switch
        {
            MouseButton.Left => "Selected / marked an area",
            MouseButton.Right => "Dragged with the right button",
            _ => "Dragged with the middle button"
        };
        string text = $"{how} from ({click.X}, {click.Y}) to ({click.EndX}, {click.EndY}), {r.Width} x {r.Height} px, in {WindowPhrase(context.Window)}";
        UiElementInfo? el = context.Element;
        if (el != null && !string.IsNullOrWhiteSpace(el.Name))
        {
            string type = string.IsNullOrWhiteSpace(el.ControlType) ? "element" : el.ControlType;
            text += $", starting on {type} \"{el.Name}\"";
        }
        return text;
    }

    private static string Verb(MouseButton button) => button switch
    {
        MouseButton.Left => "Clicked",
        MouseButton.Right => "Right-clicked",
        _ => "Middle-clicked"
    };

    private static string WindowPhrase(WindowInfo w)
    {
        string title = w.DisplayTitle;
        if (!string.IsNullOrWhiteSpace(w.ProcessName) && !title.Equals(w.ProcessName, StringComparison.OrdinalIgnoreCase))
            return $"\"{title}\" ({w.ProcessName}.exe)";
        return $"\"{title}\"";
    }
}
