using System.Diagnostics;
using StepsRecorder.Models;
using StepsRecorder.Native;

namespace StepsRecorder.Describing;

/// <summary>Cheap Win32 lookups of the top-level window under a point. Safe to call from the hook thread.</summary>
public static class WindowInspector
{
    public static IntPtr GetRootWindowAt(int x, int y)
    {
        IntPtr hwnd = NativeMethods.WindowFromPoint(new NativeMethods.POINT { X = x, Y = y });
        if (hwnd == IntPtr.Zero) return IntPtr.Zero;
        IntPtr root = NativeMethods.GetAncestor(hwnd, NativeMethods.GA_ROOT);
        return root == IntPtr.Zero ? hwnd : root;
    }

    public static WindowInfo Describe(IntPtr root)
    {
        if (root == IntPtr.Zero) return WindowInfo.Unknown;
        string title = NativeMethods.GetWindowTitle(root);
        string className = NativeMethods.GetWindowClassName(root);
        string processName = string.Empty;
        try
        {
            NativeMethods.GetWindowThreadProcessId(root, out uint pid);
            if (pid != 0)
            {
                using var p = Process.GetProcessById((int)pid);
                processName = p.ProcessName;
            }
        }
        catch
        {
            // Access denied for protected processes, or the process exited; leave empty.
        }
        return new WindowInfo(root, title, processName, className);
    }

    /// <summary>Window under the point, falling back to the foreground window.</summary>
    public static WindowInfo GetWindowAt(int x, int y)
    {
        IntPtr root = GetRootWindowAt(x, y);
        if (root == IntPtr.Zero) root = NativeMethods.GetForegroundWindow();
        return Describe(root);
    }
}
