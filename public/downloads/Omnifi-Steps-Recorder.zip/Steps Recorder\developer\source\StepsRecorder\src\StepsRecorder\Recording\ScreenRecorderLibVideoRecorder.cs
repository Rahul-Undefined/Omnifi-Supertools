using ScreenRecorderLib;

namespace StepsRecorder.Recording;

/// <summary>
/// MP4 (H.264) recording of the primary display using ScreenRecorderLib 7.x (MIT), which uses
/// Windows Graphics Capture / Desktop Duplication for frames and Media Foundation for encoding.
///
/// Mouse pointer and click highlighting in the video are provided natively by the library
/// (MouseOptions). Note the library highlights left and right clicks only; middle clicks are
/// highlighted in screenshots and the report but not in the video.
/// </summary>
public sealed class ScreenRecorderLibVideoRecorder : IVideoRecorder
{
    private static readonly TimeSpan StartTimeout = TimeSpan.FromSeconds(20);
    private static readonly TimeSpan StopTimeout = TimeSpan.FromSeconds(60);

    private readonly object _gate = new();
    private Recorder? _recorder;
    private string _outputPath = string.Empty;
    private TaskCompletionSource<bool>? _started;
    private TaskCompletionSource<VideoResult>? _completed;
    private bool _disposed;

    public event EventHandler<string>? Failed;

    /// <summary>When true, the default microphone is recorded into the MP4 (opt-in; system audio is never captured).</summary>
    public bool RecordMicrophone { get; init; }

    public static RecorderOptions BuildOptions(bool recordMicrophone = false)
    {
        var audio = new AudioOptions
        {
            // No audio unless the user explicitly opted in to voice narration. System/loopback audio is never captured.
            IsAudioEnabled = recordMicrophone,
            Bitrate = AudioBitrate.bitrate_128kbps,
            Channels = AudioChannels.Mono
        };
        if (recordMicrophone) audio.AudioSources.Add(CaptureAudioSource.Default);

        return new RecorderOptions
        {
            // Primary display only (see README for multi-monitor notes).
            SourceOptions = SourceOptions.MainMonitor,
            OutputOptions = new OutputOptions
            {
                RecorderMode = RecorderMode.Video,
                Stretch = StretchMode.Uniform
            },
            AudioOptions = audio,
            VideoEncoderOptions = new VideoEncoderOptions
            {
                Framerate = 30,
                Bitrate = 8000 * 1000,
                IsFixedFramerate = false,
                IsHardwareEncodingEnabled = true,
                IsLowLatencyEnabled = false,
                IsMp4FastStartEnabled = true,
                IsFragmentedMp4Enabled = false,
                IsThrottlingDisabled = false,
                Encoder = new H264VideoEncoder
                {
                    BitrateMode = H264BitrateControlMode.CBR,
                    EncoderProfile = H264Profile.Main
                }
            },
            MouseOptions = new MouseOptions
            {
                IsMousePointerEnabled = true,
                IsMouseClicksDetected = true,
                // Brand palette: Indigo Bright for left clicks, Deep Navy for right clicks.
                MouseLeftClickDetectionColor = "#4F5BD5",
                MouseRightClickDetectionColor = "#0A0F3D",
                MouseClickDetectionRadius = 28,
                MouseClickDetectionDuration = 250,
                // Polling does not install another system hook and does not affect mouse responsiveness.
                MouseClickDetectionMode = MouseDetectionMode.Polling
            },
            LogOptions = new LogOptions
            {
                IsLogEnabled = false
            }
        };
    }

    public async Task StartAsync(string outputPath, CancellationToken cancellationToken)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);
        if (_recorder != null) throw new InvalidOperationException("Recorder already started.");

        _outputPath = outputPath;
        _started = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
        _completed = new TaskCompletionSource<VideoResult>(TaskCreationOptions.RunContinuationsAsynchronously);

        Recorder recorder;
        try
        {
            recorder = CreateRecorderCore();
        }
        catch (Exception ex) when (ex is FileLoadException or FileNotFoundException or DllNotFoundException or BadImageFormatException or TypeLoadException)
        {
            throw new VideoRecorderException(
                "The screen recording component (ScreenRecorderLib.dll) could not be loaded. Make sure the Visual C++ 2015-2022 Redistributable (x64) is installed " +
                "and that the application is installed in a short path (under 260 characters).", ex);
        }
        catch (Exception ex)
        {
            throw new VideoRecorderException(
                "Could not initialize the screen recorder. Make sure the Visual C++ Redistributable (x64) and Media Foundation are installed.", ex);
        }

        recorder.OnStatusChanged += OnStatusChanged;
        recorder.OnRecordingComplete += OnRecordingComplete;
        recorder.OnRecordingFailed += OnRecordingFailed;
        lock (_gate) { _recorder = recorder; }

        try
        {
            recorder.Record(outputPath);
        }
        catch (Exception ex)
        {
            Cleanup();
            throw new VideoRecorderException("The screen recorder could not start: " + ex.Message, ex);
        }

        using var timeoutCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        timeoutCts.CancelAfter(StartTimeout);
        Task completed = await Task.WhenAny(_started.Task, Task.Delay(Timeout.Infinite, timeoutCts.Token)).ConfigureAwait(false);
        if (completed != _started.Task)
        {
            await AbortAsync().ConfigureAwait(false);
            if (cancellationToken.IsCancellationRequested) throw new OperationCanceledException(cancellationToken);
            throw new VideoRecorderException("The screen recorder did not start within 20 seconds.");
        }

        await _started.Task.ConfigureAwait(false); // rethrows a startup failure
    }

    /// <summary>
    /// Kept out of line so that the ScreenRecorderLib assembly is first resolved inside the try/catch in
    /// <see cref="StartAsync"/> (assembly load failures surface when the referencing method is JIT-compiled).
    /// </summary>
    [System.Runtime.CompilerServices.MethodImpl(System.Runtime.CompilerServices.MethodImplOptions.NoInlining)]
    private Recorder CreateRecorderCore() => Recorder.CreateRecorder(BuildOptions(RecordMicrophone));

    public void Pause()
    {
        Recorder? r;
        lock (_gate) { r = _recorder; }
        if (r != null && r.Status == RecorderStatus.Recording) r.Pause();
    }

    public void Resume()
    {
        Recorder? r;
        lock (_gate) { r = _recorder; }
        if (r != null && r.Status == RecorderStatus.Paused) r.Resume();
    }

    public async Task<VideoResult> StopAsync()
    {
        Recorder? r;
        TaskCompletionSource<VideoResult>? completed;
        lock (_gate) { r = _recorder; completed = _completed; }
        if (r == null || completed == null) return new VideoResult(false, _outputPath, "Recorder was not started.");

        try
        {
            if (r.Status != RecorderStatus.Idle) r.Stop();
        }
        catch (Exception ex)
        {
            completed.TrySetResult(new VideoResult(false, _outputPath, "Stop failed: " + ex.Message));
        }

        Task finished = await Task.WhenAny(completed.Task, Task.Delay(StopTimeout)).ConfigureAwait(false);
        VideoResult result = finished == completed.Task
            ? await completed.Task.ConfigureAwait(false)
            : new VideoResult(false, _outputPath, "Timed out waiting for the video file to be finalized.");

        Cleanup();
        return result;
    }

    private async Task AbortAsync()
    {
        try
        {
            Recorder? r;
            lock (_gate) { r = _recorder; }
            r?.Stop();
            if (_completed != null)
            {
                await Task.WhenAny(_completed.Task, Task.Delay(TimeSpan.FromSeconds(5))).ConfigureAwait(false);
            }
        }
        catch { /* best effort */ }
        finally
        {
            Cleanup();
        }
    }

    private void OnStatusChanged(object? sender, RecordingStatusEventArgs e)
    {
        if (e.Status == RecorderStatus.Recording) _started?.TrySetResult(true);
    }

    private void OnRecordingComplete(object? sender, RecordingCompleteEventArgs e)
    {
        _started?.TrySetResult(true);
        _completed?.TrySetResult(new VideoResult(true, string.IsNullOrEmpty(e.FilePath) ? _outputPath : e.FilePath, null));
    }

    private void OnRecordingFailed(object? sender, RecordingFailedEventArgs e)
    {
        string error = string.IsNullOrWhiteSpace(e.Error) ? "Unknown recorder error." : e.Error;
        bool wasStarted = _started?.Task.IsCompletedSuccessfully == true;
        _started?.TrySetException(new VideoRecorderException("The screen recorder failed to start: " + error));
        _completed?.TrySetResult(new VideoResult(false, _outputPath, error));
        if (wasStarted)
        {
            try { Failed?.Invoke(this, error); } catch { /* subscriber errors must not propagate into native callbacks */ }
        }
    }

    private void Cleanup()
    {
        Recorder? r;
        lock (_gate)
        {
            r = _recorder;
            _recorder = null;
        }
        if (r == null) return;
        try
        {
            r.OnStatusChanged -= OnStatusChanged;
            r.OnRecordingComplete -= OnRecordingComplete;
            r.OnRecordingFailed -= OnRecordingFailed;
        }
        catch { /* ignore */ }
        try { r.Dispose(); } catch { /* ignore */ }
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        Recorder? r;
        lock (_gate) { r = _recorder; }
        if (r != null)
        {
            try { if (r.Status != RecorderStatus.Idle) r.Stop(); } catch { /* ignore */ }
            Cleanup();
        }
    }
}

public sealed class VideoRecorderException : Exception
{
    public VideoRecorderException(string message) : base(message) { }
    public VideoRecorderException(string message, Exception inner) : base(message, inner) { }
}
