# "No-install" portable publish for locked-down machines (WDAC / AppLocker / Smart App Control).
#
# Produces a framework-dependent folder (StepsRecorder.dll + dependencies) that is launched through the
# Microsoft-signed dotnet.exe host (run.cmd). Unsigned StepsRecorder.exe is NOT needed, so application-control
# policies that only allow signed executables are satisfied. If the target has no .NET 8 Desktop Runtime
# installed, an unzipped runtime/SDK folder can be dropped next to the output as ".\dotnet" (no admin needed):
#   powershell -ExecutionPolicy Bypass -c "&([scriptblock]::Create((irm https://dot.net/v1/dotnet-install.ps1))) -Channel 8.0 -Runtime windowsdesktop -InstallDir <output>\dotnet -NoPath"
param([string]$Output = "$PSScriptRoot\..\publish\portable")
$ErrorActionPreference = "Stop"
$proj = Join-Path $PSScriptRoot "..\src\StepsRecorder\StepsRecorder.csproj"
dotnet publish $proj -c Release -r win-x64 --self-contained false -p:PublishSingleFile=false -o $Output
Copy-Item (Join-Path $PSScriptRoot "run.cmd") (Join-Path $Output "run.cmd") -Force
Copy-Item (Join-Path $PSScriptRoot "Start Steps Recorder.vbs") (Join-Path $Output "Start Steps Recorder.vbs") -Force
Write-Host "Published to $Output. Start with 'Start Steps Recorder.vbs' (silent) or run.cmd."
