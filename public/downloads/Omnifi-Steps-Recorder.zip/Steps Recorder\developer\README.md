# Steps Recorder (internal MVP)

A Windows-only desktop app, in the spirit of the classic Windows Steps Recorder, that additionally records the
screen as an MP4 video. After explicit consent it records the primary display, takes a full-screen PNG
screenshot at every left / right / middle click, describes each click as a readable step (window title,
accessible control name via UI Automation, button, coordinates), highlights clicks in the video and
screenshots, and writes an HTML report, a Word (.docx) report and a summary. Everything stays on the
local machine.

* C# / .NET 8, WinForms, `asInvoker` (no elevation), x64.
* Video: [ScreenRecorderLib](https://github.com/sskodje/ScreenRecorderLib) 7.0.1 (MIT).
* DOCX: [DocumentFormat.OpenXml](https://github.com/dotnet/Open-XML-SDK) 3.3.0 (MIT).
* No audio, no cloud, no telemetry, no analytics, no remote APIs, no background recording.

## Contents

- [Quick start](#quick-start)
- [Running on locked-down (office) machines without installing anything](#running-on-locked-down-office-machines-without-installing-anything)
- [Architecture](#architecture)
- [Privacy and security](#privacy-and-security)
- [Output layout](#output-layout)
- [Dependencies, licenses and prerequisites](#dependencies-licenses-and-prerequisites)
- [Multi-monitor behaviour](#multi-monitor-behaviour)
- [Limitations](#limitations)
- [Build](#build)
- [Packaging](#packaging)
- [Testing](#testing)

## Quick start

1. Start the app (double-click the launcher, or press **Left Ctrl + Right Ctrl** together). The window has
   a fixed size; the **Privacy notice** button shows what is and is not recorded.
2. Click **Choose folder...** and pick a local destination folder (required).
3. Click **Start recording**. After a 3-second countdown the window minimizes (optional) and capture begins. Work normally.
4. **Pause / Resume** as needed (the mouse hook is removed while paused; the video pauses too).
5. Click **Stop**. The video is finalized and the reports are generated.
6. Use **Open output folder**, double-click any artifact, **Show in Explorer**, or **Export ZIP**.

## Running on locked-down (office) machines without installing anything

Many corporate PCs enforce WDAC / AppLocker / Smart App Control, which refuse to run unsigned `.exe` files
from user folders ("Access is denied"). They do allow Microsoft-signed binaries, so the app can be launched
through the signed `dotnet.exe` host instead of its own EXE:

```
scripts\publish-portable.ps1                 # builds publish\portable\ (StepsRecorder.dll + deps + launchers)
publish\portable\Start Steps Recorder.vbs    # silent start via dotnet.exe, no console window
publish\portable\run.cmd                     # same, with a console (useful for --selftest)
```

## Quick open, voice, selections and countdown

* **Global shortcut (default on):** press **Left Ctrl + Right Ctrl together** anywhere to open Steps Recorder.
  Implemented in `UI/DoubleCtrlHotkey.cs` (`CtrlPairHotkey`) with a low-level keyboard hook that only
  checks whether the two Ctrl keys are held; every other key is passed through and ignored, nothing is
  stored or sent. So the shortcut always works, the app stays in the system tray when its window is closed
  and registers a Startup-folder entry (`Steps Recorder (background).lnk`, launched with `--tray`) on first
  run. Tray menu: Open, Shortcuts..., Exit. The `Shortcuts...` dialog turns the hotkey, the Startup entry
  and an optional Desktop shortcut on or off. Settings live in `%LOCALAPPDATA%\StepsRecorder\settings.json`.
  The app is single-instance: launching it again just brings the existing window to the front.
* **AI SOP (currently switched off):** `AppConfig.AiSopAvailable = false` hides the checkbox and the
  **Generate AI SOP** button and skips automatic generation, because the free-tier model regularly exceeded
  the service's 4-minute limit on screenshot-heavy recordings (October 2026). The code and the server
  endpoints remain in place; set the flag to true (and, if needed, `STEPS_RECORDER_MODEL` to a faster model
  or a paid tier) to bring it back. When enabled: after Stop (or on **Generate AI SOP**), `AI/SopGenerator.cs`
  packages the step facts (kind, button, coordinates, window title, process, UI element type/name, description)
  plus screenshots downscaled to 1024 px JPEG (at most 24) and posts them to the Omnifi SuperTools server
  (`AI/SopServiceClient.cs`). The call is asynchronous: `POST /api/steps-recorder/sop/start` answers at once
  with a job id and the app polls `GET /api/steps-recorder/sop/result` every 5 s (up to 12 minutes), so a
  slow model answer on the free tier can never hit an HTTP timeout. The older synchronous endpoint
  `/api/steps-recorder/sop` is kept for earlier builds. **The AI provider key never exists in the
  app**: the server (your Render deployment of omnifi-supertools) holds `GEMINI_API_KEY`, calls Gemini with a
  vision prompt and returns the SOP as JSON. The app identifies itself with a build-time token
  (`Branding/AppConfig.cs`, must equal the server's `STEPS_RECORDER_TOKEN`) and a random per-install device id;
  the server enforces **5 SOPs per 5 hours per computer** (`STEPS_RECORDER_QUOTA` / `STEPS_RECORDER_WINDOW_HOURS`)
  plus the team-wide free-tier pacing, and refunds the allowance when the provider fails. Users can only switch
  automatic generation on or off with the "Write AI SOP after recording" checkbox (the remaining allowance is
  shown in the activity log); nothing else is configurable and no key is visible or changeable. Output: `sop.docx`, `sop.html`, `sop.md` with title, purpose,
  prerequisites, numbered imperative instructions each with the relevant screenshot and the recorded step
  numbers it covers, plus tips. The privacy notice states that this feature sends recording data to the Omnifi
  server. The SOP is a draft to review. Honest caveat: the build-time token can be extracted from the binary by a
  determined user, but it only grants access to this one endpoint under the per-device quota; rotate it by
  changing both the env var and the constant and shipping a new build.
* **Omnifi SuperTools button:** the header carries an "Omnifi SuperTools" button (also in the tray menu) that
  opens https://omnifi-supertools.onrender.com/ in the default browser so users discover the other tools.
  It happens only on an explicit click and sends no recording data.
* **Taskbar identity / pinning:** because the process is the generic `dotnet.exe` host, the app sets an explicit
  AppUserModelID (`Omnifi.StepsRecorder`) and the window's relaunch command, display name and icon
  (`Native/TaskbarIdentity.cs`). Pinning the running app to the taskbar therefore produces a "Steps Recorder"
  pin with the Omnifi "ö" icon that starts the silent launcher, instead of a ".NET" pin that launches dotnet.exe.
  A pin created before this change must be unpinned and pinned again.
* **Voice narration (opt-in):** tick "Record my voice (microphone)" before Start to add the default
  microphone to the MP4 (mono AAC, 128 kbps). System/loopback audio is never captured. Off by default.
* **Selections:** a press-drag-release longer than 12 px becomes a "Selection" step captured at release,
  with the dragged rectangle highlighted (translucent indigo box, handles, "#n Selection WxH" badge) and
  a description such as `Selected / marked an area from (x1, y1) to (x2, y2), 140 x 60 px, in "App",
  starting on button "Save"`. The initial press is still recorded as a click step.
* **Recorder never appears in its own recordings:** every window of the app (main window, floating recording
  bar, dialogs, countdown) is marked with `SetWindowDisplayAffinity(WDA_EXCLUDEFROMCAPTURE)`
  (`UI/CaptureExclusion.cs`), so the video and the GDI screenshots show what is behind it instead (verified
  in the self-test: the status window vanishes from the captured PNG). In addition, the session ignores
  clicks on any window owned by the recorder process, so pausing, stopping or opening the recorder never
  becomes a step. Requires Windows 10 2004+; on older builds the windows would simply be visible.
* **Floating recording bar:** while recording, a small always-on-top bar (`UI/RecordingBar.cs`, top-right,
  draggable, no focus stealing) shows the elapsed time and step count with Pause/Resume, Stop and Open
  buttons, so users do not have to locate the main window.
* **Countdown:** pressing Start shows a 3-second on-screen countdown (`UI/CountdownOverlay.cs`, no focus
  stealing) so the user can switch to the application to demonstrate; capture begins after it.

## Branding

The app, HTML and DOCX reports follow the Omnifi brand system (`src/StepsRecorder/Branding/OmnifiBrand.cs`):
Deep Navy header with the Omnifi logo top-left, Indigo Bright accents and brand dot after headlines, Lavender
subtitles, Off-White surfaces, Body Navy text, Segoe UI with bold headlines and sentence case. The logo is
embedded as vector path data and rendered on demand on a transparent background (no image files to ship).
Every report and the app footer carry the notice "Prepared for Omnifi internal use only". Click markers use
Indigo Bright (left), Deep Navy (right) and Accent Green (middle) as functional indicators.

If the .NET 8 Desktop Runtime is not installed, no admin install is needed either: unzip a runtime (or
SDK) into `publish\portable\dotnet\` with Microsoft's install script using `-InstallDir` and `-NoPath`
(see the comment in `scripts/publish-portable.ps1`); `run.cmd` picks it up automatically. This is exactly
how the project was built and tested here: the SDK was unzipped into a temp folder, nothing was installed
system-wide, and the app ran as `dotnet StepsRecorder.dll`.

Keep the install path short (well under 260 characters). The C++/CLI recorder assembly is loaded by the
native loader, which fails with "The filename or extension is too long" on very deep paths.

## Architecture

```
src/StepsRecorder/
  Program.cs                      entry point, global exception handlers (always remove the hook), --selftest
  UI/MainForm.cs                  WinForms UI: privacy notice, consent, folder picker, Start/Pause/Stop,
                                  live status, artifact list, Open folder / Open / Show in Explorer / Export ZIP
  Recording/RecordingSession.cs   orchestrator: folders, video, hook, screenshot pipeline, step list, reports
  Recording/MouseHook.cs          WH_MOUSE_LL hook (installed only while recording, removed on pause/stop/close/error)
  Recording/ScreenCapturer.cs     GDI full-screen capture of the primary display + cursor + click marker drawing
  Recording/IVideoRecorder.cs     abstraction over the MP4 recorder
  Recording/ScreenRecorderLibVideoRecorder.cs   ScreenRecorderLib wrapper (start/pause/resume/stop, failures)
  Describing/WindowInspector.cs   Win32: top-level window under the cursor, title, process, class
  Describing/UiAutomationInspector.cs  UI Automation element under the cursor (name, control type, id), time-boxed
  Describing/StepDescriber.cs     IStepDescriber + CompositeStepDescriber + HeuristicStepDescriber (baseline)
  Reporting/ReportGenerator.cs    writes all reports; SummaryWriter
  Reporting/HtmlReportWriter.cs   steps.html
  Reporting/DocxReportWriter.cs   steps.docx via Open XML (title, metadata table, numbered steps, scaled images)
  Export/ZipExporter.cs           ZIP copy of the recording folder (originals untouched)
  Models/Models.cs                ClickEvent, WindowInfo, UiElementInfo, StepRecord, RecordingResult
  Native/NativeMethods.cs         P/Invoke declarations
  SelfTest.cs                     non-interactive end-to-end check (--selftest), see Testing
```

### Threading model

| Thread | Work |
|---|---|
| UI thread | Owns the session. Hosts the low-level hook callback (a WH_MOUSE_LL hook needs a message loop). The callback only identifies the window under the cursor, assigns the step number and enqueues; it never captures or writes. The UI never blocks while the hook is installed (async/await everywhere), because Windows silently drops a hook whose callback stalls. |
| Capture thread (AboveNormal) | Takes the full-screen GDI screenshot as soon as a click is dequeued, nothing else. |
| Process thread | UI Automation lookup (time-boxed at 1.5 s), description, click marker, PNG save, step list update (under a lock), UI notification. |
| Recorder threads | ScreenRecorderLib raises its events on its own threads; they are marshalled to the UI with `SynchronizationContext`. |
| Report generation | Runs once on a thread-pool thread after both workers have drained, from an ordered snapshot of the step list. |

Step numbers are assigned on the hook thread with `Interlocked.Increment`, so file names
(`step-0001.png`, ...) are unique and in click order even if processing finishes out of order.

### Hook lifetime

Installed after the video recorder reports it is recording; removed on Pause, Stop, Abort, window close
(any choice), recorder failure, `Application.ThreadException`, `UnhandledException` and `ProcessExit`.
Clicks on the recorder's own window (e.g. the Stop button) are ignored. Capture never blocks input: the
callback enqueues and returns immediately.

### Step descriptions

`HeuristicStepDescriber` produces e.g.

```
Clicked button "Save" at (812, 440) in "Untitled - Notepad" (notepad.exe)
Right-clicked list item "Documents" at (233, 310) in "File Explorer" (explorer.exe)
Clicked at (1020, 600) in "Some Window"                       <- fallback without UIA data
```

To add richer local descriptions (OCR of the region around the click, a local vision model, app-specific
rules) implement `IStepDescriber` and register it in `CompositeStepDescriber` ahead of the baseline. The
`StepContext` already carries the raw screenshot bitmap, the click point, the window info and the UIA
element. No external AI service is used.

## Privacy and security

* Recording starts only after the user chooses a folder and presses **Start** (followed by a visible 3-second
  countdown). The full notice is one click away behind the **Privacy notice** button.
* All outputs are written to the user-chosen local folder only. The app makes no network calls of any
  kind (grep the sources: there is no `HttpClient`, socket or telemetry code; the only packages are the
  recorder and the Open XML SDK).
* No microphone or system audio is captured (`AudioOptions.IsAudioEnabled = false`).
* The prominent notice tells users to avoid passwords and private data while recording; the recorder
  cannot know what is sensitive on screen.
* Runs as a standard user (`asInvoker`); no services, drivers, scheduled tasks or registry changes.
* The low-level mouse hook only observes button-down events while recording and never alters input.

## Output layout

```
<chosen folder>\StepsRecording_YYYYMMDD_HHMMSS\
  screen.mp4            H.264 MP4, 30 fps, primary display, pointer + click highlights
  screenshots\
    step-0001.png       full-screen PNG at each click with cursor, ring, crosshair and "#n L/R/M" badge
    step-0002.png
  steps.html            report with metadata, numbered steps, timestamps, coordinates, UI element, images
  steps.docx            Word report (title, metadata table, numbered steps, timestamps, embedded scaled images)
  summary.txt           duration (excluding pauses), total clicks, file list, warnings
  master-screenshot.png every step screenshot stitched vertically at native resolution (lossless PNG), each
                        under a navy band with step number, description, click type, time and window
                        (`Reporting/MasterScreenshotWriter.cs`); split into master-screenshot-1.png, -2.png
                        when a part would exceed 30,000 px in height
```

A `StepsRecording_..._2` suffix is used if the folder already exists. **Export ZIP** writes
`StepsRecording_YYYYMMDD_HHMMSS.zip` next to the folder and never deletes anything. Paths with spaces are
handled with `Path.Combine` and quoted shell arguments throughout.

## Dependencies, licenses and prerequisites

| Component | Version | License | Notes |
|---|---|---|---|
| .NET 8 (Windows Desktop) | 8.0.x | MIT | WinForms UI. `UseWPF=true` is only there to reference the in-box `UIAutomationClient` / `UIAutomationTypes` / `WindowsBase` assemblies. |
| ScreenRecorderLib | 7.0.1 (pinned) | MIT | C++/CLI wrapper over Windows Graphics Capture / Desktop Duplication + Media Foundation. Native prerequisites on the target machine: **Visual C++ 2015-2022 Redistributable (x64)** and **Media Foundation** (present on normal Windows 10/11; on N/KN editions install the Media Feature Pack; on Windows Server add the Media Foundation feature). Windows 10 1903+ recommended. |
| DocumentFormat.OpenXml | 3.3.0 (pinned) | MIT | Pure managed. |

No other runtime dependencies. Windows UI Automation is part of Windows.

## Multi-monitor behaviour

* Video and screenshots capture the **primary display** only (`SourceOptions.MainMonitor` and
  `Screen.PrimaryScreen.Bounds`).
* Clicks on other displays are still logged as steps with their global coordinates, window title and UIA
  data; the screenshot shows the primary display without a marker and the step carries the note "Click
  occurred outside the primary display".
* The process is PerMonitorV2 DPI aware, so hook coordinates, screenshot pixels and video pixels agree
  even at 125 % / 150 % scaling. Mixed-DPI setups were not tested.
* Recording all displays would mean passing several `DisplayRecordingSource`s to ScreenRecorderLib and
  capturing `SystemInformation.VirtualScreen` for screenshots; this is a documented follow-up.

## Limitations

* Click highlighting in the video is done natively by ScreenRecorderLib for **left and right** buttons
  (red / blue pulse, 250 ms, radius 28 px). **Middle** clicks are not highlighted in the video, only in
  the screenshots and reports. The pointer itself is drawn in the video.
* Screenshots are taken on a worker thread a few tens of milliseconds after the click, not inside the hook
  (which would block input). Rapid successive clicks are queued and never lost, but the screenshot of a
  later click may be taken slightly later than ideal. UI Automation lookup happens after the screenshot and
  is time-boxed to 1.5 s; for unresponsive apps the step falls back to "Clicked at (X, Y) in [title]".
* Only mouse clicks create steps; keyboard activity, scrolling and drags are not recorded as steps (they
  are visible in the video).
* Protected content (DRM video, some secure desktops, UAC prompts) appears black or is skipped by Windows.
* Very long recordings: memory use is dominated by queued screenshots (about 4 bytes per pixel each);
  the queue is unbounded, which is fine for human click rates.
* The app window itself is visible in the recording unless minimized; by default it minimizes on Start.
* x64 only (ScreenRecorderLib ships x86/x64/ARM64 natives; only x64 is configured).
* Self-contained single-file publish works (verified) but produces a ~150 MB EXE because the WPF
  assemblies are included; it is refused by application-control policies that block unsigned EXEs.

## Build

Requires the .NET 8 SDK (8.0.4xx used here) and Windows 10/11 x64. No Visual Studio needed.

```bash
dotnet build StepsRecorder.sln -c Release
```

Run from the build output (framework-dependent):

```bash
dotnet src/StepsRecorder/bin/x64/Release/net8.0-windows/win-x64/StepsRecorder.dll
```

## Releasing to the team

The administrator's release script (kept outside the repo, `Temp\sr-dotnet8\ship.ps1`) builds from the short-path
mirror, runs the self-test, writes the user-friendly folder to `Documents\Screen Recorder`, restarts the background
listener, then zips that folder to `omnifi-supertools/public/downloads/Omnifi-Steps-Recorder.zip`, updates the
size/version line on the SuperTools Downloads page and pushes, so the website always offers the latest build.

## Packaging

Self-contained single-file EXE (no runtime needed on the target; see the WDAC note above):

```bash
dotnet publish src/StepsRecorder/StepsRecorder.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true
```

The project sets `IncludeAllContentForSelfExtract=true` because ScreenRecorderLib is a mixed-mode
(C++/CLI) assembly that must exist on disk; single-file bundles extract to
`%TEMP%\.net\StepsRecorder\<hash>\` on first start. The output is
`src/StepsRecorder/bin/x64/Release/net8.0-windows/win-x64/publish/StepsRecorder.exe`.

Portable, no-install, policy-friendly folder: `scripts\publish-portable.ps1` (see above).

## Testing

### What was validated in this environment (automated, non-interactive)

The whole pipeline was exercised end to end on a Windows 11 Pro 24H2 x64 machine with 1920x1200 primary
display using the built-in self-test (`StepsRecorder.exe --selftest <folder> 6`, or
`dotnet StepsRecorder.dll --selftest ...`). The self-test starts a real `RecordingSession`, records the
primary display, opens its own small test window, injects a left, right and middle click on its button with
`SendInput`, pauses and resumes, stops and checks the outputs. Result: **PASS**.

* Release build: 0 errors.
* Video: `screen.mp4` written (4.0 MB for ~5 s active time), valid `ftyp mp42` header, Windows reports
  length 00:00:05.
* Hook: three injected clicks produced exactly three steps, in order Left, Right, Middle, each with a
  1920x1200 PNG, correct coordinates and video offsets (1.44 s, 2.54 s, 3.64 s).
* Descriptions via UI Automation: `Clicked button "Self-test target button" at (309, 338) in
  "Steps Recorder self-test target" (dotnet.exe)` (and Right-/Middle-clicked variants).
* Click markers: inspected `step-0002.png`; the blue ring, white inner ring, crosshair, cursor and
  "#2 R" badge are drawn at the click point over the intact screen content.
* Pause/Resume: state transitions and hook removal/re-install succeeded; active duration excludes the
  pause (7.5 s wall clock, 5.06 s active).
* `steps.html`, `steps.docx` (3 embedded PNG parts) and `summary.txt` were produced.
* Single-file self-contained publish succeeded; launching the unsigned EXE on this office PC was refused
  by WDAC ("Access is denied"), which is a machine policy, not an app defect. The framework-dependent
  output launched through `dotnet.exe` ran the full self-test successfully.

Later additions, also validated non-interactively on the same machine: the self-test now injects a
drag as well and passes with 5 steps (3 clicks, the drag's press, 1 selection with a 140x60 px box);
starting with `--tray` leaves no visible window, creates the Startup entry, and an injected
Left Ctrl + Right Ctrl press brought the window up; the countdown overlay and the silent VBS launcher
were exercised by launching the app.

**Microphone recording was not validated** (no automated test records the microphone on purpose); it
uses ScreenRecorderLib's standard `CaptureAudioSource.Default` path and should be checked manually.

### Not validated here (needs a person at an interactive Windows desktop)

Clicking through the WinForms UI (consent gating, folder dialog, Start/Pause/Resume/Stop buttons, close
prompts), MP4 playback in a media player, opening the DOCX in Word, the ZIP export button, real-user
clicks in third-party apps, multi-monitor and mixed-DPI setups. Use the manual plan in
[TEST_PLAN.md](TEST_PLAN.md).
