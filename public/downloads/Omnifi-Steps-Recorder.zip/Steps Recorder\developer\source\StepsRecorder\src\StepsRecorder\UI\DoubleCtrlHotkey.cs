using System.ComponentModel;
using System.Runtime.InteropServices;
using StepsRecorder.Native;

namespace StepsRecorder.UI;

/// <summary>
/// Global shortcut: Left Ctrl + Right Ctrl pressed together. Detected system-wide with a low-level
/// keyboard hook.
///
/// Privacy: the callback only looks at whether the virtual-key code is Left Ctrl or Right Ctrl and tracks
/// whether each is currently held. Every other key is passed through untouched and ignored. No key codes
/// or characters are stored, logged or forwarded anywhere, and the hook never blocks or alters input.
/// The hook is installed only while the shortcut is enabled and removed when it is turned off or the
/// app exits.
/// </summary>
public sealed class CtrlPairHotkey : IDisposable
{
    public const string DisplayName = "Left Ctrl + Right Ctrl";

    private readonly SynchronizationContext _ui;
    private readonly int _uiThreadId;
    private NativeMethods.LowLevelMouseProc? _proc; // same signature as a keyboard proc
    private IntPtr _hook;
    private bool _leftHeld;
    private bool _rightHeld;
    private bool _fired;
    private bool _disposed;

    public CtrlPairHotkey()
    {
        _ui = SynchronizationContext.Current ?? throw new InvalidOperationException("Create on the UI thread.");
        _uiThreadId = Environment.CurrentManagedThreadId;
    }

    public bool IsInstalled => _hook != IntPtr.Zero;

    /// <summary>Raised on the UI thread once per simultaneous press of both Ctrl keys.</summary>
    public event EventHandler? Triggered;

    public void Install()
    {
        ObjectDisposedException.ThrowIf(_disposed, this);
        RunOnUi(() =>
        {
            if (_hook != IntPtr.Zero) return;
            _proc = Callback;
            _hook = NativeMethods.SetWindowsHookEx(NativeMethods.WH_KEYBOARD_LL, _proc, NativeMethods.GetModuleHandle(null), 0);
            if (_hook == IntPtr.Zero)
            {
                int err = Marshal.GetLastWin32Error();
                _proc = null;
                throw new Win32Exception(err, "Could not install the " + DisplayName + " shortcut listener.");
            }
        });
    }

    public void Uninstall()
    {
        RunOnUi(() =>
        {
            if (_hook == IntPtr.Zero) return;
            NativeMethods.UnhookWindowsHookEx(_hook);
            _hook = IntPtr.Zero;
            _proc = null;
            _leftHeld = _rightHeld = _fired = false;
        });
    }

    private void RunOnUi(Action a)
    {
        if (Environment.CurrentManagedThreadId == _uiThreadId) a();
        else _ui.Send(_ => a(), null);
    }

    private IntPtr Callback(int nCode, IntPtr wParam, IntPtr lParam)
    {
        if (nCode >= 0)
        {
            try
            {
                const long WM_KEYUP = 0x0101, WM_SYSKEYUP = 0x0105;
                long msg = wParam.ToInt64();
                bool down = msg == NativeMethods.WM_KEYDOWN || msg == NativeMethods.WM_SYSKEYDOWN;
                bool up = msg == WM_KEYUP || msg == WM_SYSKEYUP;
                if (down || up)
                {
                    var info = Marshal.PtrToStructure<NativeMethods.KBDLLHOOKSTRUCT>(lParam);
                    if (info.vkCode == NativeMethods.VK_LCONTROL) _leftHeld = down;
                    else if (info.vkCode == NativeMethods.VK_RCONTROL) _rightHeld = down;
                    else return NativeMethods.CallNextHookEx(_hook, nCode, wParam, lParam); // not a Ctrl key: ignore

                    if (_leftHeld && _rightHeld)
                    {
                        if (!_fired)
                        {
                            _fired = true;
                            _ui.Post(_ => Triggered?.Invoke(this, EventArgs.Empty), null);
                        }
                    }
                    else
                    {
                        _fired = false; // re-arm once either key is released
                    }
                }
            }
            catch
            {
                // never let an exception escape a system hook
            }
        }
        return NativeMethods.CallNextHookEx(_hook, nCode, wParam, lParam);
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        try { Uninstall(); } catch { /* best effort */ }
    }
}
