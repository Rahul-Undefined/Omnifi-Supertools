using System.Collections.Concurrent;
using System.Diagnostics;
using System.Drawing.Imaging;
using StepsRecorder.Describing;
using StepsRecorder.Models;
using StepsRecorder.Native;
using StepsRecorder.Reporting;

namespace StepsRecorder.Recording;

/// <summary>
/// Orchestrates one recording: video recorder, mouse hook, screenshot pipeline, step list and reports.
///
/// Threads involved:
///  * UI thread: owns the session (Start/Pause/Resume/Stop must be called here), hosts the hook callback,
///    which only enqueues a <see cref="ClickEvent"/>.
///  * Capture thread: takes the screenshot as soon as possible after each click (nothing else).
///  * Process thread: UI Automation lookup, description, click marker, PNG save, step list update.
///  * Recorder callbacks: ScreenRecorderLib raises events on its own threads; they are marshalled to the UI.
/// Reports are written only after both worker threads have drained, from a snapshot of the step list.
/// </summary>
public sealed class RecordingSession : IDisposable
{
    private readonly string _destinationRoot;
    private readonly IVideoRecorder _video;
    private readonly IStepDescriber _describer;
    private readonly IntPtr _ownWindow;

    /// <summary>
    /// When true (default), clicks on ANY window of this process (main window, floating recording bar, dialogs,
    /// tray menu, countdown) are ignored, so operating the recorder never creates steps. The self-test turns
    /// this off because its target window belongs to the same process.
    /// </summary>
    public bool IgnoreOwnProcessWindows { get; init; } = true;

    private bool IsOwnWindow(IntPtr root)
    {
        if (root == IntPtr.Zero) return false;
        if (root == _ownWindow) return true;
        if (!IgnoreOwnProcessWindows) return false;
        NativeMethods.GetWindowThreadProcessId(root, out uint pid);
        return pid == (uint)Environment.ProcessId;
    }
    private readonly SynchronizationContext _ui;
    private readonly int _uiThreadId;
    private readonly MouseHook _hook;
    private readonly ScreenCapturer _capturer = new();
    private readonly BlockingCollection<ClickEvent> _captureQueue = new();
    private readonly BlockingCollection<PendingCapture> _processQueue = new();
    private readonly List<StepRecord> _steps = new();
    private readonly object _stepsLock = new();
    private readonly List<string> _warnings = new();
    private readonly Stopwatch _clock = new();
    private Thread? _captureThread;
    private Thread? _processThread;
    private TimeSpan _pausedTotal;
    private TimeSpan _pauseStartedAt;
    private int _stepCounter;
    private volatile SessionState _state = SessionState.Idle;
    private DateTime _startedAt;
    private Rectangle _captureBounds;
    private bool _disposed;

    private sealed record PendingCapture(ClickEvent Click, Bitmap? Bitmap, Exception? CaptureError, Rectangle Bounds);

    /// <summary>Drags shorter than this (in pixels, either axis) are treated as plain clicks, not selections.</summary>
    public const int SelectionThresholdPx = 12;

    private readonly Dictionary<MouseButton, (int X, int Y, DateTime Time, bool OnOwnWindow)> _pendingDown = new();

    /// <summary>"None" or "Microphone"; recorded in the reports.</summary>
    public string AudioMode { get; init; } = "None";

    public RecordingSession(string destinationRoot, IVideoRecorder video, IStepDescriber describer, IntPtr ownWindow)
    {
        _destinationRoot = destinationRoot ?? throw new ArgumentNullException(nameof(destinationRoot));
        _video = video ?? throw new ArgumentNullException(nameof(video));
        _describer = describer ?? throw new ArgumentNullException(nameof(describer));
        _ownWindow = ownWindow;
        _ui = SynchronizationContext.Current
            ?? throw new InvalidOperationException("RecordingSession must be created on the UI thread.");
        _uiThreadId = Environment.CurrentManagedThreadId;
        _hook = new MouseHook();
    }

    public string OutputFolder { get; private set; } = string.Empty;
    public string ScreenshotsFolder { get; private set; } = string.Empty;
    public string VideoPath { get; private set; } = string.Empty;
    public SessionState State => _state;
    public int StepCount => Volatile.Read(ref _stepCounter);

    /// <summary>Elapsed recording time excluding pauses.</summary>
    public TimeSpan ActiveDuration =>
        _state == SessionState.Paused ? _pauseStartedAt - _pausedTotal : _clock.Elapsed - _pausedTotal;

    /// <summary>Raised on the UI thread after a step's screenshot and description are complete.</summary>
    public event EventHandler<StepRecord>? StepCaptured;

    /// <summary>Raised on the UI thread if the video recorder fails mid-recording. The hook is already removed.</summary>
    public event EventHandler<string>? VideoFailed;

    /// <summary>Raised on the UI thread for non-fatal problems (e.g. one screenshot failed).</summary>
    public event EventHandler<string>? Warning;

    public async Task StartAsync(CancellationToken cancellationToken = default)
    {
        EnsureUiThread();
        ObjectDisposedException.ThrowIf(_disposed, this);
        if (_state != SessionState.Idle) throw new InvalidOperationException("Session already started.");
        _state = SessionState.Starting;

        try
        {
            CreateOutputFolders();
            _captureBounds = _capturer.CaptureBounds;
            StartWorkers();

            _video.Failed += OnVideoFailed;
            await _video.StartAsync(VideoPath, cancellationToken); // continues on the UI context

            _startedAt = DateTime.Now;
            _clock.Restart();
            WarmUpHookPath();
            _hook.ButtonDown += OnButtonDown;
            _hook.ButtonUp += OnButtonUp;
            _hook.Install();
            _state = SessionState.Recording;
        }
        catch
        {
            _state = SessionState.Failed;
            SafeUnhook();
            try { await _video.StopAsync(); } catch { /* best effort */ }
            StopWorkers(join: false);
            throw;
        }
    }

    public void Pause()
    {
        EnsureUiThread();
        if (_state != SessionState.Recording) return;
        SafeUnhook();
        _pauseStartedAt = _clock.Elapsed;
        _state = SessionState.Paused;
        try { _video.Pause(); }
        catch (Exception ex) { AddWarning("Could not pause the video recorder: " + ex.Message); }
    }

    public void Resume()
    {
        EnsureUiThread();
        if (_state != SessionState.Paused) return;
        _pausedTotal += _clock.Elapsed - _pauseStartedAt;
        try { _video.Resume(); }
        catch (Exception ex) { AddWarning("Could not resume the video recorder: " + ex.Message); }
        _hook.Install();
        _state = SessionState.Recording;
    }

    public async Task<RecordingResult> StopAsync(bool generateReports = true)
    {
        EnsureUiThread();
        if (_state is not (SessionState.Recording or SessionState.Paused))
            throw new InvalidOperationException($"Cannot stop a session in state {_state}.");

        if (_state == SessionState.Paused) _pausedTotal += _clock.Elapsed - _pauseStartedAt;
        _state = SessionState.Stopping;
        SafeUnhook();
        _hook.ButtonDown -= OnButtonDown;
        _hook.ButtonUp -= OnButtonUp;

        TimeSpan active = _clock.Elapsed - _pausedTotal;
        _clock.Stop();
        DateTime endedAt = DateTime.Now;

        VideoResult videoResult;
        try
        {
            videoResult = await _video.StopAsync();
        }
        catch (Exception ex)
        {
            videoResult = new VideoResult(false, VideoPath, ex.Message);
        }
        _video.Failed -= OnVideoFailed;

        // Let the worker threads finish any screenshots still in flight (off the UI thread).
        await Task.Run(() => StopWorkers(join: true));

        List<StepRecord> steps;
        lock (_stepsLock) { steps = _steps.OrderBy(s => s.StepNumber).ToList(); }

        var result = new RecordingResult
        {
            OutputFolder = OutputFolder,
            ScreenshotsFolder = ScreenshotsFolder,
            VideoPath = VideoPath,
            VideoSucceeded = videoResult.Succeeded && File.Exists(VideoPath),
            VideoError = videoResult.Succeeded ? null : videoResult.Error,
            StartedAt = _startedAt,
            EndedAt = endedAt,
            ActiveDuration = active,
            Steps = steps,
            CaptureDisplay = _capturer.CaptureDisplayDescription,
            MachineName = Environment.MachineName,
            AudioMode = AudioMode
        };
        lock (_warnings) { result.Warnings.AddRange(_warnings); }

        if (generateReports)
        {
            await Task.Run(() => ReportGenerator.WriteAll(result));
        }

        _state = SessionState.Stopped;
        return result;
    }

    /// <summary>Stops everything without generating reports (used when the user discards a recording or on fatal errors).</summary>
    public void Abort()
    {
        if (_state is SessionState.Idle or SessionState.Stopped) return;
        _state = SessionState.Failed;
        SafeUnhook();
        try { _hook.ButtonDown -= OnButtonDown; _hook.ButtonUp -= OnButtonUp; } catch { /* ignore */ }
        try { _video.Failed -= OnVideoFailed; } catch { /* ignore */ }
        try { _video.Dispose(); } catch { /* ignore */ }
        StopWorkers(join: false);
    }

    /// <summary>
    /// JIT-compiles and initialises everything the hook callback touches BEFORE the hook is installed. A low-level
    /// hook whose first invocation is slow (JIT, time-zone initialisation, generic instantiation) can exceed the OS
    /// hook timeout, in which case Windows silently drops that mouse event; this was observed as a lost first click
    /// right after a build on a busy machine.
    /// </summary>
    private void WarmUpHookPath()
    {
        try
        {
            _ = DateTime.Now;
            _ = ActiveDuration;
            _ = WindowInspector.GetRootWindowAt(0, 0);
            _ = IsOwnWindow(IntPtr.Zero);
            _pendingDown[MouseButton.Left] = (0, 0, DateTime.Now, false);
            _pendingDown.Remove(MouseButton.Left);
            var probe = new ClickEvent(0, StepKind.Click, MouseButton.Left, 0, 0, DateTime.Now, TimeSpan.Zero, IntPtr.Zero, WindowInfo.Unknown);
            _ = probe with { Window = WindowInfo.Unknown };
            _ = probe.SelectionRect;
            unsafe
            {
                var raw = new NativeMethods.MSLLHOOKSTRUCT();
                _ = System.Runtime.InteropServices.Marshal.PtrToStructure<NativeMethods.MSLLHOOKSTRUCT>((IntPtr)(&raw));
            }
            foreach (string name in new[] { "OnButtonDown", "OnButtonUp", "Enqueue", "IsOwnWindow" })
            {
                var m = typeof(RecordingSession).GetMethod(name, System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
                if (m != null) System.Runtime.CompilerServices.RuntimeHelpers.PrepareMethod(m.MethodHandle);
            }
            var cb = typeof(MouseHook).GetMethod("HookCallback", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
            if (cb != null) System.Runtime.CompilerServices.RuntimeHelpers.PrepareMethod(cb.MethodHandle);
        }
        catch
        {
            // warm-up is best effort
        }
    }

    // ----- hook side (UI thread, must be fast) -----

    private void OnButtonDown(object? sender, MouseButtonDownEventArgs e)
    {
        if (_state != SessionState.Recording) return;

        IntPtr root = WindowInspector.GetRootWindowAt(e.X, e.Y);
        bool onOwnWindow = IsOwnWindow(root);
        _pendingDown[e.Button] = (e.X, e.Y, DateTime.Now, onOwnWindow);
        if (onOwnWindow) return; // ignore clicks on the recorder's own window
        if (root == IntPtr.Zero) root = NativeMethods.GetForegroundWindow();
        WindowInfo window = WindowInfo.Unknown; // title/process are resolved on the capture thread, keeping the hook callback fast

        int number = Interlocked.Increment(ref _stepCounter);
        var click = new ClickEvent(number, StepKind.Click, e.Button, e.X, e.Y, DateTime.Now, ActiveDuration, root, window);
        Enqueue(click);
    }

    /// <summary>
    /// A release far from its press is a drag: the user selected text, marked an area or moved something.
    /// It is recorded as its own "Selection" step, captured at release so the screenshot shows the selection.
    /// </summary>
    private void OnButtonUp(object? sender, MouseButtonDownEventArgs e)
    {
        if (!_pendingDown.Remove(e.Button, out var down)) return;
        if (_state != SessionState.Recording || down.OnOwnWindow) return;
        if (Math.Abs(e.X - down.X) < SelectionThresholdPx && Math.Abs(e.Y - down.Y) < SelectionThresholdPx) return;

        IntPtr root = WindowInspector.GetRootWindowAt(down.X, down.Y);
        if (root == IntPtr.Zero) root = NativeMethods.GetForegroundWindow();
        WindowInfo window = WindowInfo.Unknown; // title/process are resolved on the capture thread, keeping the hook callback fast

        int number = Interlocked.Increment(ref _stepCounter);
        var drag = new ClickEvent(number, StepKind.Selection, e.Button, down.X, down.Y, DateTime.Now, ActiveDuration, root, window, e.X, e.Y);
        Enqueue(drag);
    }

    private void Enqueue(ClickEvent ev)
    {
        try { _captureQueue.TryAdd(ev); }
        catch (InvalidOperationException) { /* queue already completed during stop */ }
    }

    // ----- workers -----

    private void StartWorkers()
    {
        _captureThread = new Thread(CaptureLoop) { Name = "StepsRecorder.Capture", IsBackground = true, Priority = ThreadPriority.AboveNormal };
        _processThread = new Thread(ProcessLoop) { Name = "StepsRecorder.Process", IsBackground = true };
        _captureThread.Start();
        _processThread.Start();
    }

    private void StopWorkers(bool join)
    {
        try { _captureQueue.CompleteAdding(); } catch { /* ignore */ }
        if (join)
        {
            _captureThread?.Join(TimeSpan.FromSeconds(30));
        }
        try { _processQueue.CompleteAdding(); } catch { /* ignore */ }
        if (join)
        {
            _processThread?.Join(TimeSpan.FromSeconds(60));
        }
    }

    private void CaptureLoop()
    {
        foreach (ClickEvent click in _captureQueue.GetConsumingEnumerable())
        {
            Bitmap? bitmap = null;
            Exception? error = null;
            try
            {
                bitmap = _capturer.CapturePrimaryScreen(includeCursor: true);
            }
            catch (Exception ex)
            {
                error = ex;
            }
            ClickEvent resolved = click with { Window = WindowInspector.Describe(click.RootWindow) };
            try { _processQueue.Add(new PendingCapture(resolved, bitmap, error, _captureBounds)); }
            catch (InvalidOperationException) { bitmap?.Dispose(); }
        }
        try { _processQueue.CompleteAdding(); } catch { /* ignore */ }
    }

    private void ProcessLoop()
    {
        foreach (PendingCapture pending in _processQueue.GetConsumingEnumerable())
        {
            try
            {
                ProcessCapture(pending);
            }
            catch (Exception ex)
            {
                pending.Bitmap?.Dispose();
                AddWarning($"Step {pending.Click.StepNumber}: processing failed: {ex.Message}");
            }
        }
    }

    private void ProcessCapture(PendingCapture pending)
    {
        ClickEvent click = pending.Click;
        string fileName = $"step-{click.StepNumber:0000}.png";
        string relativePath = "screenshots/" + fileName;
        string fullPath = Path.Combine(ScreenshotsFolder, fileName);

        Point? local = null;
        string? note = null;
        if (pending.Bounds.Contains(click.X, click.Y))
            local = new Point(click.X - pending.Bounds.X, click.Y - pending.Bounds.Y);
        else
            note = (click.Kind == StepKind.Selection ? "Selection started" : "Click occurred") +
                   " outside the primary display; the screenshot shows the primary display without a marker.";

        UiElementInfo? element = UiAutomationInspector.TryInspect(click.X, click.Y, TimeSpan.FromMilliseconds(1500));

        var context = new StepContext
        {
            Click = click,
            Window = click.Window,
            Element = element,
            Screenshot = pending.Bitmap,
            ScreenshotPoint = local
        };
        string description = _describer.TryDescribe(context) ?? HeuristicStepDescriber.Fallback(context);

        bool saved = false;
        int width = 0, height = 0;
        if (pending.Bitmap != null)
        {
            using Bitmap bitmap = pending.Bitmap;
            width = bitmap.Width;
            height = bitmap.Height;
            if (local.HasValue)
            {
                if (click.Kind == StepKind.Selection)
                {
                    Rectangle r = click.SelectionRect;
                    r.Offset(-pending.Bounds.X, -pending.Bounds.Y);
                    ScreenCapturer.DrawSelectionMarker(bitmap, r, click.StepNumber);
                }
                else
                {
                    ScreenCapturer.DrawClickMarker(bitmap, local.Value, click.Button, click.StepNumber);
                }
            }
            try
            {
                bitmap.Save(fullPath, ImageFormat.Png);
                saved = true;
            }
            catch (Exception ex)
            {
                note = AppendNote(note, "Screenshot could not be saved: " + ex.Message);
                AddWarning($"Step {click.StepNumber}: screenshot could not be saved: {ex.Message}");
            }
        }
        else
        {
            string reason = pending.CaptureError?.Message ?? "unknown error";
            note = AppendNote(note, "Screenshot capture failed: " + reason);
            AddWarning($"Step {click.StepNumber}: screenshot capture failed: {reason}");
        }

        var step = new StepRecord
        {
            StepNumber = click.StepNumber,
            Kind = click.Kind,
            EndX = click.EndX,
            EndY = click.EndY,
            WallTime = click.WallTime,
            VideoOffset = click.VideoOffset,
            Button = click.Button,
            X = click.X,
            Y = click.Y,
            Description = description,
            ScreenshotRelativePath = relativePath,
            ScreenshotFullPath = fullPath,
            ScreenshotWidth = width,
            ScreenshotHeight = height,
            Window = click.Window,
            Element = element,
            Note = note,
            ScreenshotSaved = saved
        };

        lock (_stepsLock) { _steps.Add(step); }
        _ui.Post(_ => StepCaptured?.Invoke(this, step), null);
    }

    private static string AppendNote(string? existing, string add) =>
        string.IsNullOrEmpty(existing) ? add : existing + " " + add;

    // ----- recorder failure -----

    private void OnVideoFailed(object? sender, string error)
    {
        AddWarning("Video recording failed: " + error);
        _ui.Post(_ =>
        {
            if (_state is SessionState.Recording or SessionState.Paused)
            {
                SafeUnhook();
            }
            VideoFailed?.Invoke(this, error);
        }, null);
    }

    // ----- helpers -----

    private void CreateOutputFolders()
    {
        if (!Directory.Exists(_destinationRoot))
            throw new DirectoryNotFoundException($"Destination folder does not exist: {_destinationRoot}");

        string name = $"StepsRecording_{DateTime.Now:yyyyMMdd_HHmmss}";
        string folder = Path.Combine(_destinationRoot, name);
        int suffix = 2;
        while (Directory.Exists(folder)) folder = Path.Combine(_destinationRoot, $"{name}_{suffix++}");

        Directory.CreateDirectory(folder);
        OutputFolder = folder;
        ScreenshotsFolder = Path.Combine(folder, "screenshots");
        Directory.CreateDirectory(ScreenshotsFolder);
        VideoPath = Path.Combine(folder, "screen.mp4");
    }

    private void SafeUnhook()
    {
        try { _hook.Uninstall(); }
        catch (Exception ex) { AddWarning("Could not remove the mouse hook cleanly: " + ex.Message); }
    }

    private void AddWarning(string message)
    {
        lock (_warnings) { _warnings.Add(message); }
        _ui.Post(_ => Warning?.Invoke(this, message), null);
    }

    private void EnsureUiThread()
    {
        if (Environment.CurrentManagedThreadId != _uiThreadId)
            throw new InvalidOperationException("This operation must be called on the UI thread that created the session.");
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        if (_state is SessionState.Recording or SessionState.Paused or SessionState.Starting or SessionState.Stopping) Abort();
        _hook.Dispose();
        try { _video.Dispose(); } catch { /* ignore */ }
        _captureQueue.Dispose();
        _processQueue.Dispose();
    }
}
