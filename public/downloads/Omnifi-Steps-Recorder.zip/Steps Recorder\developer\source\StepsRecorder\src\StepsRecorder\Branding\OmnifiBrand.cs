using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Globalization;
using System.Text;

namespace StepsRecorder.Branding;

/// <summary>
/// Omnifi brand system (colours, type, logo, mandatory notices). The logo is embedded as vector path data
/// and rendered on demand with a transparent background, so no image files ship with the app.
/// </summary>
public static class OmnifiBrand
{
    public const string CompanyName = "Omnifi";
    public const string ProductName = "Steps Recorder";
    public const string InternalUseNotice = "Prepared for Omnifi internal use only";

    /// <summary>Omnifi SuperTools web app (opened in the user's browser only when they click the button).</summary>
    public const string SuperToolsUrl = "https://omnifi-supertools.onrender.com/";
    public const string SuperToolsName = "Omnifi SuperTools";
    public const string FontFamily = "Segoe UI";

    // Brand colour system
    public static readonly Color DeepNavy = ColorTranslator.FromHtml("#0A0F3D");
    public static readonly Color MidNavy = ColorTranslator.FromHtml("#131A6B");
    public static readonly Color IndigoBright = ColorTranslator.FromHtml("#4F5BD5");
    public static readonly Color Lavender = ColorTranslator.FromHtml("#8B91E3");
    public static readonly Color AccentGreen = ColorTranslator.FromHtml("#00C48C");
    public static readonly Color OffWhite = ColorTranslator.FromHtml("#F5F5FA");
    public static readonly Color BodyNavy = ColorTranslator.FromHtml("#2D3580");
    public static readonly Color MutedIndigo = ColorTranslator.FromHtml("#6B72B8");
    public static readonly Color White = Color.White;

    // Logo colours as used in the master SVG
    private static readonly Color LogoNavy = ColorTranslator.FromHtml("#0F105E");
    private static readonly Color LogoIndigo = ColorTranslator.FromHtml("#6B6BFD");

    public const string Hex_DeepNavy = "#0A0F3D";
    public const string Hex_MidNavy = "#131A6B";
    public const string Hex_IndigoBright = "#4F5BD5";
    public const string Hex_Lavender = "#8B91E3";
    public const string Hex_AccentGreen = "#00C48C";
    public const string Hex_OffWhite = "#F5F5FA";
    public const string Hex_BodyNavy = "#2D3580";
    public const string Hex_MutedIndigo = "#6B72B8";

    /// <summary>Master logo geometry: viewBox 0 0 160 43, two fills (navy word mark, indigo accents).</summary>
    private const float LogoViewWidth = 160f;
    private const float LogoViewHeight = 43f;

    private static readonly (string Path, bool Accent)[] LogoPaths =
    {
        ("M15.78 16.5942C27.6441 16.5942 30.4482 20.2629 30.4482 29.3965C30.4482 38.5302 27.6441 42.1989 15.78 42.1989C3.91592 42.1989 0.987793 38.5027 0.987793 29.3965C0.987793 20.2904 3.83324 16.5942 15.78 16.5942ZM15.78 36.2382C23.4 36.2382 25.0673 34.2972 25.0673 29.3965C25.0673 24.4959 23.4 22.5549 15.78 22.5549C8.15998 22.5549 6.37555 24.7024 6.37555 29.3965C6.37555 34.0907 8.08419 36.2382 15.78 36.2382Z", false),
        ("M151.466 38.3032C151.466 35.9217 153.312 34.084 155.648 34.084C157.983 34.084 159.782 35.9286 159.782 38.3032C159.782 40.6779 158.025 42.433 155.648 42.433C153.271 42.433 151.466 40.6366 151.466 38.3032Z", false),
        ("M66.7086 42.1988V26.7672C66.7086 24.5991 65.8405 22.5411 62.3199 22.5411C58.7993 22.5411 57.7107 24.5991 57.7107 26.8705V42.1919H51.2619V26.7603C51.2619 24.5922 50.3938 22.5342 46.8732 22.5342C43.3525 22.5342 42.264 24.5922 42.264 26.8636V42.1851H35.8152V17.6748H41.6163L41.7266 20.9787H41.7817C42.8151 18.5971 45.0887 17.0278 49.0434 17.0278C52.3505 17.0278 55.1133 18.3838 56.3052 20.8203C57.4971 18.6522 60.4804 17.0278 64.1112 17.0278C69.747 17.0278 73.1643 20.2766 73.1643 25.5834V42.2057H66.7155L66.7086 42.1988Z", false),
        ("M94.5088 42.1988V26.7672C94.5088 24.5991 93.1515 22.5411 89.8513 22.5411C86.5512 22.5411 84.9734 24.5991 84.9734 26.8705V42.1919H78.5247V17.6748H84.3809V20.9236H84.436C85.4626 18.5421 87.9016 17.0278 92.0216 17.0278C97.3887 17.0278 100.964 20.2215 100.964 25.5283V42.2057H94.5157L94.5088 42.1988Z", false),
        ("M106.324 42.1988V17.6748H112.883V42.2057H106.324V42.1988Z", false),
        ("M146.099 17.6748H139.54V42.2057H146.099V17.6748Z", true),
        ("M128.544 14.9631C128.544 13.5727 128.723 12.0791 129.481 10.8815C130.273 9.61502 131.665 8.98867 133.132 8.90607C134.063 8.85101 134.993 9.00932 135.888 9.26399C136.384 9.40853 136.874 9.5806 137.315 9.84904C138.134 10.3584 138.727 11.1981 139.071 12.0998C139.154 12.3269 139.244 12.5816 139.319 12.85H145.844C145.279 10.2551 143.812 7.91492 141.655 6.29054C140.601 5.499 139.43 4.90019 138.196 4.46656C136.054 3.7232 133.718 3.49606 131.486 3.70255C128.95 3.94345 126.463 4.92084 124.741 6.85495C122.881 8.94737 122.212 11.7831 122.212 14.5226V17.6612H118.258V22.8578H122.212V42.1852H128.551V22.8578H134.786L136.033 17.6612H128.551V14.9562Z", true),
        ("M9.62061 7.87382C9.62061 4.38416 12.3214 1.68604 15.7524 1.68604C19.1835 1.68604 21.8154 4.38416 21.8154 7.87382C21.8154 11.3635 19.2455 13.9308 15.7524 13.9308C12.2594 13.9308 9.62061 11.2947 9.62061 7.87382Z", true)
    };

    /// <summary>Inline SVG for HTML output. On dark backgrounds the navy word mark becomes white.</summary>
    public static string LogoSvg(int heightPx, bool onDark)
    {
        int width = (int)Math.Round(heightPx * LogoViewWidth / LogoViewHeight);
        string navy = onDark ? "#FFFFFF" : "#0F105E";
        var sb = new StringBuilder();
        sb.Append($"<svg width=\"{width}\" height=\"{heightPx}\" viewBox=\"0 0 160 43\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\" role=\"img\" aria-label=\"Omnifi\">");
        foreach (var (path, accent) in LogoPaths)
            sb.Append($"<path d=\"{path}\" fill=\"{(accent ? "#6B6BFD" : navy)}\"/>");
        sb.Append("</svg>");
        return sb.ToString();
    }

    /// <summary>Renders the logo at the given height with a transparent background.</summary>
    public static Bitmap RenderLogo(int heightPx, bool onDark)
    {
        float scale = heightPx / LogoViewHeight;
        int width = (int)Math.Ceiling(LogoViewWidth * scale);
        var bmp = new Bitmap(width, heightPx, PixelFormat.Format32bppArgb);
        using Graphics g = Graphics.FromImage(bmp);
        g.Clear(Color.Transparent);
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.PixelOffsetMode = PixelOffsetMode.HighQuality;
        g.ScaleTransform(scale, scale);
        using var navyBrush = new SolidBrush(onDark ? Color.White : LogoNavy);
        using var accentBrush = new SolidBrush(LogoIndigo);
        foreach (var (path, accent) in LogoPaths)
        {
            using GraphicsPath gp = SvgPathParser.Parse(path);
            gp.FillMode = FillMode.Winding;
            g.FillPath(accent ? accentBrush : navyBrush, gp);
        }
        return bmp;
    }

    /// <summary>
    /// Renders only the "o" mark of the logo (navy ring + indigo dot) centred in a square with a transparent
    /// background. Used for the window / taskbar icon.
    /// </summary>
    public static Bitmap RenderMark(int sizePx)
    {
        // Bounding box of the ring (path 0) and the dot (path 7) in logo units.
        const float minX = 0.9878f, maxX = 30.4482f, minY = 1.68604f, maxY = 42.433f;
        float w = maxX - minX, h = maxY - minY;
        float scale = sizePx * 0.92f / Math.Max(w, h);
        float offsetX = (sizePx - w * scale) / 2f - minX * scale;
        float offsetY = (sizePx - h * scale) / 2f - minY * scale;

        var bmp = new Bitmap(sizePx, sizePx, PixelFormat.Format32bppArgb);
        using Graphics g = Graphics.FromImage(bmp);
        g.Clear(Color.Transparent);
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.PixelOffsetMode = PixelOffsetMode.HighQuality;
        g.TranslateTransform(offsetX, offsetY);
        g.ScaleTransform(scale, scale);
        using var navyBrush = new SolidBrush(LogoNavy);
        using var accentBrush = new SolidBrush(LogoIndigo);
        foreach (int index in new[] { 0, 7 })
        {
            using GraphicsPath gp = SvgPathParser.Parse(LogoPaths[index].Path);
            gp.FillMode = FillMode.Winding;
            g.FillPath(LogoPaths[index].Accent ? accentBrush : navyBrush, gp);
        }
        return bmp;
    }

    /// <summary>Multi-resolution application icon (16 to 256 px) built from <see cref="RenderMark"/>.</summary>
    public static Icon CreateAppIcon()
    {
        int[] sizes = { 16, 20, 24, 32, 40, 48, 64, 128, 256 };
        var pngs = new List<byte[]>();
        foreach (int s in sizes)
        {
            using Bitmap b = RenderMark(s);
            using var ms = new MemoryStream();
            b.Save(ms, ImageFormat.Png);
            pngs.Add(ms.ToArray());
        }

        // ICO container with PNG-compressed entries (supported since Windows Vista).
        using var ico = new MemoryStream();
        using (var bw = new BinaryWriter(ico, Encoding.UTF8, leaveOpen: true))
        {
            bw.Write((ushort)0); bw.Write((ushort)1); bw.Write((ushort)sizes.Length);
            int offset = 6 + 16 * sizes.Length;
            for (int i = 0; i < sizes.Length; i++)
            {
                int s = sizes[i];
                bw.Write((byte)(s >= 256 ? 0 : s)); bw.Write((byte)(s >= 256 ? 0 : s));
                bw.Write((byte)0); bw.Write((byte)0);
                bw.Write((ushort)1); bw.Write((ushort)32);
                bw.Write(pngs[i].Length); bw.Write(offset);
                offset += pngs[i].Length;
            }
            foreach (var png in pngs) bw.Write(png);
        }
        ico.Position = 0;
        return new Icon(ico);
    }

    public static byte[] RenderLogoPng(int heightPx, bool onDark)
    {
        using Bitmap bmp = RenderLogo(heightPx, onDark);
        using var ms = new MemoryStream();
        bmp.Save(ms, ImageFormat.Png);
        return ms.ToArray();
    }

    public static Font HeadlineFont(float sizePt) => new(FontFamily, sizePt, FontStyle.Bold, GraphicsUnit.Point);
    public static Font BodyFont(float sizePt) => new(FontFamily, sizePt, FontStyle.Regular, GraphicsUnit.Point);

    /// <summary>Minimal SVG path-data parser (M/L/H/V/C/Z, absolute and relative) to GDI+ GraphicsPath.</summary>
    private static class SvgPathParser
    {
        public static GraphicsPath Parse(string data)
        {
            var path = new GraphicsPath();
            var tokens = Tokenize(data);
            int i = 0;
            char cmd = 'M';
            PointF current = PointF.Empty, start = PointF.Empty;
            bool figureOpen = false;

            float Next() => float.Parse(tokens[i++], CultureInfo.InvariantCulture);

            while (i < tokens.Count)
            {
                string t = tokens[i];
                if (t.Length == 1 && char.IsLetter(t[0])) { cmd = t[0]; i++; }
                bool rel = char.IsLower(cmd);
                switch (char.ToUpperInvariant(cmd))
                {
                    case 'M':
                    {
                        float x = Next(), y = Next();
                        if (rel) { x += current.X; y += current.Y; }
                        if (figureOpen) path.CloseFigure();
                        path.StartFigure();
                        figureOpen = true;
                        current = start = new PointF(x, y);
                        cmd = rel ? 'l' : 'L'; // subsequent pairs are implicit line-tos
                        break;
                    }
                    case 'L':
                    {
                        float x = Next(), y = Next();
                        if (rel) { x += current.X; y += current.Y; }
                        var p = new PointF(x, y);
                        path.AddLine(current, p);
                        current = p;
                        break;
                    }
                    case 'H':
                    {
                        float x = Next();
                        if (rel) x += current.X;
                        var p = new PointF(x, current.Y);
                        path.AddLine(current, p);
                        current = p;
                        break;
                    }
                    case 'V':
                    {
                        float y = Next();
                        if (rel) y += current.Y;
                        var p = new PointF(current.X, y);
                        path.AddLine(current, p);
                        current = p;
                        break;
                    }
                    case 'C':
                    {
                        float x1 = Next(), y1 = Next(), x2 = Next(), y2 = Next(), x = Next(), y = Next();
                        if (rel) { x1 += current.X; y1 += current.Y; x2 += current.X; y2 += current.Y; x += current.X; y += current.Y; }
                        var p = new PointF(x, y);
                        path.AddBezier(current, new PointF(x1, y1), new PointF(x2, y2), p);
                        current = p;
                        break;
                    }
                    case 'Z':
                    {
                        if (figureOpen) path.CloseFigure();
                        figureOpen = false;
                        current = start;
                        break;
                    }
                    default:
                        throw new NotSupportedException("Unsupported SVG path command: " + cmd);
                }
            }
            if (figureOpen) path.CloseFigure();
            return path;
        }

        private static List<string> Tokenize(string data)
        {
            var tokens = new List<string>();
            var sb = new StringBuilder();
            void Flush() { if (sb.Length > 0) { tokens.Add(sb.ToString()); sb.Clear(); } }
            foreach (char c in data)
            {
                if (char.IsLetter(c)) { Flush(); tokens.Add(c.ToString()); }
                else if (c == ',' || char.IsWhiteSpace(c)) { Flush(); }
                else if (c == '-' && sb.Length > 0 && sb[^1] != 'e' && sb[^1] != 'E') { Flush(); sb.Append(c); }
                else if (c == '.' && sb.ToString().Contains('.')) { Flush(); sb.Append(c); }
                else sb.Append(c);
            }
            Flush();
            return tokens;
        }
    }
}
