using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using StepsRecorder.Branding;
using StepsRecorder.Models;

namespace StepsRecorder.Reporting;

/// <summary>
/// Stitches every step screenshot into one tall "scrolling" PNG at full native resolution (no scaling, lossless),
/// with a navy label band above each screenshot (step number, click type, description). Written as
/// master-screenshot.png; recordings with many steps are split into master-screenshot-1.png, -2.png, ... so no
/// single image exceeds the size GDI+ and common viewers handle comfortably.
/// </summary>
public static class MasterScreenshotWriter
{
    private const int BandHeight = 64;
    private const int Gap = 16;
    private const int SideMargin = 24;
    /// <summary>Maximum height of one output image; longer recordings are split into parts.</summary>
    private const int MaxPartHeight = 30_000;

    public static List<string> Write(RecordingResult r)
    {
        var steps = r.Steps.Where(s => s.ScreenshotSaved && File.Exists(s.ScreenshotFullPath) && s.ScreenshotWidth > 0 && s.ScreenshotHeight > 0).ToList();
        var outputs = new List<string>();
        if (steps.Count == 0) return outputs;

        int width = steps.Max(s => s.ScreenshotWidth) + SideMargin * 2;

        // Split into parts by accumulated height.
        var parts = new List<List<StepRecord>>();
        var current = new List<StepRecord>();
        int height = Gap;
        foreach (var s in steps)
        {
            int block = BandHeight + s.ScreenshotHeight + Gap;
            if (current.Count > 0 && height + block > MaxPartHeight)
            {
                parts.Add(current);
                current = new List<StepRecord>();
                height = Gap;
            }
            current.Add(s);
            height += block;
        }
        if (current.Count > 0) parts.Add(current);

        for (int p = 0; p < parts.Count; p++)
        {
            string name = parts.Count == 1 ? "master-screenshot.png" : $"master-screenshot-{p + 1}.png";
            string path = Path.Combine(r.OutputFolder, name);
            WritePart(path, parts[p], width, p + 1, parts.Count, r);
            outputs.Add(path);
        }
        return outputs;
    }

    private static void WritePart(string path, List<StepRecord> steps, int width, int partNo, int partCount, RecordingResult r)
    {
        int total = Gap + steps.Sum(s => BandHeight + s.ScreenshotHeight + Gap) + 40;
        using var canvas = new Bitmap(width, total, PixelFormat.Format24bppRgb);
        using (Graphics g = Graphics.FromImage(canvas))
        {
            g.Clear(OmnifiBrand.OffWhite);
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            g.InterpolationMode = InterpolationMode.NearestNeighbor; // images are drawn 1:1, never resampled
            g.PixelOffsetMode = PixelOffsetMode.Half;

            using var bandBrush = new SolidBrush(OmnifiBrand.DeepNavy);
            using var numBrush = new SolidBrush(OmnifiBrand.IndigoBright);
            using var textBrush = new SolidBrush(OmnifiBrand.White);
            using var subBrush = new SolidBrush(OmnifiBrand.Lavender);
            using var numFont = OmnifiBrand.HeadlineFont(16f);
            using var textFont = OmnifiBrand.HeadlineFont(12f);
            using var subFont = OmnifiBrand.BodyFont(9.5f);
            using var border = new Pen(Color.FromArgb(218, 220, 240), 1f);

            int y = Gap;
            foreach (var s in steps)
            {
                // Label band
                var band = new Rectangle(SideMargin, y, width - SideMargin * 2, BandHeight);
                g.FillRectangle(bandBrush, band);
                string num = $"#{s.StepNumber}";
                SizeF numSize = g.MeasureString(num, numFont);
                g.DrawString(num, numFont, numBrush, band.X + 14, band.Y + 8);
                float textX = band.X + 14 + numSize.Width + 8;
                var textRect = new RectangleF(textX, band.Y + 9, band.Width - (textX - band.X) - 14, 26);
                g.DrawString(s.Description, textFont, textBrush, textRect, new StringFormat { Trimming = StringTrimming.EllipsisCharacter, FormatFlags = StringFormatFlags.NoWrap });
                string kind = s.Kind == StepKind.Selection ? "Selection" : ReportGenerator.ButtonName(s.Button) + " click";
                string sub = $"{kind}  |  {ReportGenerator.FormatWall(s.WallTime)}  |  video {ReportGenerator.FormatOffset(s.VideoOffset)}  |  " +
                             (s.Kind == StepKind.Selection ? $"({s.X}, {s.Y}) to ({s.EndX}, {s.EndY})" : $"({s.X}, {s.Y})") +
                             (string.IsNullOrEmpty(s.Window.DisplayTitle) ? "" : $"  |  {s.Window.DisplayTitle}");
                g.DrawString(sub, subFont, subBrush, new RectangleF(band.X + 14, band.Y + 38, band.Width - 28, 20), new StringFormat { Trimming = StringTrimming.EllipsisCharacter, FormatFlags = StringFormatFlags.NoWrap });
                y += BandHeight;

                // Screenshot, 1:1 pixels
                using (var shot = new Bitmap(s.ScreenshotFullPath))
                {
                    int x = SideMargin + (width - SideMargin * 2 - shot.Width) / 2;
                    g.DrawImage(shot, new Rectangle(x, y, shot.Width, shot.Height), new Rectangle(0, 0, shot.Width, shot.Height), GraphicsUnit.Pixel);
                    g.DrawRectangle(border, x, y, shot.Width - 1, shot.Height - 1);
                    y += shot.Height;
                }
                y += Gap;
            }

            string footer = $"{OmnifiBrand.ProductName}  |  {OmnifiBrand.InternalUseNotice}  |  {r.StartedAt:dd MMM yyyy HH:mm}  |  {steps.Count} of {r.Steps.Count} steps" + (partCount > 1 ? $"  |  part {partNo} of {partCount}" : "");
            using var footBrush = new SolidBrush(OmnifiBrand.MutedIndigo);
            g.DrawString(footer, subFont, footBrush, SideMargin, y + 6);
        }
        canvas.Save(path, ImageFormat.Png);
    }
}
