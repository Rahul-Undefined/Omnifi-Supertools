using StepsRecorder.Branding;
using StepsRecorder.Models;

namespace StepsRecorder.UI;

/// <summary>
/// Compact always-on-top control bar shown while recording so the user can pause, resume or stop without
/// bringing up the main window. It belongs to the recorder process, so clicks on it are never recorded as
/// steps, and it is excluded from screen capture, so it never appears in screenshots or the video.
/// </summary>
public sealed class RecordingBar : Form
{
    private readonly Label _dot = new();
    private readonly Label _status = new();
    private readonly Button _pauseButton = new();
    private readonly Button _stopButton = new();
    private readonly Button _openButton = new();
    private Point _dragOffset;
    private bool _dragging;

    public event EventHandler? PauseResumeClicked;
    public event EventHandler? StopClicked;
    public event EventHandler? OpenClicked;

    public RecordingBar()
    {
        FormBorderStyle = FormBorderStyle.None;
        ShowInTaskbar = false;
        TopMost = true;
        StartPosition = FormStartPosition.Manual;
        BackColor = OmnifiBrand.DeepNavy;
        Font = OmnifiBrand.BodyFont(9.5f);
        ClientSize = new Size(470, 44);
        Rectangle b = Screen.PrimaryScreen?.WorkingArea ?? new Rectangle(0, 0, 1920, 1080);
        Location = new Point(b.Right - Width - 16, b.Top + 12);
        Text = "Steps Recorder (recording)";
        CaptureExclusion.Apply(this);

        _dot.Text = "●";
        _dot.ForeColor = OmnifiBrand.IndigoBright;
        _dot.Font = OmnifiBrand.HeadlineFont(12f);
        _dot.AutoSize = true;
        _dot.Location = new Point(12, 11);

        _status.ForeColor = OmnifiBrand.White;
        _status.Font = OmnifiBrand.HeadlineFont(9.5f);
        _status.AutoSize = false;
        _status.Size = new Size(190, 24);
        _status.Location = new Point(34, 11);
        _status.TextAlign = ContentAlignment.MiddleLeft;

        Style(_pauseButton, "Pause", 232);
        Style(_stopButton, "Stop", 312);
        Style(_openButton, "Open", 392);
        _pauseButton.Click += (_, _) => PauseResumeClicked?.Invoke(this, EventArgs.Empty);
        _stopButton.Click += (_, _) => StopClicked?.Invoke(this, EventArgs.Empty);
        _openButton.Click += (_, _) => OpenClicked?.Invoke(this, EventArgs.Empty);

        Controls.AddRange(new Control[] { _dot, _status, _pauseButton, _stopButton, _openButton });
        foreach (Control c in new Control[] { this, _dot, _status }) { c.MouseDown += OnDragStart; c.MouseMove += OnDragMove; c.MouseUp += (_, _) => _dragging = false; }
        Paint += (_, e) =>
        {
            using var pen = new Pen(OmnifiBrand.IndigoBright, 2f);
            e.Graphics.DrawRectangle(pen, 1, 1, Width - 2, Height - 2);
        };
    }

    protected override bool ShowWithoutActivation => true; // never steal focus from the app being demonstrated

    protected override CreateParams CreateParams
    {
        get
        {
            var cp = base.CreateParams;
            cp.ExStyle |= 0x08000000 | 0x00000080; // WS_EX_NOACTIVATE | WS_EX_TOOLWINDOW
            return cp;
        }
    }

    public void Update(SessionState state, TimeSpan elapsed, int clicks)
    {
        bool paused = state == SessionState.Paused;
        _dot.ForeColor = paused ? OmnifiBrand.MutedIndigo : OmnifiBrand.IndigoBright;
        _status.Text = (paused ? "Paused  " : "Recording  ") + elapsed.ToString(@"hh\:mm\:ss") + "   " + clicks + " step" + (clicks == 1 ? "" : "s");
        _pauseButton.Text = paused ? "Resume" : "Pause";
        bool active = state is SessionState.Recording or SessionState.Paused;
        _pauseButton.Enabled = active;
        _stopButton.Enabled = active;
    }

    private static void Style(Button b, string text, int x)
    {
        b.Text = text;
        b.FlatStyle = FlatStyle.Flat;
        b.FlatAppearance.BorderColor = OmnifiBrand.Lavender;
        b.FlatAppearance.BorderSize = 1;
        b.BackColor = OmnifiBrand.MidNavy;
        b.ForeColor = OmnifiBrand.White;
        b.Font = OmnifiBrand.HeadlineFont(9f);
        b.Size = new Size(72, 28);
        b.Location = new Point(x, 8);
        b.Cursor = Cursors.Hand;
        b.TabStop = false;
    }

    private void OnDragStart(object? sender, MouseEventArgs e)
    {
        if (e.Button != MouseButtons.Left) return;
        _dragging = true;
        _dragOffset = PointToClient(Cursor.Position);
    }

    private void OnDragMove(object? sender, MouseEventArgs e)
    {
        if (!_dragging) return;
        Point p = Cursor.Position;
        Location = new Point(p.X - _dragOffset.X, p.Y - _dragOffset.Y);
    }
}
