namespace StepsRecorder.Recording;

public sealed record VideoResult(bool Succeeded, string FilePath, string? Error);

/// <summary>Abstraction over the screen-to-MP4 recorder so the implementation can be swapped or faked.</summary>
public interface IVideoRecorder : IDisposable
{
    /// <summary>Starts recording to <paramref name="outputPath"/> and completes once frames are actually being recorded.</summary>
    Task StartAsync(string outputPath, CancellationToken cancellationToken);

    void Pause();

    void Resume();

    /// <summary>Stops and finalizes the file. Never throws for recorder errors; they are reported in the result.</summary>
    Task<VideoResult> StopAsync();

    /// <summary>Raised (on a background thread) if the recorder fails after a successful start.</summary>
    event EventHandler<string>? Failed;
}
