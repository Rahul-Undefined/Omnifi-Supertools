using System.Windows.Automation;
using StepsRecorder.Models;

namespace StepsRecorder.Describing;

/// <summary>
/// Looks up the accessible element under a screen point with Windows UI Automation (in-box, local only).
/// UIA calls into the target application can be slow or hang for unresponsive apps, so every lookup is
/// time-boxed. Call from a background (MTA) thread, never from the hook callback.
/// </summary>
public static class UiAutomationInspector
{
    public static UiElementInfo? TryInspect(int x, int y, TimeSpan timeout)
    {
        var task = Task.Run(() => InspectCore(x, y));
        try
        {
            return task.Wait(timeout) ? task.Result : null;
        }
        catch
        {
            return null;
        }
    }

    private static UiElementInfo? InspectCore(int x, int y)
    {
        try
        {
            AutomationElement? element = AutomationElement.FromPoint(new System.Windows.Point(x, y));
            if (element == null) return null;

            string name = SafeGet(() => element.Current.Name);
            string controlType = SafeGet(() => element.Current.LocalizedControlType);
            string automationId = SafeGet(() => element.Current.AutomationId);
            string className = SafeGet(() => element.Current.ClassName);
            string frameworkId = SafeGet(() => element.Current.FrameworkId);

            // Many containers (panes, documents) have no name; try the nearest named ancestor for context.
            if (string.IsNullOrWhiteSpace(name))
            {
                try
                {
                    var walker = TreeWalker.ControlViewWalker;
                    AutomationElement? parent = walker.GetParent(element);
                    int hops = 0;
                    while (parent != null && hops++ < 3)
                    {
                        string parentName = SafeGet(() => parent.Current.Name);
                        string parentType = SafeGet(() => parent.Current.LocalizedControlType);
                        if (parentType.Equals("window", StringComparison.OrdinalIgnoreCase)) break;
                        if (!string.IsNullOrWhiteSpace(parentName))
                        {
                            name = parentName;
                            if (string.IsNullOrWhiteSpace(controlType)) controlType = parentType;
                            break;
                        }
                        parent = walker.GetParent(parent);
                    }
                }
                catch { /* ancestor lookup is optional */ }
            }

            if (string.IsNullOrWhiteSpace(name) && string.IsNullOrWhiteSpace(controlType)) return null;
            return new UiElementInfo(Clean(name), Clean(controlType), Clean(automationId), Clean(className), Clean(frameworkId));
        }
        catch
        {
            return null;
        }
    }

    private static string SafeGet(Func<string?> getter)
    {
        try { return getter() ?? string.Empty; }
        catch { return string.Empty; }
    }

    private static string Clean(string value)
    {
        value = value.Replace('\r', ' ').Replace('\n', ' ').Trim();
        return value.Length > 120 ? value[..117] + "..." : value;
    }
}
