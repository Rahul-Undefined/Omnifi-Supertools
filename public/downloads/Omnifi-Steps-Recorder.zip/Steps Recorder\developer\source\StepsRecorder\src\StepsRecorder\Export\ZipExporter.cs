using System.IO.Compression;

namespace StepsRecorder.Export;

/// <summary>Creates a ZIP copy of a completed recording folder next to it. Originals are never touched.</summary>
public static class ZipExporter
{
    public static string Export(string recordingFolder)
    {
        if (!Directory.Exists(recordingFolder))
            throw new DirectoryNotFoundException("Recording folder not found: " + recordingFolder);

        string parent = Path.GetDirectoryName(Path.TrimEndingDirectorySeparator(recordingFolder)) ?? recordingFolder;
        string baseName = Path.GetFileName(Path.TrimEndingDirectorySeparator(recordingFolder));
        string zipPath = Path.Combine(parent, baseName + ".zip");
        int n = 2;
        while (File.Exists(zipPath)) zipPath = Path.Combine(parent, $"{baseName}_{n++}.zip");

        // Screenshots are already PNG and the video is already H.264, so "Fastest" avoids wasting time
        // recompressing data that does not shrink.
        ZipFile.CreateFromDirectory(recordingFolder, zipPath, CompressionLevel.Fastest, includeBaseDirectory: true);
        return zipPath;
    }
}
