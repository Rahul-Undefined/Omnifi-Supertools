using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using StepsRecorder.Models;
using StepsRecorder.Native;

namespace StepsRecorder.Recording;

/// <summary>
/// Captures the primary display with GDI (BitBlt via Graphics.CopyFromScreen) and draws click markers.
/// Works from any thread. Coordinates are physical pixels because the process is PerMonitorV2 DPI aware.
/// </summary>
public sealed class ScreenCapturer
{
    public Rectangle CaptureBounds => Screen.PrimaryScreen?.Bounds ?? new Rectangle(0, 0, 1, 1);

    public string CaptureDisplayDescription
    {
        get
        {
            var s = Screen.PrimaryScreen;
            if (s == null) return "unknown display";
            return $"{s.DeviceName.TrimStart('\\', '.')} (primary), {s.Bounds.Width}x{s.Bounds.Height} px at ({s.Bounds.X},{s.Bounds.Y})";
        }
    }

    public Bitmap CapturePrimaryScreen(bool includeCursor)
    {
        Rectangle bounds = CaptureBounds;
        var bitmap = new Bitmap(bounds.Width, bounds.Height, PixelFormat.Format32bppArgb);
        try
        {
            using Graphics g = Graphics.FromImage(bitmap);
            g.CopyFromScreen(bounds.Location, Point.Empty, bounds.Size, CopyPixelOperation.SourceCopy);
            if (includeCursor)
            {
                try { DrawCursor(g, bounds); }
                catch { /* cursor overlay is best-effort */ }
            }
            return bitmap;
        }
        catch
        {
            bitmap.Dispose();
            throw;
        }
    }

    /// <summary>Draws the current system cursor so the pointer is visible in screenshots.</summary>
    private static void DrawCursor(Graphics g, Rectangle bounds)
    {
        var ci = new NativeMethods.CURSORINFO { cbSize = Marshal.SizeOf<NativeMethods.CURSORINFO>() };
        if (!NativeMethods.GetCursorInfo(ref ci)) return;
        if (ci.flags != NativeMethods.CURSOR_SHOWING || ci.hCursor == IntPtr.Zero) return;
        if (!NativeMethods.GetIconInfo(ci.hCursor, out var iconInfo)) return;
        try
        {
            int x = ci.ptScreenPos.X - iconInfo.xHotspot - bounds.X;
            int y = ci.ptScreenPos.Y - iconInfo.yHotspot - bounds.Y;
            IntPtr hdc = g.GetHdc();
            try
            {
                NativeMethods.DrawIconEx(hdc, x, y, ci.hCursor, 0, 0, 0, IntPtr.Zero, NativeMethods.DI_NORMAL);
            }
            finally
            {
                g.ReleaseHdc(hdc);
            }
        }
        finally
        {
            if (iconInfo.hbmMask != IntPtr.Zero) NativeMethods.DeleteObject(iconInfo.hbmMask);
            if (iconInfo.hbmColor != IntPtr.Zero) NativeMethods.DeleteObject(iconInfo.hbmColor);
        }
    }

    /// <summary>
    /// Draws a translucent ring + crosshair + step badge at the click location. The ring is hollow and
    /// translucent so the original pixels under and around the click remain visible.
    /// </summary>
    public static void DrawClickMarker(Bitmap bitmap, Point location, MouseButton button, int stepNumber)
    {
        // Brand palette: Indigo Bright (left), Deep Navy (right), Accent Green (middle). Functional indicators only.
        Color color = button switch
        {
            MouseButton.Left => Branding.OmnifiBrand.IndigoBright,
            MouseButton.Right => Branding.OmnifiBrand.DeepNavy,
            _ => Branding.OmnifiBrand.AccentGreen
        };

        using Graphics g = Graphics.FromImage(bitmap);
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;

        const int outerRadius = 28;
        const int innerRadius = 12;

        using (var fill = new SolidBrush(Color.FromArgb(50, color)))
        using (var outerPen = new Pen(Color.FromArgb(230, color), 4f))
        using (var innerPen = new Pen(Color.FromArgb(255, Color.White), 2f))
        {
            var outer = new Rectangle(location.X - outerRadius, location.Y - outerRadius, outerRadius * 2, outerRadius * 2);
            var inner = new Rectangle(location.X - innerRadius, location.Y - innerRadius, innerRadius * 2, innerRadius * 2);
            g.FillEllipse(fill, outer);
            g.DrawEllipse(outerPen, outer);
            g.DrawEllipse(innerPen, inner);
            g.DrawLine(outerPen, location.X - 6, location.Y, location.X + 6, location.Y);
            g.DrawLine(outerPen, location.X, location.Y - 6, location.X, location.Y + 6);
        }

        // Step badge, placed to the upper-right of the ring but kept inside the image.
        string label = $"#{stepNumber} {ButtonLabel(button)}";
        using var font = new Font("Segoe UI", 12f, FontStyle.Bold, GraphicsUnit.Point);
        SizeF textSize = g.MeasureString(label, font);
        var badge = new RectangleF(location.X + outerRadius + 6, location.Y - outerRadius - textSize.Height - 2, textSize.Width + 12, textSize.Height + 6);
        if (badge.Right > bitmap.Width) badge.X = Math.Max(0, location.X - outerRadius - badge.Width - 6);
        if (badge.Top < 0) badge.Y = Math.Min(bitmap.Height - badge.Height, location.Y + outerRadius + 6);

        using (var badgeBrush = new SolidBrush(Color.FromArgb(225, color)))
        using (var textBrush = new SolidBrush(Color.White))
        using (var path = RoundedRect(badge, 6))
        {
            g.FillPath(badgeBrush, path);
            g.DrawString(label, font, textBrush, badge.X + 6, badge.Y + 3);
        }
    }

    /// <summary>
    /// Highlights a dragged/selected area: translucent indigo fill, solid border, corner handles and a badge.
    /// The fill is light enough that the selected content stays readable.
    /// </summary>
    public static void DrawSelectionMarker(Bitmap bitmap, Rectangle rect, int stepNumber)
    {
        Color color = Branding.OmnifiBrand.IndigoBright;
        rect.Intersect(new Rectangle(0, 0, bitmap.Width, bitmap.Height));
        if (rect.Width < 2) rect.Width = 2;
        if (rect.Height < 2) rect.Height = 2;

        using Graphics g = Graphics.FromImage(bitmap);
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;

        using (var fill = new SolidBrush(Color.FromArgb(45, color)))
        using (var border = new Pen(Color.FromArgb(235, color), 3f))
        using (var halo = new Pen(Color.FromArgb(160, Color.White), 7f))
        using (var handle = new SolidBrush(color))
        {
            g.DrawRectangle(halo, rect);
            g.FillRectangle(fill, rect);
            g.DrawRectangle(border, rect);
            const int hs = 5;
            foreach (var p in new[] { new Point(rect.Left, rect.Top), new Point(rect.Right, rect.Top), new Point(rect.Left, rect.Bottom), new Point(rect.Right, rect.Bottom) })
                g.FillEllipse(handle, p.X - hs, p.Y - hs, hs * 2, hs * 2);
        }

        string label = $"#{stepNumber} Selection {rect.Width}x{rect.Height}";
        using var font = new Font("Segoe UI", 12f, FontStyle.Bold, GraphicsUnit.Point);
        SizeF textSize = g.MeasureString(label, font);
        var badge = new RectangleF(rect.Left, rect.Top - textSize.Height - 10, textSize.Width + 12, textSize.Height + 6);
        if (badge.Top < 0) badge.Y = Math.Min(bitmap.Height - badge.Height, rect.Bottom + 8);
        if (badge.Right > bitmap.Width) badge.X = Math.Max(0, bitmap.Width - badge.Width);

        using (var badgeBrush = new SolidBrush(Color.FromArgb(230, color)))
        using (var textBrush = new SolidBrush(Color.White))
        using (var path = RoundedRect(badge, 6))
        {
            g.FillPath(badgeBrush, path);
            g.DrawString(label, font, textBrush, badge.X + 6, badge.Y + 3);
        }
    }

    private static string ButtonLabel(MouseButton button) => button switch
    {
        MouseButton.Left => "L",
        MouseButton.Right => "R",
        _ => "M"
    };

    private static GraphicsPath RoundedRect(RectangleF r, float radius)
    {
        var path = new GraphicsPath();
        float d = radius * 2;
        path.AddArc(r.X, r.Y, d, d, 180, 90);
        path.AddArc(r.Right - d, r.Y, d, d, 270, 90);
        path.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
        path.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
        path.CloseFigure();
        return path;
    }
}
