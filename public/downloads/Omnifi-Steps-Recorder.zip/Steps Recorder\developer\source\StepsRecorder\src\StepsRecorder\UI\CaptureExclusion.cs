using StepsRecorder.Native;

namespace StepsRecorder.UI;

/// <summary>
/// Marks a window as excluded from screen capture (SetWindowDisplayAffinity / WDA_EXCLUDEFROMCAPTURE).
/// The window stays visible to the user but is omitted from the recorded video and from the GDI screenshots,
/// so the recorder's own UI never appears in a recording. Supported on Windows 10 2004+; silently ignored
/// on older systems.
/// </summary>
public static class CaptureExclusion
{
    public static void Apply(Form form)
    {
        if (form.IsHandleCreated) Set(form.Handle);
        form.HandleCreated += (_, _) => Set(form.Handle);
    }

    private static void Set(IntPtr handle)
    {
        if (handle == IntPtr.Zero) return;
        try { NativeMethods.SetWindowDisplayAffinity(handle, NativeMethods.WDA_EXCLUDEFROMCAPTURE); }
        catch { /* best effort */ }
    }
}
