# Manual test plan - Steps Recorder MVP

Environment: Windows 10/11 x64, standard (non-admin) user, primary display at 100 % and again at 125-150 %
scaling. Keep the app folder path short. Use a destination folder whose path contains spaces, e.g.
`C:\Users\<you>\Documents\Steps Test Folder`.

Automated pre-check (optional): `run.cmd --selftest "C:\Users\<you>\Documents\Steps Test Folder" 6`
(or `StepsRecorder.exe --selftest ...`) must write `selftest-result.txt` ending in `RESULT: PASS`.

| # | Area | Steps | Expected |
|---|---|---|---|
| 1 | Privacy notice / fixed window | Launch the app. Click "Privacy notice". Try to resize or maximize the window. | A fixed-size dialog shows the full notice (indigo callout) and closes with Close/Esc. The main window cannot be resized or maximized; nothing is clipped. |
| 2 | Folder required | Leave the folder empty, press Start. | Start is disabled until a folder is chosen; after choosing one, Start becomes available. |
| 3 | Start | Choose the folder with spaces. Press Start. | Status shows "RECORDING", elapsed counter runs, window minimizes (if the option is ticked). A `StepsRecording_YYYYMMDD_HHMMSS` folder with `screenshots\` appears in the chosen folder. |
| 4 | Click capture (left) | Open Notepad, left-click the File menu, then a menu item. | Each click increments "Clicks captured". After Stop, `step-0001.png`, `step-0002.png` exist, show the full screen with a red ring, crosshair, cursor and "#n L" badge at the click point. |
| 5 | Click capture (right / middle) | Right-click on the desktop; middle-click inside a browser page. | Steps are created with Right / Middle buttons; blue (right) and green (middle) rings in the PNGs. |
| 6 | Own window ignored | Restore the recorder window; click Pause, Resume. | No steps are created for clicks on the recorder's own window. |
| 7 | Pause | Press Pause; click around in other apps for 10 s. | Status "Paused"; no new steps; elapsed counter stops; video (after Stop) contains no footage of the paused period. |
| 8 | Resume | Press Resume; click once in Notepad. | Status back to "RECORDING"; the click creates a step; elapsed resumes. |
| 9 | Stop | Press Stop. | Status "Stopping..." then "Finished". Artifact list shows screen.mp4, steps.html, steps.docx, summary.txt and every step PNG with sizes. No error dialog. |
| 10 | MP4 playback | Double-click `screen.mp4` (or open in Movies & TV / VLC). | Plays from start to end, correct duration (excluding pauses), mouse pointer visible, red/blue pulse appears at left/right clicks. |
| 11 | Click-to-screenshot matching | Open `steps.html`. For each step compare timestamp, coordinates, description and the image. | Step numbers are sequential, each image matches the described click, the ring is at the stated (X, Y), the window title and (where available) the control name are correct. |
| 12 | Descriptions | Check the step for the Notepad menu click. | Reads like `Clicked menu item "Save" at (x, y) in "Untitled - Notepad" (notepad.exe)`; a click on an area without accessible name falls back to `Clicked at (x, y) in "<title>"`. |
| 13 | DOCX | Open `steps.docx` in Word. | Title, "Recording details" table, numbered steps with description, timestamps, coordinates and an embedded screenshot scaled to the page width; no repair prompt. |
| 14 | summary.txt | Open the file. | Start/end time, duration excluding pauses, total clicks, file list with sizes (including master-screenshot.png), any warnings. |
| 14b | Master screenshot | Open `master-screenshot.png` in Photos and zoom to 100 %. | Every step screenshot appears in order, pixel-identical to the individual PNGs (no scaling), each under a navy band with "#n", the description, click type, time and window; footer at the bottom. The file is listed in the app and linked from steps.html. A recording with more than about 25 steps produces numbered parts. |
| 15 | Open output folder | Click "Open output folder". | Explorer opens the recording folder (path with spaces works). |
| 16 | Open / reveal artifact | Select a PNG; click "Open selected", then "Show in Explorer". | File opens in the default viewer; Explorer selects the file. |
| 17 | Export ZIP | Click "Export ZIP". | `StepsRecording_...zip` appears next to the folder; contains the folder with all files; originals untouched; a second export creates `_2.zip`. |
| 18 | Close during recording - save | Start a recording, close the window, choose Yes. | Recording stops, reports are generated, app closes. |
| 19 | Close during recording - discard | Start a recording, close the window, choose No. | App closes immediately; no steps.html/docx are written; mouse works normally afterwards (hook removed). |
| 20 | Close during recording - cancel | Start, close, choose Cancel. | Recording continues. |
| 21 | Hook cleanup after error | Start recording, then kill the recorder from Task Manager. | Mouse keeps working (Windows removes the hook with the process). |
| 22 | Recorder failure UI | Rename/remove `ScreenRecorderLib.dll` from the app folder, press Start. | Friendly error dialog ("could not be loaded... Visual C++ Redistributable..."), status back to "Not recording", mouse unaffected. |
| 23 | Secondary display | With two monitors, click on the non-primary monitor. | Step created with global coordinates and a note "outside the primary display"; screenshot shows the primary display without marker. |
| 24 | DPI scaling | Repeat 4 at 150 % scaling. | Ring is exactly at the clicked spot; video and screenshot are full resolution. |
| 25 | No audio | Play music while recording. | MP4 has no audio track. |
| 26 | Locked-down machine | On a WDAC/AppLocker PC run `Start Steps Recorder.vbs`. | App starts via dotnet.exe without any installation or console window. |
| 27 | Countdown | Press Start. | A navy "Recording starts in 3, 2, 1" overlay appears centred, does not steal focus, then recording begins; nothing is captured before it ends. |
| 28 | Selection capture | Start recording, drag to select a sentence in Notepad or a range of cells in Excel, release. | Two steps: the initial click and a "Selection" step whose screenshot shows the dragged area with a translucent indigo box, corner handles and a "#n Selection WxH" badge; the description gives both corners and the size. Tiny drags (under 12 px) produce no selection step. |
| 29 | Voice recording | Tick "Record my voice (microphone)", record while speaking, Stop, play `screen.mp4`. | Your voice is audible; no system sounds are captured. `summary.txt` shows "Audio: Microphone". Without the tick, the MP4 has no audio track and summary shows "Audio: None". |
| 30 | Global shortcut | With the app window closed (tray icon visible), press Left Ctrl + Right Ctrl together. | The window opens and comes to the front. Holding one Ctrl and tapping it repeatedly does nothing; Ctrl+C etc. are unaffected. |
| 31 | Tray and exit | Close the window with the X. Right-click the tray icon. | Window hides, first time a balloon tip explains; tray menu offers Open, Shortcuts..., Exit. Exit quits fully (no dotnet process left). |
| 32 | Start with Windows | Sign out and in again (or check the Startup folder). | `Steps Recorder (background).lnk` exists in `shell:startup`; after sign-in the tray icon is present and the shortcut works without opening anything manually. |
| 33 | Shortcuts dialog | Click Shortcuts..., untick the hotkey, Apply. Close the window. | App exits on close instead of hiding; Startup entry removed; Left Ctrl + Right Ctrl does nothing. Re-enable and verify the opposite. Desktop shortcut checkbox creates/removes `Steps Recorder.lnk` on the Desktop with the "ö" icon. |
| 34 | Single instance | With the app running, double-click the launcher again. | No second window; the existing one comes to the front. |
| 35-38b | AI SOP (currently disabled via `AppConfig.AiSopAvailable = false`; the checkbox and Generate AI SOP button are hidden and no network request is made after Stop. Verify they are absent. The cases below apply only when the flag is re-enabled.) | | |
| 35 | AI SOP switch | Untick and re-tick "Write AI SOP after recording". | The setting is saved immediately (log line); re-ticking logs the live allowance ("x of 5 AI SOPs used in this 5-hour window ..."). There is no key field or dialog; nothing else is configurable. |
| 36 | AI SOP generation | Record 5 to 10 clicks in a real app (e.g. Excel: open file, select range, format), Stop. | Status shows "Writing AI SOP..."; within about a minute `sop.docx`, `sop.html`, `sop.md` appear in the list and folder, and the log shows the updated allowance. Open sop.docx: Omnifi header/footer, title, purpose, numbered imperative steps naming real buttons/fields, screenshots under the steps, "Recorded steps n, m" lines. |
| 37 | AI SOP allowance | Generate 6 SOPs within 5 hours on one computer. | The 6th is refused with "AI SOP allowance used up for now. 5 AI SOPs per 5 hours per computer. Resets in ...". A provider failure (e.g. key missing on the server) does not consume an allowance. |
| 38 | AI SOP offline / off | Press Generate AI SOP with Wi-Fi off; then untick automatic in AI SOP... and record again. | Offline gives "Could not reach the Omnifi SuperTools server"; recording outputs remain intact. With automatic off, no network request is made after Stop. |
| 38b | AI SOP server token (admin) | On Render, set STEPS_RECORDER_TOKEN to a different value than the app build. | The app shows "This version of Steps Recorder is not authorised for the AI SOP service"; restoring the value fixes it without touching user machines. |
| 39 | SuperTools button | Click "Omnifi SuperTools" in the header and in the tray menu. | Default browser opens https://omnifi-supertools.onrender.com/. |
| 40 | Floating bar | Start a recording. | A small navy bar appears top-right with "Recording 00:00:05  n steps", Pause, Stop, Open; it can be dragged; it never takes focus. Pause switches it to "Paused" and the button to Resume; Stop ends the recording; Open shows the main window. |
| 41 | Recorder invisible in captures | While recording: click Pause and Resume on the bar, open the main window with Open, click Shortcuts... and Cancel, then click once in Notepad and Stop. | Only the Notepad click is a step. In `screen.mp4` and every PNG the bar, the main window and the dialog are absent (the area behind them is shown instead). |
