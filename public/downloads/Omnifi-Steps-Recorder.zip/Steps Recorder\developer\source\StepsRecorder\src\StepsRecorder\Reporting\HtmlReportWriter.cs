using System.Net;
using System.Text;
using StepsRecorder.Branding;
using StepsRecorder.Models;

namespace StepsRecorder.Reporting;

/// <summary>Omnifi-branded HTML report that references the PNG files in ./screenshots relatively.</summary>
public static class HtmlReportWriter
{
    public static void Write(string path, RecordingResult r)
    {
        var sb = new StringBuilder();
        sb.AppendLine("<!DOCTYPE html>");
        sb.AppendLine("<html lang=\"en\"><head><meta charset=\"utf-8\">");
        sb.AppendLine("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">");
        sb.AppendLine("<title>Steps recording " + E(r.StartedAt.ToString("dd MMM yyyy HH:mm")) + " | Omnifi</title>");
        sb.AppendLine("<style>");
        sb.AppendLine(":root{--navy:" + OmnifiBrand.Hex_DeepNavy + ";--mid:" + OmnifiBrand.Hex_MidNavy + ";--indigo:" + OmnifiBrand.Hex_IndigoBright +
                      ";--lavender:" + OmnifiBrand.Hex_Lavender + ";--green:" + OmnifiBrand.Hex_AccentGreen + ";--off:" + OmnifiBrand.Hex_OffWhite +
                      ";--body:" + OmnifiBrand.Hex_BodyNavy + ";--muted:" + OmnifiBrand.Hex_MutedIndigo + ";}");
        sb.AppendLine("*{box-sizing:border-box} body{font-family:'Segoe UI',Arial,sans-serif;margin:0;background:var(--off);color:var(--body);font-size:15px;line-height:1.5;}");
        sb.AppendLine(".wrap{max-width:1180px;margin:0 auto;padding:28px 32px 48px;}");
        sb.AppendLine("header{display:flex;align-items:center;justify-content:space-between;padding-bottom:14px;border-bottom:1px solid var(--navy);margin-bottom:24px;}");
        sb.AppendLine("header .title{text-align:right} header h1{margin:0;font-size:24px;color:var(--navy);font-weight:700;} header h1 .dot{color:var(--indigo)}");
        sb.AppendLine("header .sub{color:var(--muted);font-size:13px;margin-top:2px}");
        sb.AppendLine("h2{font-size:18px;color:var(--navy);margin:28px 0 6px;font-weight:700;} h2 .dot{color:var(--indigo)} h2+.rule{height:2px;background:var(--indigo);width:64px;margin-bottom:14px;border-radius:1px}");
        sb.AppendLine("table.meta{border-collapse:collapse;width:100%;background:#fff;border-radius:8px;overflow:hidden;box-shadow:0 1px 2px rgba(10,15,61,.06)}");
        sb.AppendLine("table.meta th{background:var(--navy);color:#fff;text-align:left;padding:9px 14px;font-weight:600;width:200px} table.meta td{padding:9px 14px;}");
        sb.AppendLine("table.meta tr:nth-child(even) td{background:var(--off)}");
        sb.AppendLine(".callout{border-left:4px solid var(--indigo);background:#fff;color:var(--navy);font-weight:600;padding:12px 16px;border-radius:0 8px 8px 0;margin:0 0 22px}");
        sb.AppendLine(".step{background:#fff;border-radius:10px;padding:18px 20px;margin-bottom:20px;box-shadow:0 1px 2px rgba(10,15,61,.06);}");
        sb.AppendLine(".step h3{margin:0 0 6px;font-size:17px;color:var(--navy);font-weight:700;} .step h3 .num{color:var(--indigo);margin-right:8px}");
        sb.AppendLine(".details{color:var(--muted);font-size:13px;margin:0 0 12px} .details span{margin-right:14px}");
        sb.AppendLine(".badge{display:inline-block;padding:1px 10px;border-radius:12px;font-size:12px;font-weight:600;color:#fff;background:var(--indigo);margin-right:10px}");
        sb.AppendLine(".badge.Right{background:var(--navy)} .badge.Middle{background:var(--green)} .badge.Selection{background:var(--mid)}");
        sb.AppendLine(".step img{max-width:100%;height:auto;border:1px solid #DADCF0;border-radius:6px;display:block;}");
        sb.AppendLine(".note{color:var(--mid);font-size:13px;margin:6px 0;} .missing{color:var(--indigo);font-weight:600}");
        sb.AppendLine("a{color:var(--indigo);text-decoration:none} a:hover{text-decoration:underline}");
        sb.AppendLine("footer{margin-top:40px;border-top:1px solid var(--navy);padding-top:10px;display:flex;justify-content:space-between;color:var(--muted);font-size:12px}");
        sb.AppendLine("</style></head><body><div class=\"wrap\">");

        sb.AppendLine("<header>");
        sb.AppendLine("<div class=\"logo\">" + OmnifiBrand.LogoSvg(34, onDark: false) + "</div>");
        sb.AppendLine("<div class=\"title\"><h1>Steps recording<span class=\"dot\">&bull;</span></h1><div class=\"sub\">" +
                      E(r.StartedAt.ToString("dd MMM yyyy HH:mm")) + " &middot; " + E(OmnifiBrand.InternalUseNotice) + "</div></div>");
        sb.AppendLine("</header>");

        int saved = r.Steps.Count(s => s.ScreenshotSaved);
        sb.AppendLine("<div class=\"callout\">" + r.Steps.Count + " step" + (r.Steps.Count == 1 ? "" : "s") + " (" + r.ClickCount + " click" + (r.ClickCount == 1 ? "" : "s") + ", " + r.SelectionCount + " selection" + (r.SelectionCount == 1 ? "" : "s") + ") captured over " +
                      E(ReportGenerator.FormatDuration(r.ActiveDuration)) + " of recording on " + E(r.MachineName) +
                      (r.VideoSucceeded ? ", with video." : ", video not available.") + "</div>");

        sb.AppendLine("<h2>Recording details<span class=\"dot\">&bull;</span></h2><div class=\"rule\"></div>");
        sb.AppendLine("<table class=\"meta\">");
        Row(sb, "Started", r.StartedAt.ToString("dd MMM yyyy HH:mm:ss"));
        Row(sb, "Ended", r.EndedAt.ToString("dd MMM yyyy HH:mm:ss"));
        Row(sb, "Duration", ReportGenerator.FormatDuration(r.ActiveDuration) + " (excluding pauses)");
        Row(sb, "Total steps", r.Steps.Count + " (" + r.ClickCount + " click" + (r.ClickCount == 1 ? "" : "s") + ", " + r.SelectionCount + " selection" + (r.SelectionCount == 1 ? "" : "s") + ")");
        Row(sb, "Screenshots", saved.ToString());
        Row(sb, "Audio", r.AudioMode == "Microphone" ? "Microphone (voice narration)" : "None");
        Row(sb, "Machine", r.MachineName);
        Row(sb, "Captured display", r.CaptureDisplay);
        sb.Append("<tr><th>Video</th><td>");
        if (r.VideoSucceeded) sb.Append("<a href=\"screen.mp4\">screen.mp4</a>");
        else sb.Append("<span class=\"missing\">Video not available: " + E(r.VideoError ?? "unknown error") + "</span>");
        sb.AppendLine("</td></tr>");
        if (r.MasterScreenshotPaths.Count > 0)
        {
            sb.Append("<tr><th>All screenshots in one image</th><td>");
            sb.Append(string.Join(" &middot; ", r.MasterScreenshotPaths.Select(m => "<a href=\"" + E(Path.GetFileName(m)) + "\">" + E(Path.GetFileName(m)) + "</a>")));
            sb.AppendLine(" (full resolution, scroll through every step)</td></tr>");
        }
        Row(sb, "Output folder", r.OutputFolder);
        sb.AppendLine("</table>");

        if (r.Warnings.Count > 0)
        {
            sb.AppendLine("<h2>Warnings<span class=\"dot\">&bull;</span></h2><div class=\"rule\"></div><ul>");
            foreach (var w in r.Warnings) sb.AppendLine("<li>" + E(w) + "</li>");
            sb.AppendLine("</ul>");
        }

        sb.AppendLine("<h2>Steps<span class=\"dot\">&bull;</span></h2><div class=\"rule\"></div>");
        if (r.Steps.Count == 0) sb.AppendLine("<p>No clicks were captured during this recording.</p>");

        foreach (var s in r.Steps)
        {
            string button = ReportGenerator.ButtonName(s.Button);
            sb.AppendLine("<div class=\"step\" id=\"step-" + s.StepNumber + "\">");
            sb.AppendLine("<h3><span class=\"num\">" + s.StepNumber + ".</span>" + E(s.Description) + "</h3>");
            sb.Append("<div class=\"details\">");
            if (s.Kind == StepKind.Selection)
                sb.Append("<span class=\"badge Selection\">Selection (" + button.ToLowerInvariant() + " drag)</span>");
            else
                sb.Append("<span class=\"badge " + button + "\">" + button + " click</span>");
            sb.Append("<span>Time " + E(ReportGenerator.FormatWall(s.WallTime)) + "</span>");
            sb.Append("<span>Video offset " + E(ReportGenerator.FormatOffset(s.VideoOffset)) + "</span>");
            if (s.Kind == StepKind.Selection)
                sb.Append("<span>From (" + s.X + ", " + s.Y + ") to (" + s.EndX + ", " + s.EndY + ")</span>");
            else
                sb.Append("<span>Cursor (" + s.X + ", " + s.Y + ")</span>");
            sb.Append("<span>Window " + E(s.Window.DisplayTitle) + (string.IsNullOrEmpty(s.Window.ProcessName) ? "" : " (" + E(s.Window.ProcessName) + ".exe)") + "</span>");
            if (s.Element != null)
            {
                sb.Append("<span>UI element " + E(s.Element.ControlType));
                if (!string.IsNullOrEmpty(s.Element.Name)) sb.Append(" &ldquo;" + E(s.Element.Name) + "&rdquo;");
                if (!string.IsNullOrEmpty(s.Element.AutomationId)) sb.Append(" [" + E(s.Element.AutomationId) + "]");
                sb.Append("</span>");
            }
            sb.AppendLine("</div>");
            if (!string.IsNullOrEmpty(s.Note)) sb.AppendLine("<div class=\"note\">" + E(s.Note) + "</div>");
            if (s.ScreenshotSaved)
            {
                sb.AppendLine("<a href=\"" + E(s.ScreenshotRelativePath) + "\" target=\"_blank\"><img src=\"" + E(s.ScreenshotRelativePath) +
                              "\" alt=\"Screenshot for step " + s.StepNumber + "\" loading=\"lazy\"></a>");
                sb.AppendLine("<div class=\"details\" style=\"margin:8px 0 0\">Screenshot <a href=\"" + E(s.ScreenshotRelativePath) + "\">" + E(s.ScreenshotRelativePath) + "</a></div>");
            }
            else
            {
                sb.AppendLine("<div class=\"missing\">Screenshot not available for this step.</div>");
            }
            sb.AppendLine("</div>");
        }

        sb.AppendLine("<footer><span>" + E(OmnifiBrand.InternalUseNotice) + ". Generated locally by " + E(OmnifiBrand.ProductName) + "; no data leaves this machine.</span><span>" +
                      E(r.EndedAt.ToString("dd MMM yyyy")) + "</span></footer>");
        sb.AppendLine("</div></body></html>");
        File.WriteAllText(path, sb.ToString(), new UTF8Encoding(false));
    }

    private static void Row(StringBuilder sb, string key, string value) =>
        sb.AppendLine("<tr><th>" + E(key) + "</th><td>" + E(value) + "</td></tr>");

    private static string E(string? s) => WebUtility.HtmlEncode(s ?? string.Empty);
}
