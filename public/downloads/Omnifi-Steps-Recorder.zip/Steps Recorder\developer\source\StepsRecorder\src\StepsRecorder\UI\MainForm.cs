using System.Diagnostics;
using StepsRecorder.AI;
using StepsRecorder.Branding;
using StepsRecorder.Describing;
using StepsRecorder.Export;
using StepsRecorder.Models;
using StepsRecorder.Recording;
using StepsRecorder.Reporting;

namespace StepsRecorder.UI;

public sealed class MainForm : Form
{
    private const string PrivacyNotice =
        "Privacy notice\r\n" +
        "Nothing is recorded until you press Start. Recording ends when you press Stop or close this window.\r\n" +
        "Everything is saved only to the local folder you choose. There is no cloud upload, telemetry, analytics or remote API.\r\n" +
        "The video and screenshots capture whatever is visible on the primary display. Avoid showing passwords, personal or confidential data while recording.\r\n" +
        "Clicks and click-and-drag selections become steps with screenshots. No audio is recorded unless you tick \"Record my voice\" (microphone only, never system audio).\r\n" +
        "The \"Omnifi SuperTools\" button simply opens the SuperTools website in your browser when you click it; no recording data is sent.\r\n" +
        "AI SOP (on by default, can be switched off under \"AI SOP...\"): after a recording, the step descriptions and reduced screenshots are sent to Omnifi's SuperTools server, which uses an AI model to write the SOP. Screenshots are processed in memory and not stored there. Do not use it for recordings that show confidential data.";

    private readonly Panel _header = new();
    private readonly PictureBox _logo = new();
    private readonly Label _titleLabel = new();
    private readonly Label _subtitleLabel = new();
    private readonly Button _privacyButton = new();
    private readonly Button _superToolsButton = new();
    private readonly CheckBox _aiCheck = new();
    private readonly RecordingBar _bar = new();
    private readonly Button _sopButton = new();
    private bool _sopRunning;
    private readonly TextBox _folderBox = new();
    private readonly Button _browseButton = new();
    private readonly Button _startButton = new();
    private readonly Button _pauseButton = new();
    private readonly Button _stopButton = new();
    private readonly CheckBox _minimizeCheck = new();
    private readonly CheckBox _voiceCheck = new();
    private readonly Label _statusLabel = new();
    private readonly Label _elapsedLabel = new();
    private readonly Label _clicksLabel = new();
    private readonly ListView _artifacts = new();
    private readonly Button _openFolderButton = new();
    private readonly Button _openItemButton = new();
    private readonly Button _revealItemButton = new();
    private readonly Button _zipButton = new();
    private readonly TextBox _log = new();
    private readonly Label _footerLabel = new();
    private readonly System.Windows.Forms.Timer _timer = new();

    /// <summary>Seconds of on-screen countdown between pressing Start and the first captured frame.</summary>
    private const int CountdownSeconds = 3;

    private readonly Button _shortcutsButton = new();
    private readonly NotifyIcon _tray = new();
    private readonly AppSettings _settings = AppSettings.Load();
    private readonly bool _startHidden;
    private CtrlPairHotkey? _hotkey;
    private ApplicationContext? _appContext;
    private bool _exiting;
    private bool _trayTipShown;

    private RecordingSession? _session;
    private RecordingResult? _lastResult;
    private bool _closeAfterStop;
    private bool _busy;

    public MainForm(bool startHidden = false)
    {
        _startHidden = startHidden;
        Text = OmnifiBrand.ProductName;
        // Fixed, compact default size: no resizing or maximizing, so the layout always looks as designed.
        FormBorderStyle = FormBorderStyle.FixedSingle;
        MaximizeBox = false;
        ClientSize = new Size(900, 690);
        StartPosition = FormStartPosition.CenterScreen;
        Font = OmnifiBrand.BodyFont(9.75f);
        BackColor = OmnifiBrand.OffWhite;
        ForeColor = OmnifiBrand.BodyNavy;
        try { Icon = OmnifiBrand.CreateAppIcon(); } catch { /* icon is optional */ }

        BuildLayout();
        _timer.Interval = 250;
        _timer.Tick += (_, _) => UpdateLiveStatus();
        // Floating Pause/Stop bar shown while recording; it and this window are excluded from screen capture.
        _bar.PauseResumeClicked += (_, _) => TogglePause();
        _bar.StopClicked += async (_, _) => await StopAsync();
        _bar.OpenClicked += (_, _) => ShowFromTray();
        CaptureExclusion.Apply(this);
        SetUiState(SessionState.Idle);
        Log("Ready. Choose a destination folder and press Start. See \"Privacy notice\" for what is recorded.");

        InitTray();
        ApplyShortcutSettings(showErrors: false);
    }

    /// <summary>Hosts the message loop so the window can start hidden (tray mode) and exit explicitly.</summary>
    public ApplicationContext RunContext()
    {
        _appContext = new ApplicationContext();
        if (!_startHidden)
        {
            Show();
        }
        else
        {
            _ = Handle; // create the window handle so cross-thread BeginInvoke works while hidden
            Log("Started in the background. Press " + CtrlPairHotkey.DisplayName + " or use the tray icon to open the window.");
        }
        return _appContext;
    }

    // ---------------------------------------------------------------- layout

    private void BuildLayout()
    {
        var root = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3, BackColor = OmnifiBrand.OffWhite };
        root.RowStyles.Add(new RowStyle(SizeType.AutoSize)); // header
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100)); // content
        root.RowStyles.Add(new RowStyle(SizeType.AutoSize)); // footer
        Controls.Add(root);

        // Brand header: deep navy band, logo top-left, product title with brand dot, subtitle in lavender.
        _header.Dock = DockStyle.Top;
        _header.Height = 84;
        _header.BackColor = OmnifiBrand.DeepNavy;
        _header.Padding = new Padding(20, 14, 20, 14);
        _logo.Image = OmnifiBrand.RenderLogo(40, onDark: true);
        _logo.SizeMode = PictureBoxSizeMode.AutoSize;
        _logo.BackColor = Color.Transparent;
        _logo.Location = new Point(20, 22);
        _titleLabel.Text = "Steps Recorder";
        _titleLabel.Font = OmnifiBrand.HeadlineFont(16f);
        _titleLabel.ForeColor = OmnifiBrand.White;
        _titleLabel.BackColor = Color.Transparent;
        _titleLabel.AutoSize = true;
        _titleLabel.Location = new Point(200, 16);
        var dot = new Label { Text = "•", Font = OmnifiBrand.HeadlineFont(16f), ForeColor = OmnifiBrand.IndigoBright, BackColor = Color.Transparent, AutoSize = true };
        _subtitleLabel.Text = "Video, click screenshots and a step report. All kept on this PC.";
        _subtitleLabel.Font = OmnifiBrand.BodyFont(9.5f);
        _subtitleLabel.ForeColor = OmnifiBrand.Lavender;
        _subtitleLabel.BackColor = Color.Transparent;
        _subtitleLabel.AutoSize = true;
        _subtitleLabel.Location = new Point(200, 48);
        // Omnifi SuperTools: right-aligned call-to-action in the header, opens the web app in the default browser.
        _superToolsButton.Text = OmnifiBrand.SuperToolsName;
        _superToolsButton.FlatStyle = FlatStyle.Flat;
        _superToolsButton.FlatAppearance.BorderColor = OmnifiBrand.Lavender;
        _superToolsButton.FlatAppearance.BorderSize = 1;
        _superToolsButton.FlatAppearance.MouseOverBackColor = OmnifiBrand.IndigoBright;
        _superToolsButton.BackColor = OmnifiBrand.MidNavy;
        _superToolsButton.ForeColor = OmnifiBrand.White;
        _superToolsButton.Font = OmnifiBrand.HeadlineFont(9.5f);
        _superToolsButton.Cursor = Cursors.Hand;
        _superToolsButton.Size = new Size(170, 36);
        _superToolsButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        _superToolsButton.Click += (_, _) => OpenSuperTools();
        var toolTip = new ToolTip();
        toolTip.SetToolTip(_superToolsButton, "Open " + OmnifiBrand.SuperToolsName + " in your browser (" + OmnifiBrand.SuperToolsUrl + ")");
        _header.Controls.AddRange(new Control[] { _logo, _titleLabel, dot, _subtitleLabel, _superToolsButton });
        _header.Resize += (_, _) => _superToolsButton.Location = new Point(_header.ClientSize.Width - _superToolsButton.Width - 20, (_header.ClientSize.Height - _superToolsButton.Height) / 2);
        _titleLabel.SizeChanged += (_, _) => dot.Location = new Point(_titleLabel.Right - 2, _titleLabel.Top);
        dot.Location = new Point(_titleLabel.Right - 2, _titleLabel.Top);
        _header.Resize += (_, _) => _subtitleLabel.MaximumSize = new Size(Math.Max(200, _header.ClientSize.Width - 220 - 200), 0);
        _subtitleLabel.MaximumSize = new Size(Math.Max(200, ClientSize.Width - 220 - 200), 0);
        root.Controls.Add(_header, 0, 0);

        var content = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 5, Padding = new Padding(20, 14, 20, 6), BackColor = OmnifiBrand.OffWhite };
        // Fixed window, so fixed row heights: no gaps, and the file list gets a usable height.
        content.RowStyles.Add(new RowStyle(SizeType.Absolute, 48));  // folder
        content.RowStyles.Add(new RowStyle(SizeType.Absolute, 92));  // controls (buttons + option checkboxes on a second line)
        content.RowStyles.Add(new RowStyle(SizeType.Absolute, 36));  // status
        content.RowStyles.Add(new RowStyle(SizeType.Absolute, 250)); // artifacts
        content.RowStyles.Add(new RowStyle(SizeType.Percent, 100));  // log
        root.Controls.Add(content, 0, 1);

        // Folder row
        var folderRow = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 3, RowCount = 1, Margin = new Padding(0, 0, 0, 6) };
        folderRow.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
        folderRow.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        folderRow.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
        folderRow.Controls.Add(new Label { Text = "Save recordings to", AutoSize = true, Anchor = AnchorStyles.Left, ForeColor = OmnifiBrand.DeepNavy, Font = OmnifiBrand.HeadlineFont(9.5f), Margin = new Padding(0, 7, 10, 0) }, 0, 0);
        _folderBox.ReadOnly = true;
        _folderBox.Dock = DockStyle.Fill;
        _folderBox.BorderStyle = BorderStyle.FixedSingle;
        _folderBox.BackColor = OmnifiBrand.White;
        _folderBox.ForeColor = OmnifiBrand.BodyNavy;
        _folderBox.PlaceholderText = "No folder selected. A local destination folder is required before you can start.";
        folderRow.Controls.Add(_folderBox, 1, 0);
        StyleSecondary(_browseButton, "Choose folder...");
        _browseButton.Click += (_, _) => ChooseFolder();
        folderRow.Controls.Add(_browseButton, 2, 0);
        content.Controls.Add(folderRow, 0, 0);

        // Control row
        var controls = new FlowLayoutPanel { Dock = DockStyle.Fill, Margin = new Padding(0, 0, 0, 4), WrapContents = true };
        StylePrimary(_startButton, "Start recording");
        _startButton.Click += async (_, _) => await StartAsync();
        StyleSecondary(_pauseButton, "Pause");
        _pauseButton.Click += (_, _) => TogglePause();
        StyleSecondary(_stopButton, "Stop");
        _stopButton.Click += async (_, _) => await StopAsync();
        _minimizeCheck.Text = "Minimize while recording";
        _minimizeCheck.Checked = true;
        _minimizeCheck.AutoSize = true;
        _minimizeCheck.ForeColor = OmnifiBrand.BodyNavy;
        _minimizeCheck.Margin = new Padding(16, 10, 0, 0);
        _voiceCheck.Text = "Record my voice (mic)";
        _voiceCheck.Checked = false;
        _voiceCheck.AutoSize = true;
        _voiceCheck.ForeColor = OmnifiBrand.BodyNavy;
        _voiceCheck.Margin = new Padding(16, 10, 0, 0);
        StyleSecondary(_shortcutsButton, "Shortcuts...");
        _shortcutsButton.Click += (_, _) => ShowShortcutsDialog();
        StyleSecondary(_privacyButton, "Privacy notice");
        _privacyButton.Click += (_, _) => ShowPrivacyNotice();
        _aiCheck.Text = "Write AI SOP after recording";
        _aiCheck.Checked = _settings.AiSopEnabled;
        _aiCheck.AutoSize = true;
        _aiCheck.ForeColor = OmnifiBrand.BodyNavy;
        _aiCheck.Margin = new Padding(16, 10, 0, 0);
        _aiCheck.CheckedChanged += (_, _) =>
        {
            _settings.AiSopEnabled = _aiCheck.Checked;
            _settings.Save();
            Log("AI SOP after recording: " + (_aiCheck.Checked ? "on" : "off") + ".");
            if (_aiCheck.Checked) _ = RefreshAiAllowanceAsync();
        };
        var aiTip = new ToolTip();
        aiTip.SetToolTip(_aiCheck, "After each recording the steps and reduced screenshots are sent to Omnifi's SuperTools server, which writes sop.docx/html/md with AI. 5 SOPs per 5 hours per computer. Do not use for confidential recordings.");
        controls.Controls.AddRange(new Control[] { _startButton, _pauseButton, _stopButton, _shortcutsButton, _privacyButton, _minimizeCheck, _voiceCheck, _aiCheck });
        content.Controls.Add(controls, 0, 1);

        // Status row
        var status = new FlowLayoutPanel { Dock = DockStyle.Fill, Margin = new Padding(0, 0, 0, 6), WrapContents = false };
        _statusLabel.AutoSize = true;
        _statusLabel.Font = OmnifiBrand.HeadlineFont(10.5f);
        _elapsedLabel.AutoSize = true;
        _elapsedLabel.ForeColor = OmnifiBrand.MutedIndigo;
        _elapsedLabel.Margin = new Padding(24, 3, 0, 0);
        _clicksLabel.AutoSize = true;
        _clicksLabel.ForeColor = OmnifiBrand.MutedIndigo;
        _clicksLabel.Margin = new Padding(24, 3, 0, 0);
        status.Controls.AddRange(new Control[] { _statusLabel, _elapsedLabel, _clicksLabel });
        content.Controls.Add(status, 0, 2);

        // Artifacts
        var outputGroup = MakeGroup("Output files (double-click to open)");
        var outputLayout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1 };
        outputLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        outputLayout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        _artifacts.Dock = DockStyle.Fill;
        _artifacts.View = View.Details;
        _artifacts.FullRowSelect = true;
        _artifacts.MultiSelect = false;
        _artifacts.HideSelection = false;
        _artifacts.BorderStyle = BorderStyle.FixedSingle;
        _artifacts.BackColor = OmnifiBrand.White;
        _artifacts.ForeColor = OmnifiBrand.BodyNavy;
        _artifacts.Columns.Add("File", 220);
        _artifacts.Columns.Add("Type", 160);
        _artifacts.Columns.Add("Size", 90, HorizontalAlignment.Right);
        _artifacts.Columns.Add("Full path", 400);
        _artifacts.DoubleClick += (_, _) => OpenSelectedArtifact();
        _artifacts.SelectedIndexChanged += (_, _) => RefreshButtons();
        outputLayout.Controls.Add(_artifacts, 0, 0);

        var outputButtons = new FlowLayoutPanel { Dock = DockStyle.Top, AutoSize = true, Padding = new Padding(0, 6, 0, 0) };
        StylePrimary(_openFolderButton, "Open output folder");
        _openFolderButton.Click += (_, _) => OpenOutputFolder();
        StyleSecondary(_openItemButton, "Open selected");
        _openItemButton.Click += (_, _) => OpenSelectedArtifact();
        StyleSecondary(_revealItemButton, "Show in Explorer");
        _revealItemButton.Click += (_, _) => RevealSelectedArtifact();
        StyleSecondary(_zipButton, "Export ZIP");
        _zipButton.Click += async (_, _) => await ExportZipAsync();
        StyleSecondary(_sopButton, "Generate AI SOP");
        _sopButton.Click += async (_, _) => { if (_lastResult != null) await GenerateSopAsync(_lastResult, manual: true); };
        outputButtons.Controls.AddRange(new Control[] { _openFolderButton, _openItemButton, _revealItemButton, _zipButton, _sopButton });
        outputLayout.Controls.Add(outputButtons, 0, 1);
        outputGroup.Controls.Add(outputLayout);
        content.Controls.Add(outputGroup, 0, 3);

        // Log
        var logGroup = MakeGroup("Activity log");
        _log.Multiline = true;
        _log.ReadOnly = true;
        _log.ScrollBars = ScrollBars.Vertical;
        _log.Dock = DockStyle.Fill;
        _log.BorderStyle = BorderStyle.FixedSingle;
        _log.BackColor = OmnifiBrand.White;
        _log.ForeColor = OmnifiBrand.BodyNavy;
        _log.Font = new Font("Consolas", 9f);
        logGroup.Controls.Add(_log);
        content.Controls.Add(logGroup, 0, 4);

        // Footer: thin navy rule + internal-use notice.
        var footer = new Panel { Dock = DockStyle.Top, Height = 34, BackColor = OmnifiBrand.OffWhite, Padding = new Padding(20, 8, 20, 0) };
        footer.Paint += (_, e) =>
        {
            using var pen = new Pen(OmnifiBrand.DeepNavy, 1f);
            e.Graphics.DrawLine(pen, 20, 0, footer.Width - 20, 0);
        };
        _footerLabel.Text = OmnifiBrand.InternalUseNotice + "   •   Version " + (typeof(MainForm).Assembly.GetName().Version?.ToString(3) ?? "0.1.0");
        _footerLabel.Font = OmnifiBrand.BodyFont(8.5f);
        _footerLabel.ForeColor = OmnifiBrand.MutedIndigo;
        _footerLabel.AutoSize = true;
        _footerLabel.Location = new Point(20, 10);
        footer.Controls.Add(_footerLabel);
        root.Controls.Add(footer, 0, 2);
    }

    private static GroupBox MakeGroup(string title)
    {
        return new GroupBox
        {
            Text = title,
            Dock = DockStyle.Fill,
            Margin = new Padding(0, 0, 0, 8),
            ForeColor = OmnifiBrand.DeepNavy,
            Font = OmnifiBrand.HeadlineFont(9.5f),
            Padding = new Padding(10, 6, 10, 10)
        };
    }

    private static void StylePrimary(Button b, string text)
    {
        b.Text = text;
        b.AutoSize = true;
        b.MinimumSize = new Size(150, 38);
        b.FlatStyle = FlatStyle.Flat;
        b.FlatAppearance.BorderSize = 0;
        b.BackColor = OmnifiBrand.IndigoBright;
        b.ForeColor = OmnifiBrand.White;
        b.Font = OmnifiBrand.HeadlineFont(9.75f);
        b.Cursor = Cursors.Hand;
        b.Margin = new Padding(0, 0, 10, 0);
        b.EnabledChanged += (_, _) => b.BackColor = b.Enabled ? OmnifiBrand.IndigoBright : OmnifiBrand.Lavender;
    }

    private static void StyleSecondary(Button b, string text)
    {
        b.Text = text;
        b.AutoSize = true;
        b.MinimumSize = new Size(120, 38);
        b.FlatStyle = FlatStyle.Flat;
        b.FlatAppearance.BorderColor = OmnifiBrand.IndigoBright;
        b.FlatAppearance.BorderSize = 1;
        b.BackColor = OmnifiBrand.White;
        b.ForeColor = OmnifiBrand.DeepNavy;
        b.Font = OmnifiBrand.BodyFont(9.75f);
        b.Cursor = Cursors.Hand;
        b.Margin = new Padding(0, 0, 10, 0);
        b.EnabledChanged += (_, _) =>
        {
            b.ForeColor = b.Enabled ? OmnifiBrand.DeepNavy : OmnifiBrand.MutedIndigo;
            b.FlatAppearance.BorderColor = b.Enabled ? OmnifiBrand.IndigoBright : OmnifiBrand.Lavender;
        };
    }

    // ---------------------------------------------------------------- actions

    private void ChooseFolder()
    {
        using var dialog = new FolderBrowserDialog
        {
            Description = "Choose the local folder where the recording folder will be created",
            UseDescriptionForTitle = true,
            ShowNewFolderButton = true
        };
        if (!string.IsNullOrEmpty(_folderBox.Text) && Directory.Exists(_folderBox.Text)) dialog.InitialDirectory = _folderBox.Text;
        if (dialog.ShowDialog(this) == DialogResult.OK)
        {
            _folderBox.Text = dialog.SelectedPath;
            Log("Destination folder: " + dialog.SelectedPath);
            RefreshButtons();
        }
    }

    private async Task StartAsync()
    {
        if (_busy || _session != null) return;
        if (string.IsNullOrWhiteSpace(_folderBox.Text) || !Directory.Exists(_folderBox.Text))
        {
            MessageBox.Show(this, "Choose an existing local destination folder first.", "Destination folder required", MessageBoxButtons.OK, MessageBoxIcon.Information);
            ChooseFolder();
            if (string.IsNullOrWhiteSpace(_folderBox.Text) || !Directory.Exists(_folderBox.Text)) return;
        }

        _busy = true;
        SetUiState(SessionState.Starting);
        _artifacts.Items.Clear();
        _lastResult = null;

        RecordingSession? session = null;
        try
        {
            // Give the user a moment to switch to the application they want to demonstrate.
            if (_minimizeCheck.Checked) WindowState = FormWindowState.Minimized;
            Log("Get ready: recording starts in " + CountdownSeconds + " seconds...");
            await CountdownOverlay.RunAsync(CountdownSeconds);

            bool voice = _voiceCheck.Checked;
            session = new RecordingSession(_folderBox.Text, new ScreenRecorderLibVideoRecorder { RecordMicrophone = voice }, CompositeStepDescriber.CreateDefault(), Handle)
            {
                AudioMode = voice ? "Microphone" : "None"
            };
            session.StepCaptured += OnStepCaptured;
            session.VideoFailed += OnVideoFailed;
            session.Warning += (_, msg) => Log("Warning: " + msg);
            Log(voice ? "Starting video recorder with microphone..." : "Starting video recorder (no audio)...");
            await session.StartAsync();
            _session = session;
            Log("Recording to " + session.OutputFolder);
            SetUiState(SessionState.Recording);
            _timer.Start();
            _bar.Update(SessionState.Recording, TimeSpan.Zero, 0);
            _bar.Show();
            if (_minimizeCheck.Checked) WindowState = FormWindowState.Minimized;
        }
        catch (Exception ex)
        {
            session?.Dispose();
            Log("Start failed: " + ex.Message);
            SetUiState(SessionState.Idle);
            if (WindowState == FormWindowState.Minimized) WindowState = FormWindowState.Normal;
            ShowError("Recording could not start", ex);
        }
        finally
        {
            _busy = false;
            RefreshButtons();
        }
    }

    private void TogglePause()
    {
        if (_session == null || _busy) return;
        try
        {
            if (_session.State == SessionState.Recording)
            {
                _session.Pause();
                Log("Paused.");
                SetUiState(SessionState.Paused);
            }
            else if (_session.State == SessionState.Paused)
            {
                _session.Resume();
                Log("Resumed.");
                SetUiState(SessionState.Recording);
                if (_minimizeCheck.Checked) WindowState = FormWindowState.Minimized;
            }
        }
        catch (Exception ex)
        {
            Log("Pause/Resume failed: " + ex.Message);
            ShowError("Pause/Resume failed", ex);
        }
    }

    private async Task StopAsync()
    {
        if (_session == null || _busy) return;
        _busy = true;
        var session = _session;
        SetUiState(SessionState.Stopping);
        _timer.Stop();
        _bar.Hide();
        Log("Stopping... finalizing video and writing reports.");
        try
        {
            RecordingResult result = await session.StopAsync();
            _lastResult = result;
            _session = null;
            session.Dispose();
            ShowResult(result);
        }
        catch (Exception ex)
        {
            Log("Stop failed: " + ex.Message);
            try { session.Abort(); } catch { /* ignore */ }
            session.Dispose();
            _session = null;
            ShowError("Stopping the recording failed", ex);
            SetUiState(SessionState.Idle);
        }
        finally
        {
            _busy = false;
            RefreshButtons();
            if (WindowState == FormWindowState.Minimized) WindowState = FormWindowState.Normal;
            Activate();
            if (_closeAfterStop) Close();
        }
    }

    private void ShowResult(RecordingResult result)
    {
        SetUiState(SessionState.Stopped);
        Log($"Finished. {result.Steps.Count} click(s), {ReportGenerator.FormatDuration(result.ActiveDuration)} recorded.");
        if (!result.VideoSucceeded)
        {
            Log("Video was NOT saved: " + (result.VideoError ?? "unknown error"));
            MessageBox.Show(this,
                "The screenshots and reports were saved, but the video could not be recorded:\r\n\r\n" + (result.VideoError ?? "unknown error") +
                "\r\n\r\nCheck that the Visual C++ Redistributable (x64) and Media Foundation are installed.",
                "Video recording failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
        foreach (var w in result.Warnings) Log("Warning: " + w);
        PopulateArtifacts(result);
        Log("Output folder: " + result.OutputFolder);

        if (_settings.AiSopEnabled && result.Steps.Count > 0)
            _ = GenerateSopAsync(result, manual: false);
    }

    /// <summary>Asks the Omnifi AI service for an SOP from the finished recording and adds sop.docx/html/md to the outputs.</summary>
    private async Task GenerateSopAsync(RecordingResult result, bool manual)
    {
        if (_sopRunning) return;
        _sopRunning = true;
        RefreshButtons();
        _statusLabel.Text = "Writing AI SOP...";
        _statusLabel.ForeColor = OmnifiBrand.IndigoBright;
        Log("AI SOP: sending " + result.Steps.Count + " steps and their screenshots to the Omnifi AI service...");
        var progress = new Progress<string>(msg => Log("AI SOP: " + msg));
        try
        {
            SopResult sop = await SopGenerator.GenerateAsync(result, _settings.EnsureDeviceId, progress, CancellationToken.None);
            Log($"AI SOP ready: \"{sop.Document.Title}\" with {sop.Document.Steps.Count} procedure steps ({sop.ImagesSent} screenshots analysed).");
            if (sop.Allowance != null) Log("AI SOP: " + sop.Allowance.Describe());
            AddArtifact(sop.DocxPath, "AI SOP (Word)", true);
            AddArtifact(sop.HtmlPath, "AI SOP (HTML)", true);
            AddArtifact(sop.MarkdownPath, "AI SOP (Markdown)", true);
            if (manual) MessageBox.Show(this, "SOP generated:\r\n" + sop.DocxPath + "\r\n\r\nPlease review it for accuracy before sharing.", "AI SOP", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex)
        {
            Log("AI SOP failed: " + ex.Message);
            MessageBox.Show(this, "The AI SOP could not be generated:\r\n\r\n" + ex.Message + "\r\n\r\nYour recording, screenshots and reports are saved; you can retry with \"Generate AI SOP\".", "AI SOP", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
        finally
        {
            _sopRunning = false;
            if (_session == null) SetUiState(_lastResult != null ? SessionState.Stopped : SessionState.Idle);
            RefreshButtons();
        }
    }

    /// <summary>Shows the remaining AI SOP allowance in the log (a status read; it does not consume a request).</summary>
    private async Task RefreshAiAllowanceAsync()
    {
        try
        {
            using var client = new SopServiceClient(_settings.EnsureDeviceId);
            SopServiceStatus status = await client.GetStatusAsync(CancellationToken.None);
            if (IsDisposed) return;
            Log(status.Configured
                ? "AI SOP: " + (status.Allowance?.Describe() ?? "allowance unknown.")
                : "AI SOP: the service is not configured on the server yet; ask the administrator.");
        }
        catch (Exception ex)
        {
            if (IsDisposed) return;
            Log("AI SOP: allowance unavailable (" + ex.Message + ")");
        }
    }

    private void PopulateArtifacts(RecordingResult result)
    {
        _artifacts.BeginUpdate();
        _artifacts.Items.Clear();
        AddArtifact(result.VideoPath, "Screen video (MP4)", result.VideoSucceeded);
        AddArtifact(result.HtmlPath, "HTML report", true);
        AddArtifact(result.DocxPath, "Word report (DOCX)", true);
        AddArtifact(result.SummaryPath, "Summary (TXT)", true);
        foreach (var s in result.Steps)
            AddArtifact(s.ScreenshotFullPath, $"Screenshot, step {s.StepNumber}", s.ScreenshotSaved);
        _artifacts.EndUpdate();
        if (_artifacts.Items.Count > 0) _artifacts.Items[0].Selected = true;
    }

    private void AddArtifact(string? path, string type, bool expected)
    {
        if (string.IsNullOrEmpty(path)) return;
        bool exists = File.Exists(path);
        var item = new ListViewItem(Path.GetFileName(path));
        item.SubItems.Add(exists ? type : type + " (missing)");
        item.SubItems.Add(exists ? ReportGenerator.FormatBytes(new FileInfo(path).Length) : "-");
        item.SubItems.Add(path);
        item.Tag = path;
        if (!exists) item.ForeColor = expected ? OmnifiBrand.IndigoBright : OmnifiBrand.MutedIndigo;
        _artifacts.Items.Add(item);
    }

    private async Task ExportZipAsync()
    {
        if (_lastResult == null || _busy) return;
        _busy = true;
        RefreshButtons();
        string folder = _lastResult.OutputFolder;
        Log("Creating ZIP of " + folder + " ...");
        try
        {
            string zip = await Task.Run(() => ZipExporter.Export(folder));
            Log("ZIP created: " + zip);
            AddArtifact(zip, "ZIP export", true);
            MessageBox.Show(this, "ZIP created:\r\n" + zip + "\r\n\r\nThe original recording folder was left unchanged.", "Export ZIP", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex)
        {
            Log("ZIP export failed: " + ex.Message);
            ShowError("ZIP export failed", ex);
        }
        finally
        {
            _busy = false;
            RefreshButtons();
        }
    }

    private void OpenOutputFolder()
    {
        string? folder = _lastResult?.OutputFolder ?? _session?.OutputFolder;
        if (string.IsNullOrEmpty(folder) || !Directory.Exists(folder)) return;
        TryShell("explorer.exe", "\"" + folder + "\"");
    }

    private void OpenSelectedArtifact()
    {
        string? path = SelectedArtifactPath();
        if (path == null || !File.Exists(path)) return;
        try
        {
            Process.Start(new ProcessStartInfo(path) { UseShellExecute = true });
        }
        catch (Exception ex)
        {
            Log("Could not open " + path + ": " + ex.Message);
        }
    }

    private void RevealSelectedArtifact()
    {
        string? path = SelectedArtifactPath();
        if (path == null || !File.Exists(path)) return;
        TryShell("explorer.exe", "/select,\"" + path + "\"");
    }

    private string? SelectedArtifactPath() =>
        _artifacts.SelectedItems.Count == 0 ? null : _artifacts.SelectedItems[0].Tag as string;

    private static void TryShell(string exe, string args)
    {
        try { Process.Start(new ProcessStartInfo(exe, args) { UseShellExecute = true }); }
        catch { /* ignore */ }
    }

    // ---------------------------------------------------------------- session events (UI thread)

    private void OnStepCaptured(object? sender, StepRecord step)
    {
        Log($"Step {step.StepNumber}: {step.Description}" + (step.ScreenshotSaved ? "" : " [screenshot missing]"));
        UpdateLiveStatus();
    }

    private async void OnVideoFailed(object? sender, string error)
    {
        if (_session == null) return;
        Log("Video recorder failed: " + error + ". Stopping and saving what was captured.");
        MessageBox.Show(this, "The video recorder reported an error:\r\n\r\n" + error + "\r\n\r\nThe recording will be stopped; screenshots and reports captured so far will be saved.",
            "Video recording failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
        await StopAsync();
    }

    // ---------------------------------------------------------------- UI state

    private void SetUiState(SessionState state)
    {
        _statusLabel.Text = state switch
        {
            SessionState.Idle => "Not recording",
            SessionState.Starting => "Starting...",
            SessionState.Recording => "Recording",
            SessionState.Paused => "Paused",
            SessionState.Stopping => "Stopping...",
            SessionState.Stopped => "Finished",
            _ => "Error"
        };
        _statusLabel.ForeColor = state switch
        {
            SessionState.Recording => OmnifiBrand.IndigoBright,
            SessionState.Paused => OmnifiBrand.MutedIndigo,
            SessionState.Stopped => OmnifiBrand.AccentGreen,
            _ => OmnifiBrand.DeepNavy
        };
        _pauseButton.Text = state == SessionState.Paused ? "Resume" : "Pause";
        Text = state is SessionState.Recording or SessionState.Paused ? OmnifiBrand.ProductName + ": " + _statusLabel.Text : OmnifiBrand.ProductName;
        UpdateLiveStatus();
        RefreshButtons();
    }

    private void RefreshButtons()
    {
        bool active = _session != null && _session.State is SessionState.Recording or SessionState.Paused;
        bool idle = _session == null && !_busy;
        _startButton.Enabled = idle && !string.IsNullOrWhiteSpace(_folderBox.Text);
        _browseButton.Enabled = idle;
        _voiceCheck.Enabled = idle;
        _pauseButton.Enabled = active && !_busy;
        _stopButton.Enabled = active && !_busy;
        bool hasResult = _lastResult != null && !_busy;
        _openFolderButton.Enabled = hasResult || _session != null;
        _zipButton.Enabled = hasResult;
        _sopButton.Enabled = hasResult && !_sopRunning && _lastResult!.Steps.Count > 0;
        _sopButton.Text = _sopRunning ? "Writing SOP..." : "Generate AI SOP";
        _aiCheck.Enabled = !_sopRunning;
        bool hasSelection = _artifacts.SelectedItems.Count > 0;
        _openItemButton.Enabled = hasSelection;
        _revealItemButton.Enabled = hasSelection;
    }

    private void UpdateLiveStatus()
    {
        if (_session != null)
        {
            _elapsedLabel.Text = "Elapsed " + ReportGenerator.FormatDuration(_session.ActiveDuration);
            _clicksLabel.Text = "Clicks captured " + _session.StepCount;
            if (_bar.Visible) _bar.Update(_session.State, _session.ActiveDuration, _session.StepCount);
        }
        else if (_lastResult != null)
        {
            _elapsedLabel.Text = "Elapsed " + ReportGenerator.FormatDuration(_lastResult.ActiveDuration);
            _clicksLabel.Text = "Clicks captured " + _lastResult.Steps.Count;
        }
        else
        {
            _elapsedLabel.Text = "Elapsed 00:00:00";
            _clicksLabel.Text = "Clicks captured 0";
        }
    }

    private void Log(string message)
    {
        if (IsDisposed) return;
        string line = DateTime.Now.ToString("HH:mm:ss") + "  " + message + Environment.NewLine;
        _log.AppendText(line);
    }

    private void ShowError(string title, Exception ex)
    {
        string detail = ex.Message;
        if (ex.InnerException != null) detail += "\r\n\r\nDetails: " + ex.InnerException.Message;
        MessageBox.Show(this, detail, title, MessageBoxButtons.OK, MessageBoxIcon.Error);
    }

    protected override void OnHandleCreated(EventArgs e)
    {
        base.OnHandleCreated(e);
        // Taskbar identity: own icon and relaunch command when the user pins the app (host process is dotnet.exe).
        Native.TaskbarIdentity.Apply(Handle, ShortcutManager.RelaunchCommandLine(), OmnifiBrand.ProductName, ShortcutManager.IconPath());
    }

    // ---------------------------------------------------------------- closing / cleanup

    protected override void OnFormClosing(FormClosingEventArgs e)
    {
        // With the global shortcut enabled the app keeps running in the tray so the shortcut still works.
        if (!_exiting && _settings.HotkeyEnabled && _session == null && e.CloseReason == CloseReason.UserClosing)
        {
            e.Cancel = true;
            HideToTray();
            return;
        }

        if (_session != null && !_closeAfterStop)
        {
            if (WindowState == FormWindowState.Minimized) WindowState = FormWindowState.Normal;
            DialogResult choice = MessageBox.Show(this,
                "A recording is in progress.\r\n\r\nYes = stop, save the recording and close\r\nNo = discard and close\r\nCancel = keep recording",
                "Recording in progress", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            if (choice == DialogResult.Cancel)
            {
                e.Cancel = true;
                return;
            }
            if (choice == DialogResult.Yes)
            {
                e.Cancel = true;
                _closeAfterStop = true;
                _ = StopAsync();
                return;
            }
            try { _session.Abort(); } catch { /* ignore */ }
            _session.Dispose();
            _session = null;
        }
        base.OnFormClosing(e);
    }

    protected override void OnFormClosed(FormClosedEventArgs e)
    {
        _timer.Stop();
        _session?.Dispose();
        _session = null;
        _hotkey?.Dispose();
        _hotkey = null;
        _tray.Visible = false;
        _tray.Dispose();
        _bar.Dispose();
        base.OnFormClosed(e);
        _appContext?.ExitThread();
    }

    /// <summary>Last-resort cleanup used by the global exception handlers.</summary>
    public void EmergencyCleanup()
    {
        try { _session?.Abort(); } catch { /* ignore */ }
        try { _session?.Dispose(); } catch { /* ignore */ }
        _session = null;
        try { _hotkey?.Dispose(); } catch { /* ignore */ }
        _hotkey = null;
        try { _tray.Visible = false; } catch { /* ignore */ }
        try { _bar.Hide(); } catch { /* ignore */ }
    }

    // ---------------------------------------------------------------- tray, global shortcut, shortcuts dialog

    private void InitTray()
    {
        _tray.Icon = Icon ?? SystemIcons.Application;
        _tray.Text = OmnifiBrand.ProductName + " (" + CtrlPairHotkey.DisplayName + " to open)";
        var menu = new ContextMenuStrip();
        menu.Items.Add("Open Steps Recorder", null, (_, _) => ShowFromTray());
        menu.Items.Add("Shortcuts...", null, (_, _) => { ShowFromTray(); ShowShortcutsDialog(); });
        menu.Items.Add(OmnifiBrand.SuperToolsName, null, (_, _) => OpenSuperTools());
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add("Exit", null, (_, _) => ExitApplication());
        _tray.ContextMenuStrip = menu;
        _tray.DoubleClick += (_, _) => ShowFromTray();
        _tray.Visible = true;
    }

    /// <summary>Installs/removes the Left Ctrl + Right Ctrl listener and the Startup entry to match the settings.</summary>
    private void ApplyShortcutSettings(bool showErrors)
    {
        try
        {
            if (_settings.HotkeyEnabled)
            {
                if (_hotkey == null)
                {
                    _hotkey = new CtrlPairHotkey();
                    _hotkey.Triggered += (_, _) => ShowFromTray();
                    _hotkey.Install();
                }
            }
            else
            {
                _hotkey?.Dispose();
                _hotkey = null;
            }
        }
        catch (Exception ex)
        {
            Log("Shortcut listener error: " + ex.Message);
            if (showErrors) ShowError("Shortcut could not be enabled", ex);
        }

        try
        {
            // Always (re)write the Startup entry when enabled so it keeps pointing at the current app folder
            // even if the folder was moved; remove it when disabled.
            bool wantStartup = _settings.HotkeyEnabled && _settings.StartWithWindows;
            if (wantStartup || ShortcutManager.StartupShortcutExists) ShortcutManager.SetStartupShortcut(wantStartup);
        }
        catch (Exception ex)
        {
            Log("Startup shortcut error: " + ex.Message);
            if (showErrors) ShowError("Startup entry could not be updated", ex);
        }

        if (_settings.HotkeyEnabled && !_settings.FirstRunNoticeShown)
        {
            _settings.FirstRunNoticeShown = true;
            _settings.Save();
            Log("Shortcut enabled: press " + CtrlPairHotkey.DisplayName + " together at any time to open Steps Recorder. Closing the window keeps it in the tray; use the tray icon's Exit to quit. Change this under Shortcuts...");
        }
    }

    public void ShowFromTray()
    {
        if (IsDisposed) return;
        if (!Visible) Show();
        if (WindowState == FormWindowState.Minimized) WindowState = FormWindowState.Normal;
        TopMost = true; // briefly, to win the foreground
        Activate();
        TopMost = false;
    }

    private void HideToTray()
    {
        Hide();
        if (!_trayTipShown)
        {
            _trayTipShown = true;
            _tray.BalloonTipTitle = OmnifiBrand.ProductName;
            _tray.BalloonTipText = "Still running in the background. Press " + CtrlPairHotkey.DisplayName + " to open it again, or right-click this icon and choose Exit.";
            _tray.ShowBalloonTip(4000);
        }
    }

    private void ExitApplication()
    {
        _exiting = true;
        ShowFromTray();
        Close();
    }

    /// <summary>Opens the Omnifi SuperTools web app in the user's default browser. The only network action in the app, and only on explicit click.</summary>
    private void OpenSuperTools()
    {
        try
        {
            Process.Start(new ProcessStartInfo(OmnifiBrand.SuperToolsUrl) { UseShellExecute = true });
            Log("Opened " + OmnifiBrand.SuperToolsName + " in your browser.");
        }
        catch (Exception ex)
        {
            Log("Could not open the browser: " + ex.Message);
            MessageBox.Show(this, "Could not open your browser. You can visit " + OmnifiBrand.SuperToolsUrl + " manually.", OmnifiBrand.SuperToolsName, MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }

    private void ShowPrivacyNotice()
    {
        using var dlg = MakeFixedDialog("Privacy notice");
        var layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink, Padding = new Padding(20, 16, 20, 14) };
        var text = new Label
        {
            Text = PrivacyNotice,
            AutoSize = true,
            MaximumSize = new Size(660, 0),
            ForeColor = OmnifiBrand.DeepNavy,
            Font = OmnifiBrand.BodyFont(10f),
            Padding = new Padding(14, 8, 8, 8),
            BackColor = OmnifiBrand.White
        };
        text.Paint += (_, e) =>
        {
            using var pen = new Pen(OmnifiBrand.IndigoBright, 4f);
            e.Graphics.DrawLine(pen, 2, 0, 2, text.Height);
        };
        var ok = new Button { DialogResult = DialogResult.OK, Anchor = AnchorStyles.Right };
        StylePrimary(ok, "Close");
        ok.Margin = new Padding(0, 12, 0, 0);
        layout.Controls.Add(text, 0, 0);
        layout.Controls.Add(ok, 0, 1);
        dlg.Controls.Add(layout);
        dlg.AcceptButton = ok;
        dlg.CancelButton = ok;
        dlg.ShowDialog(this);
    }

    /// <summary>Non-resizable dialog that sizes itself to its (auto-sized) content, so buttons can never be pushed out of view.</summary>
    private Form MakeFixedDialog(string title)
    {
        var dlg = new Form
        {
            Text = title,
            FormBorderStyle = FormBorderStyle.FixedDialog,
            StartPosition = FormStartPosition.CenterParent,
            MinimizeBox = false,
            MaximizeBox = false,
            ShowInTaskbar = false,
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            BackColor = OmnifiBrand.OffWhite,
            Font = OmnifiBrand.BodyFont(9.75f),
            Icon = Icon
        };
        CaptureExclusion.Apply(dlg); // recorder dialogs never appear in screenshots or video
        return dlg;
    }

    private void ShowShortcutsDialog()
    {
        using var dlg = MakeFixedDialog("Shortcuts");
        // Auto-sized table with wrapping labels: the dialog grows to fit, so nothing is clipped and it cannot be resized.
        var layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink, Padding = new Padding(20, 16, 20, 14) };
        int textWidth = 600;

        var hotkeyCheck = new CheckBox
        {
            Text = "Open Steps Recorder with " + CtrlPairHotkey.DisplayName + " pressed together (default)",
            Checked = _settings.HotkeyEnabled, AutoSize = true, MaximumSize = new Size(textWidth, 0), ForeColor = OmnifiBrand.DeepNavy, Margin = new Padding(0, 0, 0, 6)
        };
        var startupCheck = new CheckBox
        {
            Text = "Start with Windows in the background so the shortcut always works",
            Checked = _settings.StartWithWindows, AutoSize = true, MaximumSize = new Size(textWidth - 24, 0), ForeColor = OmnifiBrand.BodyNavy, Margin = new Padding(24, 0, 0, 14)
        };
        var desktopCheck = new CheckBox
        {
            Text = "Create a shortcut on the Desktop",
            Checked = ShortcutManager.DesktopShortcutExists, AutoSize = true, MaximumSize = new Size(textWidth, 0), ForeColor = OmnifiBrand.DeepNavy, Margin = new Padding(0, 0, 0, 14)
        };
        var info = new Label
        {
            Text = "The shortcut only checks whether the two Ctrl keys are held at the same time. It never records, stores or sends any other keystrokes.\r\n\r\n" +
                   "While the shortcut is enabled, closing the window keeps Steps Recorder in the system tray so the shortcut keeps working; right-click the tray icon and choose Exit to quit completely.",
            AutoSize = true, MaximumSize = new Size(textWidth, 0), ForeColor = OmnifiBrand.MutedIndigo, Margin = new Padding(0)
        };
        var buttons = new FlowLayoutPanel { FlowDirection = FlowDirection.RightToLeft, AutoSize = true, Anchor = AnchorStyles.Right, Margin = new Padding(0, 14, 0, 0) };
        var cancel = new Button { DialogResult = DialogResult.Cancel };
        var ok = new Button { DialogResult = DialogResult.OK };
        StylePrimary(ok, "Apply");
        StyleSecondary(cancel, "Cancel");
        cancel.Margin = new Padding(0);
        ok.Margin = new Padding(0, 0, 10, 0);
        buttons.Controls.AddRange(new Control[] { cancel, ok });

        hotkeyCheck.CheckedChanged += (_, _) => startupCheck.Enabled = hotkeyCheck.Checked;
        startupCheck.Enabled = hotkeyCheck.Checked;

        layout.Controls.Add(hotkeyCheck, 0, 0);
        layout.Controls.Add(startupCheck, 0, 1);
        layout.Controls.Add(desktopCheck, 0, 2);
        layout.Controls.Add(info, 0, 3);
        layout.Controls.Add(buttons, 0, 4);
        dlg.Controls.Add(layout);
        dlg.AcceptButton = ok;
        dlg.CancelButton = cancel;

        if (dlg.ShowDialog(this) != DialogResult.OK) return;

        _settings.HotkeyEnabled = hotkeyCheck.Checked;
        _settings.StartWithWindows = startupCheck.Checked;
        _settings.Save();
        ApplyShortcutSettings(showErrors: true);
        try
        {
            if (desktopCheck.Checked != ShortcutManager.DesktopShortcutExists) ShortcutManager.SetDesktopShortcut(desktopCheck.Checked);
        }
        catch (Exception ex)
        {
            ShowError("Desktop shortcut could not be updated", ex);
        }
        Log("Shortcut settings applied: hotkey " + (_settings.HotkeyEnabled ? "on" : "off") +
            ", start with Windows " + (_settings.HotkeyEnabled && _settings.StartWithWindows ? "on" : "off") +
            ", desktop shortcut " + (ShortcutManager.DesktopShortcutExists ? "on" : "off") + ".");
    }
}
