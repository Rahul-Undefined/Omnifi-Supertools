# Self-contained single-file publish (one StepsRecorder.exe, ~150 MB, no .NET runtime needed on the target).
# NOTE: on machines with WDAC / AppLocker / Smart App Control, an unsigned EXE from a user folder will be
# refused ("Access is denied"). Use publish-portable.ps1 + run.cmd there, or code-sign the EXE.
param([string]$Output = "$PSScriptRoot\..\publish\singlefile")
$ErrorActionPreference = "Stop"
$proj = Join-Path $PSScriptRoot "..\src\StepsRecorder\StepsRecorder.csproj"
dotnet publish $proj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o $Output
Write-Host "Published to $Output"
