using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using StepsRecorder.Branding;

namespace StepsRecorder.AI;

/// <summary>Allowance as reported by the SOP service: N SOPs per window per computer.</summary>
public sealed class SopAllowance
{
    [JsonPropertyName("limit")] public int Limit { get; set; }
    [JsonPropertyName("used")] public int Used { get; set; }
    [JsonPropertyName("remaining")] public int Remaining { get; set; }
    [JsonPropertyName("resetsAt")] public long ResetsAtUnixMs { get; set; }
    [JsonPropertyName("windowHours")] public int WindowHours { get; set; }

    [JsonIgnore] public DateTime ResetsAtLocal => DateTimeOffset.FromUnixTimeMilliseconds(ResetsAtUnixMs).LocalDateTime;

    public string Describe()
    {
        if (Limit <= 0) return "No limit configured.";
        var left = ResetsAtLocal - DateTime.Now;
        string reset = left.TotalMinutes < 1 ? "soon" : left.TotalHours >= 1 ? $"in {(int)left.TotalHours} h {left.Minutes} min" : $"in {left.Minutes} min";
        return $"{Used} of {Limit} AI SOPs used in this {WindowHours}-hour window; {Remaining} left, resets {reset}.";
    }
}

public sealed class SopServiceStatus
{
    [JsonPropertyName("configured")] public bool Configured { get; set; }
    [JsonPropertyName("allowance")] public SopAllowance? Allowance { get; set; }
}

public sealed class SopServiceResponse
{
    [JsonPropertyName("sop")] public SopDocument? Sop { get; set; }
    [JsonPropertyName("allowance")] public SopAllowance? Allowance { get; set; }
    [JsonPropertyName("imagesUsed")] public int ImagesUsed { get; set; }
}

/// <summary>
/// Client for the Omnifi SuperTools "Steps Recorder SOP" endpoints. The app authenticates with the build-time
/// token and a per-install device id; the AI provider key lives on the server only. These are the only network
/// calls in the app besides opening the SuperTools web page, and they run only when AI SOP is enabled.
/// </summary>
public sealed class SopServiceClient : IDisposable
{
    private readonly HttpClient _http;
    private readonly string _deviceId;

    public SopServiceClient(string deviceId)
    {
        _deviceId = deviceId;
        // The server allows the AI provider up to 4 minutes for large multimodal requests; wait a little longer than that.
        _http = new HttpClient { BaseAddress = new Uri(AppConfig.SopServiceBaseUrl), Timeout = TimeSpan.FromSeconds(300) };
        _http.DefaultRequestHeaders.UserAgent.ParseAdd("StepsRecorder/0.1");
        _http.DefaultRequestHeaders.Add("x-steps-recorder-token", AppConfig.SopServiceToken);
        _http.DefaultRequestHeaders.Add("x-steps-recorder-device", deviceId);
    }

    public async Task<SopServiceStatus> GetStatusAsync(CancellationToken cancellationToken)
    {
        using HttpResponseMessage res = await Send(() => new HttpRequestMessage(HttpMethod.Get, "/api/steps-recorder/status"), cancellationToken).ConfigureAwait(false);
        string body = await res.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
        if (!res.IsSuccessStatusCode) throw new SopServiceException(DescribeError(res.StatusCode, body));
        return JsonSerializer.Deserialize<SopServiceStatus>(body) ?? throw new SopServiceException("Unexpected answer from the SOP service.");
    }

    public sealed class StartResponse
    {
        [JsonPropertyName("jobId")] public string JobId { get; set; } = string.Empty;
        [JsonPropertyName("allowance")] public SopAllowance? Allowance { get; set; }
        [JsonPropertyName("pollAfterMs")] public int PollAfterMs { get; set; } = 5000;
    }

    public sealed class ResultResponse
    {
        [JsonPropertyName("state")] public string State { get; set; } = string.Empty;
        [JsonPropertyName("sop")] public SopDocument? Sop { get; set; }
        [JsonPropertyName("imagesUsed")] public int ImagesUsed { get; set; }
        [JsonPropertyName("elapsedMs")] public long ElapsedMs { get; set; }
        [JsonPropertyName("error")] public string? Error { get; set; }
        [JsonPropertyName("hint")] public string? Hint { get; set; }
    }

    /// <summary>
    /// Asynchronous flow: start the job, then poll until it is done. Immune to HTTP timeouts, so large
    /// screenshot batches can take several minutes on the free tier without failing.
    /// </summary>
    public async Task<SopServiceResponse> GenerateViaJobAsync(object payload, IProgress<string>? progress, CancellationToken cancellationToken)
    {
        string json = JsonSerializer.Serialize(payload, new JsonSerializerOptions { DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull });
        StartResponse start;
        using (HttpResponseMessage res = await Send(() =>
        {
            var req = new HttpRequestMessage(HttpMethod.Post, "/api/steps-recorder/sop/start") { Content = new StringContent(json, Encoding.UTF8) };
            req.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
            return req;
        }, cancellationToken).ConfigureAwait(false))
        {
            string body = await res.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
            if (!res.IsSuccessStatusCode) throw new SopServiceException(DescribeError(res.StatusCode, body));
            start = JsonSerializer.Deserialize<StartResponse>(body) ?? throw new SopServiceException("Unexpected answer from the SOP service.");
            if (string.IsNullOrEmpty(start.JobId)) throw new SopServiceException("The SOP service did not return a job id.");
        }

        var started = DateTime.UtcNow;
        int interval = Math.Clamp(start.PollAfterMs, 2000, 15000);
        while (true)
        {
            await Task.Delay(interval, cancellationToken).ConfigureAwait(false);
            using HttpResponseMessage res = await Send(() => new HttpRequestMessage(HttpMethod.Get, "/api/steps-recorder/sop/result?job=" + Uri.EscapeDataString(start.JobId)), cancellationToken).ConfigureAwait(false);
            string body = await res.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
            if (!res.IsSuccessStatusCode) throw new SopServiceException(DescribeError(res.StatusCode, body));
            var result = JsonSerializer.Deserialize<ResultResponse>(body) ?? throw new SopServiceException("Unexpected answer from the SOP service.");
            if (result.State == "done" && result.Sop != null)
                return new SopServiceResponse { Sop = result.Sop, Allowance = start.Allowance, ImagesUsed = result.ImagesUsed };
            if (result.State == "failed")
                throw new SopServiceException((result.Error ?? "The SOP could not be generated.") + (string.IsNullOrEmpty(result.Hint) ? string.Empty : " " + result.Hint));
            var waited = DateTime.UtcNow - started;
            if (waited > AppConfig.SopMaxWait) throw new SopServiceException("The AI SOP is taking longer than " + (int)AppConfig.SopMaxWait.TotalMinutes + " minutes. Try again later with \"Generate AI SOP\".");
            progress?.Report($"Still writing... ({(int)waited.TotalSeconds} s)");
        }
    }

    public async Task<SopServiceResponse> GenerateAsync(object payload, CancellationToken cancellationToken)
    {
        // Omit null fields (e.g. endX/endY on plain clicks): the server validates them as optional numbers.
        string json = JsonSerializer.Serialize(payload, new JsonSerializerOptions { DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull });
        using HttpResponseMessage res = await Send(() =>
        {
            var req = new HttpRequestMessage(HttpMethod.Post, "/api/steps-recorder/sop") { Content = new StringContent(json, Encoding.UTF8) };
            req.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
            return req;
        }, cancellationToken).ConfigureAwait(false);
        string body = await res.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
        if (!res.IsSuccessStatusCode) throw new SopServiceException(DescribeError(res.StatusCode, body));
        var parsed = JsonSerializer.Deserialize<SopServiceResponse>(body) ?? throw new SopServiceException("Unexpected answer from the SOP service.");
        if (parsed.Sop == null) throw new SopServiceException("The SOP service returned no SOP. Try again.");
        return parsed;
    }

    private async Task<HttpResponseMessage> Send(Func<HttpRequestMessage> make, CancellationToken cancellationToken)
    {
        try
        {
            using HttpRequestMessage req = make();
            return await _http.SendAsync(req, cancellationToken).ConfigureAwait(false);
        }
        catch (TaskCanceledException) when (!cancellationToken.IsCancellationRequested)
        {
            throw new SopServiceException("The AI SOP service took too long to answer. Try again in a minute.");
        }
        catch (HttpRequestException ex)
        {
            throw new SopServiceException("Could not reach the Omnifi SuperTools server (no internet, or blocked by a proxy/firewall): " + ex.Message);
        }
    }

    private static string DescribeError(HttpStatusCode status, string body)
    {
        string error = string.Empty, hint = string.Empty;
        try
        {
            using var doc = JsonDocument.Parse(body);
            if (doc.RootElement.TryGetProperty("error", out var e)) error = e.GetString() ?? string.Empty;
            if (doc.RootElement.TryGetProperty("hint", out var h) && h.ValueKind == JsonValueKind.String) hint = h.GetString() ?? string.Empty;
        }
        catch { /* not JSON */ }
        if (string.IsNullOrEmpty(error))
        {
            error = status switch
            {
                HttpStatusCode.Unauthorized => "This version of Steps Recorder is not authorised for the AI SOP service. Ask the administrator for the current build.",
                HttpStatusCode.TooManyRequests => "AI SOP allowance used up for now. Try again later.",
                HttpStatusCode.ServiceUnavailable => "The AI SOP service is not configured on the server yet.",
                _ => "The AI SOP service returned an error (" + (int)status + ")."
            };
        }
        return string.IsNullOrEmpty(hint) ? error : error + " " + hint;
    }

    public void Dispose() => _http.Dispose();
}

public sealed class SopServiceException : Exception
{
    public SopServiceException(string message) : base(message) { }
}
