using System.Globalization;
using System.Text;
using StepsRecorder.Models;

namespace StepsRecorder.Reporting;

/// <summary>Writes steps.html, steps.docx and summary.txt. Called once, after all steps are final.</summary>
public static class ReportGenerator
{
    public static void WriteAll(RecordingResult result)
    {
        string html = Path.Combine(result.OutputFolder, "steps.html");
        string docx = Path.Combine(result.OutputFolder, "steps.docx");
        string summary = Path.Combine(result.OutputFolder, "summary.txt");

        try
        {
            HtmlReportWriter.Write(html, result);
            result.HtmlPath = html;
        }
        catch (Exception ex)
        {
            result.Warnings.Add("steps.html could not be written: " + ex.Message);
        }

        try
        {
            DocxReportWriter.Write(docx, result);
            result.DocxPath = docx;
        }
        catch (Exception ex)
        {
            result.Warnings.Add("steps.docx could not be written: " + ex.Message);
        }

        try
        {
            SummaryWriter.Write(summary, result);
            result.SummaryPath = summary;
        }
        catch (Exception ex)
        {
            result.Warnings.Add("summary.txt could not be written: " + ex.Message);
        }
    }

    public static string FormatOffset(TimeSpan t) => t.ToString(@"hh\:mm\:ss\.fff", CultureInfo.InvariantCulture);
    public static string FormatDuration(TimeSpan t) => t.ToString(@"hh\:mm\:ss", CultureInfo.InvariantCulture);
    public static string FormatWall(DateTime t) => t.ToString("yyyy-MM-dd HH:mm:ss.fff", CultureInfo.InvariantCulture);

    public static string ButtonName(MouseButton b) => b switch
    {
        MouseButton.Left => "Left",
        MouseButton.Right => "Right",
        _ => "Middle"
    };

    public static string FormatBytes(long bytes)
    {
        string[] units = { "B", "KB", "MB", "GB" };
        double v = bytes;
        int u = 0;
        while (v >= 1024 && u < units.Length - 1) { v /= 1024; u++; }
        return u == 0 ? $"{bytes} B" : v.ToString("0.0", CultureInfo.InvariantCulture) + " " + units[u];
    }
}

public static class SummaryWriter
{
    public static void Write(string path, RecordingResult r)
    {
        var sb = new StringBuilder();
        sb.AppendLine("Omnifi Steps Recorder - recording summary");
        sb.AppendLine("=========================================");
        sb.AppendLine(Branding.OmnifiBrand.InternalUseNotice);
        sb.AppendLine();
        sb.AppendLine($"Started:            {ReportGenerator.FormatWall(r.StartedAt)}");
        sb.AppendLine($"Ended:              {ReportGenerator.FormatWall(r.EndedAt)}");
        sb.AppendLine($"Recording duration: {ReportGenerator.FormatDuration(r.ActiveDuration)} (excluding pauses)");
        sb.AppendLine($"Total steps:        {r.Steps.Count} ({r.ClickCount} clicks, {r.SelectionCount} selections)");
        sb.AppendLine($"Audio:              {(r.AudioMode == "Microphone" ? "Microphone (voice narration)" : "None")}");
        sb.AppendLine($"Machine:            {r.MachineName}");
        sb.AppendLine($"Captured display:   {r.CaptureDisplay}");
        sb.AppendLine($"Video:              {(r.VideoSucceeded ? "OK" : "FAILED - " + (r.VideoError ?? "unknown error"))}");
        sb.AppendLine();
        sb.AppendLine("Output folder:");
        sb.AppendLine("  " + r.OutputFolder);
        sb.AppendLine();
        sb.AppendLine("Output files:");
        AppendFile(sb, r.VideoPath, "screen.mp4");
        AppendFile(sb, r.HtmlPath, "steps.html");
        AppendFile(sb, r.DocxPath, "steps.docx");
        sb.AppendLine("  summary.txt");
        int saved = r.Steps.Count(s => s.ScreenshotSaved);
        sb.AppendLine($"  screenshots/ ({saved} PNG file{(saved == 1 ? "" : "s")})");
        foreach (var s in r.Steps.Where(s => s.ScreenshotSaved))
            sb.AppendLine("    " + s.ScreenshotRelativePath);

        if (r.Warnings.Count > 0)
        {
            sb.AppendLine();
            sb.AppendLine("Warnings:");
            foreach (var w in r.Warnings) sb.AppendLine("  - " + w);
        }

        File.WriteAllText(path, sb.ToString(), new UTF8Encoding(false));
    }

    private static void AppendFile(StringBuilder sb, string? path, string label)
    {
        if (!string.IsNullOrEmpty(path) && File.Exists(path))
            sb.AppendLine($"  {label} ({ReportGenerator.FormatBytes(new FileInfo(path).Length)})");
        else
            sb.AppendLine($"  {label} (missing)");
    }
}
