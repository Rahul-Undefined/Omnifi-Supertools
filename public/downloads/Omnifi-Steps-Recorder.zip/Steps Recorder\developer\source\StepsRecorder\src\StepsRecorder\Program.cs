using StepsRecorder.UI;

namespace StepsRecorder;

internal static class Program
{
    private const string MutexName = @"Local\StepsRecorder.SingleInstance";
    private const string ShowEventName = @"Local\StepsRecorder.Show";

    [STAThread]
    private static int Main(string[] args)
    {
        ApplicationConfiguration.Initialize();
        Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
        // Own taskbar identity (icon, grouping, pinning) even though the host process is dotnet.exe.
        Native.TaskbarIdentity.SetProcessId();

        // Developer self-test: StepsRecorder.exe --selftest <outputRoot> [seconds]
        if (args.Length >= 2 && args[0].Equals("--selftest", StringComparison.OrdinalIgnoreCase))
        {
            int seconds = args.Length > 2 && int.TryParse(args[2], out int s) ? Math.Clamp(s, 3, 60) : 6;
            return SelfTest.Run(args[1], seconds);
        }

        bool startInTray = args.Any(a => a.Equals("--tray", StringComparison.OrdinalIgnoreCase));

        // Single instance: if the app (or its background listener) is already running, just ask it to show.
        using var mutex = new Mutex(initiallyOwned: true, MutexName, out bool isFirstInstance);
        using var showEvent = new EventWaitHandle(false, EventResetMode.AutoReset, ShowEventName);
        if (!isFirstInstance)
        {
            if (!startInTray) showEvent.Set();
            return 0;
        }

        var form = new MainForm(startHidden: startInTray);

        // Another launch (desktop shortcut, launcher, hotkey shortcut) asks us to come to the front.
        var listener = new Thread(() =>
        {
            while (showEvent.WaitOne())
            {
                try { form.BeginInvoke(form.ShowFromTray); } catch { break; }
            }
        }) { IsBackground = true, Name = "StepsRecorder.ShowListener" };
        listener.Start();

        // Global handlers: whatever happens, the low-level hooks must be removed.
        Application.ThreadException += (_, e) =>
        {
            form.EmergencyCleanup();
            MessageBox.Show("An unexpected error occurred and the recording was stopped:\r\n\r\n" + e.Exception.Message,
                "Steps Recorder", MessageBoxButtons.OK, MessageBoxIcon.Error);
        };
        AppDomain.CurrentDomain.UnhandledException += (_, _) => form.EmergencyCleanup();
        AppDomain.CurrentDomain.ProcessExit += (_, _) => form.EmergencyCleanup();

        Application.Run(form.RunContext());
        return 0;
    }
}
