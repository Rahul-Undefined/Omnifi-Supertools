using System.ComponentModel;
using System.Runtime.InteropServices;
using StepsRecorder.Models;
using StepsRecorder.Native;

namespace StepsRecorder.Recording;

public sealed class MouseButtonDownEventArgs : EventArgs
{
    public MouseButtonDownEventArgs(MouseButton button, int x, int y, uint tickCount)
    {
        Button = button;
        X = x;
        Y = y;
        TickCount = tickCount;
    }

    public MouseButton Button { get; }
    public int X { get; }
    public int Y { get; }
    public uint TickCount { get; }
}

/// <summary>
/// Low-level (WH_MOUSE_LL) mouse hook.
///
/// Threading rules:
///  * A low-level hook needs a thread that pumps messages, so the hook must be created and installed on the
///    WinForms UI thread. Install/Uninstall marshal to that thread automatically if called from elsewhere.
///  * The callback runs on the UI thread for every mouse message system-wide. It must return quickly;
///    subscribers of <see cref="ButtonDown"/> must only enqueue work, never capture, inspect or write files.
///  * If the callback blocks longer than the OS low-level hook timeout, Windows silently removes the hook.
///    Therefore the UI thread must never block while the hook is installed (the app uses async/await throughout).
///  * Exceptions never escape the callback.
/// </summary>
public sealed class MouseHook : IDisposable
{
    private readonly SynchronizationContext _uiContext;
    private readonly int _uiThreadId;
    private NativeMethods.LowLevelMouseProc? _proc; // keeps the delegate alive while the hook is installed
    private IntPtr _hookHandle;
    private bool _disposed;

    public MouseHook()
    {
        _uiContext = SynchronizationContext.Current
            ?? throw new InvalidOperationException("MouseHook must be created on the UI thread (a message loop is required).");
        _uiThreadId = Environment.CurrentManagedThreadId;
    }

    public bool IsInstalled => _hookHandle != IntPtr.Zero;

    public event EventHandler<MouseButtonDownEventArgs>? ButtonDown;

    /// <summary>Raised on button release (same args type; used to detect drag selections).</summary>
    public event EventHandler<MouseButtonDownEventArgs>? ButtonUp;

    public void Install()
    {
        ObjectDisposedException.ThrowIf(_disposed, this);
        RunOnUiThread(() =>
        {
            if (_hookHandle != IntPtr.Zero) return;
            _proc = HookCallback;
            IntPtr module = NativeMethods.GetModuleHandle(null);
            _hookHandle = NativeMethods.SetWindowsHookEx(NativeMethods.WH_MOUSE_LL, _proc, module, 0);
            if (_hookHandle == IntPtr.Zero)
            {
                int error = Marshal.GetLastWin32Error();
                _proc = null;
                throw new Win32Exception(error, "Failed to install the low-level mouse hook.");
            }
        });
    }

    public void Uninstall()
    {
        RunOnUiThread(() =>
        {
            if (_hookHandle == IntPtr.Zero) return;
            NativeMethods.UnhookWindowsHookEx(_hookHandle);
            _hookHandle = IntPtr.Zero;
            _proc = null;
        });
    }

    private void RunOnUiThread(Action action)
    {
        if (Environment.CurrentManagedThreadId == _uiThreadId)
        {
            action();
        }
        else
        {
            Exception? captured = null;
            _uiContext.Send(_ =>
            {
                try { action(); }
                catch (Exception ex) { captured = ex; }
            }, null);
            if (captured != null) throw captured;
        }
    }

    private IntPtr HookCallback(int nCode, IntPtr wParam, IntPtr lParam)
    {
        if (nCode >= 0)
        {
            try
            {
                long message = wParam.ToInt64();
                (MouseButton Button, bool Down)? e = message switch
                {
                    NativeMethods.WM_LBUTTONDOWN => (MouseButton.Left, true),
                    NativeMethods.WM_RBUTTONDOWN => (MouseButton.Right, true),
                    NativeMethods.WM_MBUTTONDOWN => (MouseButton.Middle, true),
                    NativeMethods.WM_LBUTTONUP => (MouseButton.Left, false),
                    NativeMethods.WM_RBUTTONUP => (MouseButton.Right, false),
                    NativeMethods.WM_MBUTTONUP => (MouseButton.Middle, false),
                    _ => null
                };

                if (e.HasValue)
                {
                    var info = Marshal.PtrToStructure<NativeMethods.MSLLHOOKSTRUCT>(lParam);
                    var args = new MouseButtonDownEventArgs(e.Value.Button, info.pt.X, info.pt.Y, info.time);
                    if (e.Value.Down) ButtonDown?.Invoke(this, args);
                    else ButtonUp?.Invoke(this, args);
                }
            }
            catch
            {
                // Never let an exception propagate out of a system hook callback.
            }
        }

        return NativeMethods.CallNextHookEx(_hookHandle, nCode, wParam, lParam);
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        try { Uninstall(); } catch { /* best effort on dispose */ }
    }
}
