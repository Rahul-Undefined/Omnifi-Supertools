@echo off
rem Launches Steps Recorder through the Microsoft-signed dotnet.exe host (works under WDAC / AppLocker policies
rem that block unsigned EXEs). Uses a portable runtime in .\dotnet if present, otherwise the machine's .NET 8.
setlocal
set "HERE=%~dp0"
if exist "%HERE%dotnet\dotnet.exe" (
    set "DOTNET_ROOT=%HERE%dotnet"
    "%HERE%dotnet\dotnet.exe" "%HERE%StepsRecorder.dll" %*
) else (
    dotnet "%HERE%StepsRecorder.dll" %*
)
endlocal
