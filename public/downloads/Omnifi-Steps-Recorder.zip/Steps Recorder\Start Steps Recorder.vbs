' Silent launcher for Omnifi Steps Recorder.
' Starts the app through the Microsoft-signed dotnet.exe host (allowed by WDAC / AppLocker policies that block
' unsigned EXEs) wrapped in "conhost.exe --headless", so no console window ever appears while the app window
' shows normally. Uses the portable runtime in .\dotnet when present, otherwise the machine's .NET 8.
Option Explicit
Dim fso, sh, here, dll, host, cmd
Set fso = CreateObject("Scripting.FileSystemObject")
Set sh = CreateObject("WScript.Shell")
here = fso.GetParentFolderName(WScript.ScriptFullName)
' The app may sit next to this launcher, or in a "program" / "app" subfolder.
dll = fso.BuildPath(here, "StepsRecorder.dll")
If Not fso.FileExists(dll) Then dll = fso.BuildPath(fso.BuildPath(here, "program"), "StepsRecorder.dll")
If Not fso.FileExists(dll) Then dll = fso.BuildPath(fso.BuildPath(here, "app"), "StepsRecorder.dll")
If Not fso.FileExists(dll) Then
    MsgBox "The program files were not found. Keep this launcher in the same folder as the ""program"" folder.", vbExclamation, "Omnifi Steps Recorder"
    WScript.Quit 1
End If
host = fso.BuildPath(fso.BuildPath(fso.GetParentFolderName(dll), "dotnet"), "dotnet.exe")
If fso.FileExists(host) Then
    sh.Environment("PROCESS")("DOTNET_ROOT") = fso.GetParentFolderName(host)
Else
    host = "dotnet.exe"
End If
' Forward any arguments (e.g. --tray for the background listener, --selftest for diagnostics).
Dim i, extra
extra = ""
For i = 0 To WScript.Arguments.Count - 1
    extra = extra & " """ & WScript.Arguments(i) & """"
Next
cmd = "conhost.exe --headless """ & host & """ """ & dll & """" & extra
sh.Run cmd, 1, False
